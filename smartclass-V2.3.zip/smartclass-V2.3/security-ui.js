"use strict";

/*
========================================
 SmartClass Security UI
 Version: 1.0
========================================
*/

(function () {

    const STATE = {
        status: "INITIALIZING",
        monitoring: false,
        rateLimiter: false,
        rules: false,
        logs: false
    };


    function setState(name, value) {

        if (
            Object.prototype.hasOwnProperty.call(
                STATE,
                name
            )
        ) {
            STATE[name] = Boolean(value);
        }

    }


    function setStatus(status) {

        const allowed = [
            "INITIALIZING",
            "PROTECTED",
            "WARNING",
            "RESTRICTED",
            "ERROR"
        ];

        if (allowed.includes(status)) {
            STATE.status = status;
        }

    }


    function getState() {

        return {
            status: STATE.status,
            monitoring: STATE.monitoring,
            rateLimiter: STATE.rateLimiter,
            rules: STATE.rules,
            logs: STATE.logs
        };

    }


    function getProtectionScore() {

        let score = 0;

        if (STATE.monitoring) {
            score += 25;
        }

        if (STATE.rateLimiter) {
            score += 25;
        }

        if (STATE.rules) {
            score += 25;
        }

        if (STATE.logs) {
            score += 25;
        }

        return score;

    }


    function getSecurityStatus() {

        const score =
            getProtectionScore();


        if (STATE.status === "ERROR") {
            return "ERROR";
        }

        if (STATE.status === "RESTRICTED") {
            return "RESTRICTED";
        }

        if (score === 100) {
            return "PROTECTED";
        }

        if (score >= 50) {
            return "PARTIAL";
        }

        return "INITIALIZING";

    }


    window.SmartClassSecurityUI = {

        version: "1.0",

        setState: setState,

        setStatus: setStatus,

        getState: getState,

        getProtectionScore:
            getProtectionScore,

        getSecurityStatus:
            getSecurityStatus

    };


    console.info(
        "SmartClass Security UI 1.0 initialized."
    );

})();