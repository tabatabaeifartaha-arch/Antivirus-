"use strict";

// ==========================================
// SmartClass Security Initialization
// ==========================================

(function () {

    function initializeSecurity() {

        if (!window.SmartClassSecuritySettings) {
            console.error(
                "SmartClass Security Settings پیدا نشد."
            );
            return;
        }


        const settings =
            window.SmartClassSecuritySettings.getAll();


        // ======================================
        // Security Monitor
        // ======================================

        if (
            settings.securityMonitor &&
            window.SmartClassSecurityMonitor
        ) {

            window.SmartClassSecurityMonitor.start();

        }


        // ======================================
        // CSP
        // ======================================

        if (
            settings.csp &&
            window.SmartClassSecurityCSP
        ) {

            window.SmartClassSecurityCSP.apply();

        }


        // ======================================
        // Security UI State
        // ======================================

        if (window.SmartClassSecurityUI) {

            window.SmartClassSecurityUI.setState(
                "monitoring",
                Boolean(
                    settings.securityMonitor
                )
            );

            window.SmartClassSecurityUI.setState(
                "rateLimiter",
                Boolean(
                    settings.rateLimiting
                )
            );

            window.SmartClassSecurityUI.setState(
                "rules",
                Boolean(
                    settings.inputProtection
                )
            );

            window.SmartClassSecurityUI.setState(
                "logs",
                Boolean(
                    settings.securityLogs
                )
            );

        }


        console.log(
            "SmartClass Security Initialized 🔐"
        );

    }


    if (
        document.readyState ===
        "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            initializeSecurity
        );

    } else {

        initializeSecurity();

    }

})();