"use strict";

// ============================================================
// SmartClass Security Health Monitor
// Version 1.0
// ============================================================

window.SmartClassSecurityHealth = (function () {

    const VERSION = "1.0";

    const STATUS = {
        EXCELLENT: "EXCELLENT",
        HEALTHY: "HEALTHY",
        WARNING: "WARNING",
        CRITICAL: "CRITICAL",
        UNKNOWN: "UNKNOWN"
    };

    const CONFIG = {
        maxHistory: 50,
        minimumScore: 0,
        maximumScore: 100,
        criticalScore: 40,
        warningScore: 75
    };

    let lastReport = null;

    let history = [];

    let checks = 0;

    let lastCheckAt = null;

    let lastError = null;


    // =========================================================
    // Safe Log
    // =========================================================

    function log(
        level,
        type,
        message,
        details
    ) {

        try {

            if (
                window.SmartClassSecurityLog &&
                typeof window.SmartClassSecurityLog.log ===
                "function"
            ) {

                window.SmartClassSecurityLog.log(
                    level,
                    type,
                    message,
                    details || {}
                );

            }

        } catch (error) {

            console.error(
                "Security Health Log Error:",
                error
            );

        }

    }


    // =========================================================
    // Safe Number
    // =========================================================

    function safeNumber(
        value,
        fallback
    ) {

        const number =
            Number(value);

        if (
            !Number.isFinite(number)
        ) {

            return (
                Number.isFinite(fallback)
                    ? fallback
                    : 0
            );

        }

        return number;

    }


    // =========================================================
    // Clamp
    // =========================================================

    function clamp(
        value,
        minimum,
        maximum
    ) {

        return Math.max(
            minimum,
            Math.min(
                maximum,
                value
            )
        );

    }


    // =========================================================
    // Safe Module Check
    // =========================================================

    function moduleExists(
        name
    ) {

        try {

            return Boolean(
                window[name]
            );

        } catch (error) {

            return false;

        }

    }


    // =========================================================
    // Read Security Settings
    // =========================================================

    function getSettingsHealth() {

        const result = {

            available: false,

            enabled: 0,

            disabled: 0,

            total: 0,

            percentage: 0,

            strictMode: false

        };


        try {

            if (
                !window.SmartClassSecuritySettings ||
                typeof window.SmartClassSecuritySettings
                    .getSummary !== "function"
            ) {

                return result;

            }


            const summary =
                window.SmartClassSecuritySettings
                    .getSummary();


            if (
                !summary ||
                typeof summary !== "object"
            ) {

                return result;

            }


            result.available = true;

            result.enabled =
                safeNumber(
                    summary.enabled
                );

            result.disabled =
                safeNumber(
                    summary.disabled
                );

            result.total =
                safeNumber(
                    summary.total
                );

            result.percentage =
                clamp(
                    safeNumber(
                        summary.percentage
                    ),
                    0,
                    100
                );

            result.strictMode =
                summary.strictMode === true;


        } catch (error) {

            lastError =
                "Security settings health check failed.";

        }


        return result;

    }


    // =========================================================
    // Integrity Health
    // =========================================================

    function getIntegrityHealth() {

        const result = {

            available: false,

            score: null,

            status: "UNKNOWN",

            failures: 0

        };


        try {

            if (
                !window.SmartClassSecurityIntegrity
            ) {

                return result;

            }


            if (
                typeof window
                    .SmartClassSecurityIntegrity
                    .getStatus !== "function"
            ) {

                return result;

            }


            const status =
                window
                    .SmartClassSecurityIntegrity
                    .getStatus();


            if (
                !status ||
                typeof status !== "object"
            ) {

                return result;

            }


            result.available = true;

            result.score =
                clamp(
                    safeNumber(
                        status.score,
                        0
                    ),
                    0,
                    100
                );

            result.status =
                String(
                    status.status ||
                    "UNKNOWN"
                );

            result.failures =
                safeNumber(
                    status.failureCount
                );


        } catch (error) {

            lastError =
                "Integrity health check failed.";

        }


        return result;

    }


    // =========================================================
    // Fail-Safe Health
    // =========================================================

    function getFailSafeHealth() {

        const result = {

            available: false,

            mode: "UNKNOWN",

            safe: false,

            recentErrors: 0,

            totalErrors: 0

        };


        try {

            if (
                !window.SmartClassSecurityFailSafe
            ) {

                return result;

            }


            if (
                typeof window
                    .SmartClassSecurityFailSafe
                    .getStatus !== "function"
            ) {

                return result;

            }


            const status =
                window
                    .SmartClassSecurityFailSafe
                    .getStatus();


            if (
                !status ||
                typeof status !== "object"
            ) {

                return result;

            }


            result.available = true;

            result.mode =
                String(
                    status.mode ||
                    "UNKNOWN"
                );

            result.safe =
                status.safe === true;

            result.recentErrors =
                safeNumber(
                    status.recentErrors
                );

            result.totalErrors =
                safeNumber(
                    status.totalErrors
                );


        } catch (error) {

            lastError =
                "Fail-safe health check failed.";

        }


        return result;

    }


    // =========================================================
    // Response Health
    // =========================================================

    function getResponseHealth() {

        const result = {

            available: false,

            restricted: false,

            remainingTime: 0,

            responseCount: 0

        };


        try {

            if (
                !window.SmartClassSecurityResponse
            ) {

                return result;

            }


            if (
                typeof window
                    .SmartClassSecurityResponse
                    .getStatus !== "function"
            ) {

                return result;

            }


            const status =
                window
                    .SmartClassSecurityResponse
                    .getStatus();


            if (
                !status ||
                typeof status !== "object"
            ) {

                return result;

            }


            result.available = true;

            result.restricted =
                status.restricted === true;

            result.remainingTime =
                Math.max(
                    0,
                    safeNumber(
                        status.remainingTime
                    )
                );

            result.responseCount =
                safeNumber(
                    status.responseCount
                );


        } catch (error) {

            lastError =
                "Response health check failed.";

        }


        return result;

    }


    // =========================================================
    // Monitor Health
    // =========================================================

    function getMonitorHealth() {

        const result = {

            available: false,

            running: false,

            riskLevel: "UNKNOWN",

            riskScore: 0

        };


        try {

            if (
                !window.SmartClassSecurityMonitor
            ) {

                return result;

            }


            if (
                typeof window
                    .SmartClassSecurityMonitor
                    .getStatus !== "function"
            ) {

                return result;

            }


            const status =
                window
                    .SmartClassSecurityMonitor
                    .getStatus();


            result.available = true;

            result.running =
                status &&
                (
                    status.running === true ||
                    status.active === true
                );

            result.riskScore =
                clamp(
                    safeNumber(
                        status &&
                        status.riskScore
                    ),
                    0,
                    100
                );


            if (
                typeof window
                    .SmartClassSecurityMonitor
                    .getRiskLevel ===
                "function"
            ) {

                result.riskLevel =
                    String(
                        window
                            .SmartClassSecurityMonitor
                            .getRiskLevel()
                    );

            }


        } catch (error) {

            lastError =
                "Monitor health check failed.";

        }


        return result;

    }


    // =========================================================
    // Core Module Availability
    // =========================================================

    function getModuleHealth() {

        const required = [

            "SmartClassSecurityLog",

            "SmartClassSecurityRules",

            "SmartClassSecurityRate",

            "SmartClassSecurityMonitor",

            "SmartClassSecurityResponse",

            "SmartClassSecuritySettings",

            "SmartClassSecurityStorage",

            "SmartClassSecurityIntegrity",

            "SmartClassSecurityFailSafe"

        ];


        const modules = {};

        let available = 0;


        required.forEach(
            function (name) {

                const exists =
                    moduleExists(name);


                modules[name] =
                    exists;


                if (exists) {

                    available++;

                }

            }
        );


        return {

            total:
                required.length,

            available:
                available,

            missing:
                required.length -
                available,

            percentage:
                required.length > 0
                    ? Math.round(
                        (
                            available /
                            required.length
                        ) * 100
                    )
                    : 0,

            modules:
                modules

        };

    }


    // =========================================================
    // Calculate Health Score
    // =========================================================

    function calculateScore(
        settings,
        integrity,
        failsafe,
        response,
        monitor,
        modules
    ) {

        let score = 100;


        // Module availability
        score -=
            modules.missing * 8;


        // Settings
        if (
            !settings.available
        ) {

            score -= 15;

        } else {

            const disabledRatio =
                settings.total > 0
                    ? (
                        settings.disabled /
                        settings.total
                    )
                    : 0;


            score -=
                Math.round(
                    disabledRatio * 20
                );

        }


        // Integrity
        if (
            !integrity.available
        ) {

            score -= 15;

        } else {

            score -=
                Math.round(
                    (
                        100 -
                        integrity.score
                    ) * 0.30
                );

        }


        // Fail-safe
        if (
            !failsafe.available
        ) {

            score -= 10;

        }


        if (
            failsafe.mode === "LOCKDOWN"
        ) {

            score -= 35;

        } else if (
            failsafe.mode === "SAFE"
        ) {

            score -= 20;

        } else if (
            failsafe.mode === "CAUTIOUS"
        ) {

            score -= 8;

        }


        // Monitor
        if (
            !monitor.available
        ) {

            score -= 10;

        } else if (
            !monitor.running
        ) {

            score -= 10;

        }


        // Active restriction is not automatically
        // a failure; it means the response layer
        // is currently working.
        if (
            response.available &&
            response.restricted
        ) {

            score -= 3;

        }


        return clamp(
            Math.round(score),
            CONFIG.minimumScore,
            CONFIG.maximumScore
        );

    }


    // =========================================================
    // Determine Status
    // =========================================================

    function determineStatus(
        score,
        failsafe,
        integrity
    ) {

        if (
            score <
            CONFIG.criticalScore
        ) {

            return STATUS.CRITICAL;

        }


        if (
            failsafe.mode ===
            "LOCKDOWN"
        ) {

            return STATUS.CRITICAL;

        }


        if (
            integrity.status ===
            "COMPROMISED"
        ) {

            return STATUS.CRITICAL;

        }


        if (
            score <
            CONFIG.warningScore
        ) {

            return STATUS.WARNING;

        }


        if (
            score >= 90
        ) {

            return STATUS.EXCELLENT;

        }


        return STATUS.HEALTHY;

    }


    // =========================================================
    // Run Health Check
    // =========================================================

    function check() {

        checks++;

        lastCheckAt =
            Date.now();


        try {

            const settings =
                getSettingsHealth();


            const integrity =
                getIntegrityHealth();


            const failsafe =
                getFailSafeHealth();


            const response =
                getResponseHealth();


            const monitor =
                getMonitorHealth();


            const modules =
                getModuleHealth();


            const score =
                calculateScore(
                    settings,
                    integrity,
                    failsafe,
                    response,
                    monitor,
                    modules
                );


            const status =
                determineStatus(
                    score,
                    failsafe,
                    integrity
                );


            const report = {

                version:
                    VERSION,

                timestamp:
                    Date.now(),

                checkNumber:
                    checks,

                score:
                    score,

                status:
                    status,

                settings:
                    settings,

                integrity:
                    integrity,

                failsafe:
                    failsafe,

                response:
                    response,

                monitor:
                    monitor,

                modules:
                    modules

            };


            lastReport =
                report;


            history.push({
                timestamp:
                    report.timestamp,

                score:
                    score,

                status:
                    status
            });


            if (
                history.length >
                CONFIG.maxHistory
            ) {

                history =
                    history.slice(
                        -CONFIG.maxHistory
                    );

            }


            lastError = null;


            if (
                status ===
                STATUS.CRITICAL
            ) {

                log(
                    "CRITICAL",
                    "SECURITY_HEALTH_CRITICAL",
                    "سلامت کلی سیستم امنیتی بحرانی است.",
                    {
                        score:
                            score
                    }
                );

            } else if (
                status ===
                STATUS.WARNING
            ) {

                log(
                    "HIGH",
                    "SECURITY_HEALTH_WARNING",
                    "سلامت سیستم امنیتی نیاز به بررسی دارد.",
                    {
                        score:
                            score
                    }
                );

            }


            return report;

        } catch (error) {

            lastError =
                String(error);


            log(
                "CRITICAL",
                "SECURITY_HEALTH_ERROR",
                "خطا در بررسی سلامت سیستم امنیتی.",
                {
                    error:
                        lastError
                }
            );


            return {

                version:
                    VERSION,

                timestamp:
                    Date.now(),

                checkNumber:
                    checks,

                score:
                    0,

                status:
                    STATUS.UNKNOWN,

                error:
                    lastError

            };

        }

    }


    // =========================================================
    // Get Last Report
    // =========================================================

    function getLastReport() {

        if (
            !lastReport
        ) {

            return null;

        }


        try {

            return JSON.parse(
                JSON.stringify(
                    lastReport
                )
            );

        } catch (error) {

            return null;

        }

    }


    // =========================================================
    // Get History
    // =========================================================

    function getHistory() {

        try {

            return JSON.parse(
                JSON.stringify(
                    history
                )
            );

        } catch (error) {

            return [];

        }

    }


    // =========================================================
    // Get Status
    // =========================================================

    function getStatus() {

        return {

            version:
                VERSION,

            score:
                lastReport
                    ? lastReport.score
                    : null,

            status:
                lastReport
                    ? lastReport.status
                    : STATUS.UNKNOWN,

            checks:
                checks,

            lastCheckAt:
                lastCheckAt,

            lastError:
                lastError

        };

    }


    // =========================================================
    // Reset
    // =========================================================

    function reset() {

        lastReport = null;

        history = [];

        checks = 0;

        lastCheckAt = null;

        lastError = null;

        return true;

    }


    // =========================================================
    // Public API
    // =========================================================

    return {

        version:
            VERSION,

        statuses:
            { ...STATUS },

        check:
            check,

        getLastReport:
            getLastReport,

        getHistory:
            getHistory,

        getStatus:
            getStatus,

        reset:
            reset

    };

})();