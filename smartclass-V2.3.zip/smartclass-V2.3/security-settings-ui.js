"use strict";

window.SmartClassSecuritySettingsUI = (function () {

    const SETTINGS = {
        inputProtection: {
            title: "محافظت از ورودی‌ها",
            description:
                "ورودی‌های مشکوک را بررسی می‌کند و تلاش‌های خطرناک را شناسایی می‌کند."
        },

        rateLimiting: {
            title: "محدودسازی درخواست‌ها",
            description:
                "تعداد درخواست‌های سریع و غیرعادی را کنترل می‌کند تا از فعالیت بیش‌ازحد جلوگیری شود."
        },

        securityMonitor: {
            title: "مانیتور امنیتی",
            description:
                "فعالیت‌های مهم صفحه را بررسی می‌کند و رفتارهای غیرعادی را شناسایی می‌کند."
        },

        automaticResponse: {
            title: "واکنش خودکار",
            description:
                "در صورت شناسایی رفتار مشکوک، سیستم می‌تواند به‌صورت خودکار محدودیت امنیتی اعمال کند."
        },

        securityLogs: {
            title: "ثبت گزارش امنیتی",
            description:
                "رویدادهای امنیتی را ثبت می‌کند تا بتوان وضعیت و فعالیت‌های مشکوک را بررسی کرد."
        },

        csp: {
            title: "Content Security Policy",
            description:
                "یک لایه امنیتی برای محدودکردن منابع و رفتارهای مجاز صفحه فراهم می‌کند."
        },

        suspiciousAlerts: {
            title: "هشدار فعالیت مشکوک",
            description:
                "هنگام شناسایی فعالیت غیرعادی، وضعیت امنیتی را برای بررسی بیشتر مشخص می‌کند."
        },

        strictMode: {
            title: "حالت امنیتی سخت‌گیرانه",
            description:
                "چندین لایه امنیتی را با سیاست سخت‌گیرانه‌تری فعال می‌کند."
        }
    };

    function getInfo(name) {

        if (
            !Object.prototype.hasOwnProperty.call(
                SETTINGS,
                name
            )
        ) {
            return null;
        }

        return {
            ...SETTINGS[name]
        };
    }

    function getAllInfo() {
        return JSON.parse(
            JSON.stringify(SETTINGS)
        );
    }

    function getSettingState(name) {

        if (!window.SmartClassSecuritySettings) {
            return null;
        }

        return SmartClassSecuritySettings.get(name);
    }

    function toggle(name) {

        if (!window.SmartClassSecuritySettings) {
            return false;
        }

        return SmartClassSecuritySettings.toggle(name);
    }

    return {

        version: "1.0",

        getInfo,
        getAllInfo,
        getSettingState,
        toggle

    };

})();