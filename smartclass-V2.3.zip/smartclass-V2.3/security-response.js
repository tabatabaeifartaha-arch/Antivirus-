"use strict";

// ==========================================
// SmartClass Security Automatic Response
// Version 2.0
// ==========================================

window.SmartClassSecurityResponse = (function () {

    const VERSION = "2.0";

    const DEFAULT_DURATION = 5000;

    const MAX_RESTRICTION = 30000;

    const MIN_RESTRICTION = 1000;

    let restricted = false;

    let reason = null;

    let startedAt = null;

    let expiresAt = null;

    let timer = null;

    let responseCount = 0;

    let lastResponseAt = null;

    let lastError = null;


    // ==========================================
    // Safe Log
    // ==========================================

    function log(
        level,
        type,
        message,
        details
    ) {

        try {

            if (
                window.SmartClassSecurityLog &&
                typeof window.SmartClassSecurityLog.log ===
                "function"
            ) {

                window.SmartClassSecurityLog.log(
                    level,
                    type,
                    message,
                    details || {}
                );

            }

        } catch (error) {

            lastError =
                "Security log failed.";

            console.error(
                "Security Response Log Error:",
                error
            );

        }

    }


    // ==========================================
    // Safe Reason
    // ==========================================

    function normalizeReason(value) {

        try {

            const text =
                String(
                    value ||
                    "Suspicious activity detected."
                )
                .replace(/\s+/g, " ")
                .trim();

            if (!text) {

                return "Suspicious activity detected.";

            }

            return text.slice(0, 300);

        } catch (error) {

            return "Suspicious activity detected.";

        }

    }


    // ==========================================
    // Safe Duration
    // ==========================================

    function normalizeDuration(duration) {

        let value;

        try {

            value = Number(duration);

        } catch (error) {

            value = DEFAULT_DURATION;

        }

        if (
            !Number.isFinite(value) ||
            value <= 0
        ) {

            value = DEFAULT_DURATION;

        }

        value =
            Math.max(
                MIN_RESTRICTION,
                value
            );

        value =
            Math.min(
                MAX_RESTRICTION,
                value
            );

        return Math.floor(value);

    }


    // ==========================================
    // Clear Timer
    // ==========================================

    function clearTimer() {

        if (timer !== null) {

            try {

                clearTimeout(timer);

            } catch (error) {

                lastError =
                    "Restriction timer cleanup failed.";

            }

            timer = null;

        }

    }


    // ==========================================
    // Update UI
    // ==========================================

    function updateUI(status) {

        try {

            if (
                window.SmartClassSecurityUI &&
                typeof window.SmartClassSecurityUI.setStatus ===
                "function"
            ) {

                window.SmartClassSecurityUI.setStatus(
                    status
                );

            }

        } catch (error) {

            lastError =
                "Security UI update failed.";

        }

    }


    // ==========================================
    // Restrict
    // ==========================================

    function restrict(
        restrictionReason,
        duration
    ) {

        try {

            const safeReason =
                normalizeReason(
                    restrictionReason
                );

            const safeDuration =
                normalizeDuration(
                    duration
                );

            clearTimer();

            restricted = true;

            reason = safeReason;

            startedAt = Date.now();

            expiresAt =
                startedAt +
                safeDuration;

            responseCount += 1;

            lastResponseAt =
                startedAt;

            lastError = null;


            timer =
                setTimeout(
                    function () {

                        clearRestriction();

                    },
                    safeDuration
                );


            log(
                "HIGH",
                "AUTOMATIC_RESPONSE",
                "واکنش خودکار امنیتی فعال شد.",
                {
                    reason: safeReason,
                    duration: safeDuration,
                    responseCount: responseCount
                }
            );


            updateUI(
                "RESTRICTED"
            );


            return true;

        } catch (error) {

            lastError =
                "Automatic response failed.";

            log(
                "CRITICAL",
                "RESPONSE_ERROR",
                "خطا در واکنش خودکار امنیتی.",
                {
                    error:
                        String(error)
                }
            );

            return false;

        }

    }


    // ==========================================
    // Is Restricted
    // ==========================================

    function isRestricted() {

        try {

            if (
                restricted &&
                expiresAt !== null &&
                Date.now() >= expiresAt
            ) {

                clearRestriction();

            }

        } catch (error) {

            lastError =
                "Restriction status check failed.";

        }

        return restricted;

    }


    // ==========================================
    // Remaining Time
    // ==========================================

    function getRemainingTime() {

        if (!isRestricted()) {

            return 0;

        }

        if (!expiresAt) {

            return 0;

        }

        return Math.max(
            0,
            expiresAt - Date.now()
        );

    }


    // ==========================================
    // Clear Restriction
    // ==========================================

    function clearRestriction() {

        const wasRestricted =
            restricted;

        restricted = false;

        reason = null;

        startedAt = null;

        expiresAt = null;

        clearTimer();


        if (wasRestricted) {

            log(
                "INFO",
                "AUTOMATIC_RESPONSE_CLEARED",
                "محدودیت امنیتی خودکار پایان یافت."
            );

        }


        updateUI(
            "PROTECTED"
        );

    }


    // ==========================================
    // Get Statistics
    // ==========================================

    function getStatistics() {

        return {

            responseCount:
                responseCount,

            lastResponseAt:
                lastResponseAt,

            lastError:
                lastError

        };

    }


    // ==========================================
    // Get Status
    // ==========================================

    function getStatus() {

        return {

            version:
                VERSION,

            restricted:
                isRestricted(),

            reason:
                reason,

            startedAt:
                startedAt,

            expiresAt:
                expiresAt,

            remainingTime:
                getRemainingTime(),

            responseCount:
                responseCount,

            lastResponseAt:
                lastResponseAt,

            lastError:
                lastError

        };

    }


    // ==========================================
    // Reset Statistics
    // ==========================================

    function resetStatistics() {

        responseCount = 0;

        lastResponseAt = null;

        lastError = null;

        return true;

    }


    // ==========================================
    // Public API
    // ==========================================

    return {

        version:
            VERSION,

        restrict:
            restrict,

        isRestricted:
            isRestricted,

        clearRestriction:
            clearRestriction,

        getRemainingTime:
            getRemainingTime,

        getStatistics:
            getStatistics,

        resetStatistics:
            resetStatistics,

        getStatus:
            getStatus

    };

})();