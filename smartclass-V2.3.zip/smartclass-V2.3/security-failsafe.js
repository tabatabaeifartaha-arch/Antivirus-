"use strict";

// ============================================================
// SmartClass Security Fail-Safe
// Version 1.0
// ============================================================

window.SmartClassSecurityFailSafe = (function () {

    const VERSION = "1.0";

    const MODES = {
        NORMAL: "NORMAL",
        CAUTIOUS: "CAUTIOUS",
        SAFE: "SAFE",
        LOCKDOWN: "LOCKDOWN"
    };

    const CONFIG = {
        maxErrors: 100,
        safeThreshold: 3,
        lockdownThreshold: 10,
        errorWindow: 30000,
        maxReasonLength: 300
    };

    let mode = MODES.NORMAL;

    let errors = [];

    let totalErrors = 0;

    let lastError = null;

    let lastErrorAt = null;

    let startedAt = Date.now();


    // =========================================================
    // Safe String
    // =========================================================

    function safeString(value, maxLength) {

        try {

            return String(value)
                .replace(/\s+/g, " ")
                .trim()
                .slice(
                    0,
                    maxLength ||
                    CONFIG.maxReasonLength
                );

        } catch (error) {

            return "Unknown security error.";

        }

    }


    // =========================================================
    // Security Log
    // =========================================================

    function log(
        level,
        type,
        message,
        details
    ) {

        try {

            if (
                window.SmartClassSecurityLog &&
                typeof window.SmartClassSecurityLog.log ===
                "function"
            ) {

                window.SmartClassSecurityLog.log(
                    level,
                    type,
                    message,
                    details || {}
                );

            }

        } catch (error) {

            /*
             * Fail-safe must NEVER depend on
             * another security module.
             */

            console.error(
                "Fail-Safe Log Error:",
                error
            );

        }

    }


    // =========================================================
    // Clean Old Errors
    // =========================================================

    function cleanupErrors() {

        const now =
            Date.now();

        errors =
            errors.filter(
                function (item) {

                    return (
                        now -
                        item.timestamp
                        <=
                        CONFIG.errorWindow
                    );

                }
            );


        if (
            errors.length >
            CONFIG.maxErrors
        ) {

            errors =
                errors.slice(
                    -CONFIG.maxErrors
                );

        }

    }


    // =========================================================
    // Determine Mode
    // =========================================================

    function evaluateMode() {

        cleanupErrors();

        const recentErrors =
            errors.length;


        if (
            recentErrors >=
            CONFIG.lockdownThreshold
        ) {

            mode =
                MODES.LOCKDOWN;

            return mode;

        }


        if (
            recentErrors >=
            CONFIG.safeThreshold
        ) {

            mode =
                MODES.SAFE;

            return mode;

        }


        if (
            recentErrors > 0
        ) {

            mode =
                MODES.CAUTIOUS;

            return mode;

        }


        mode =
            MODES.NORMAL;

        return mode;

    }


    // =========================================================
    // Record Error
    // =========================================================

    function recordError(
        source,
        error,
        severity
    ) {

        try {

            const safeSource =
                safeString(
                    source ||
                    "unknown"
                );


            const safeError =
                safeString(
                    error instanceof Error
                        ? error.message
                        : error
                );


            const safeSeverity =
                safeString(
                    severity ||
                    "HIGH",
                    30
                );


            const item = {

                timestamp:
                    Date.now(),

                source:
                    safeSource,

                error:
                    safeError,

                severity:
                    safeSeverity

            };


            errors.push(item);

            totalErrors++;

            lastError =
                item.error;

            lastErrorAt =
                item.timestamp;


            evaluateMode();


            log(
                safeSeverity,
                "FAILSAFE_ERROR",
                "خطای امنیتی شناسایی شد.",
                {
                    source:
                        safeSource,

                    mode:
                        mode
                }
            );


            if (
                mode === MODES.LOCKDOWN
            ) {

                log(
                    "CRITICAL",
                    "FAILSAFE_LOCKDOWN",
                    "سیستم امنیتی وارد حالت Lockdown شد."
                );

            } else if (
                mode === MODES.SAFE
            ) {

                log(
                    "HIGH",
                    "FAILSAFE_SAFE_MODE",
                    "سیستم امنیتی وارد حالت Safe شد."
                );

            }


            return {

                recorded:
                    true,

                mode:
                    mode,

                totalErrors:
                    totalErrors

            };

        } catch (internalError) {

            /*
             * Absolute last-resort path.
             * Never throw from fail-safe.
             */

            console.error(
                "SmartClass Fail-Safe Internal Error:",
                internalError
            );


            return {

                recorded:
                    false,

                mode:
                    MODES.SAFE,

                totalErrors:
                    totalErrors

            };

        }

    }


    // =========================================================
    // Report External Error
    // =========================================================

    function reportError(
        source,
        error
    ) {

        return recordError(
            source,
            error,
            "HIGH"
        );

    }


    // =========================================================
    // Check Safe State
    // =========================================================

    function isSafe() {

        evaluateMode();

        return (
            mode !==
            MODES.LOCKDOWN
        );

    }


    // =========================================================
    // Is Restricted
    // =========================================================

    function shouldRestrict() {

        evaluateMode();

        return (
            mode === MODES.SAFE ||
            mode === MODES.LOCKDOWN
        );

    }


    // =========================================================
    // Manual Safe Mode
    // =========================================================

    function enterSafeMode(
        reason
    ) {

        mode =
            MODES.SAFE;


        const safeReason =
            safeString(
                reason ||
                "Manual safe mode."
            );


        log(
            "HIGH",
            "FAILSAFE_MANUAL_SAFE",
            "حالت Safe به‌صورت دستی فعال شد.",
            {
                reason:
                    safeReason
            }
        );


        return true;

    }


    // =========================================================
    // Manual Lockdown
    // =========================================================

    function enterLockdown(
        reason
    ) {

        mode =
            MODES.LOCKDOWN;


        const safeReason =
            safeString(
                reason ||
                "Security lockdown."
            );


        log(
            "CRITICAL",
            "FAILSAFE_MANUAL_LOCKDOWN",
            "حالت Lockdown امنیتی فعال شد.",
            {
                reason:
                    safeReason
            }
        );


        return true;

    }


    // =========================================================
    // Recover
    // =========================================================

    function recover() {

        errors = [];

        mode =
            MODES.NORMAL;

        lastError =
            null;

        lastErrorAt =
            null;


        log(
            "INFO",
            "FAILSAFE_RECOVERY",
            "سیستم امنیتی از حالت Fail-Safe خارج شد."
        );


        return true;

    }


    // =========================================================
    // Get Recent Errors
    // =========================================================

    function getErrors() {

        cleanupErrors();


        try {

            return JSON.parse(
                JSON.stringify(
                    errors
                )
            );

        } catch (error) {

            return [];

        }

    }


    // =========================================================
    // Get Status
    // =========================================================

    function getStatus() {

        evaluateMode();


        return {

            version:
                VERSION,

            mode:
                mode,

            safe:
                isSafe(),

            shouldRestrict:
                shouldRestrict(),

            totalErrors:
                totalErrors,

            recentErrors:
                errors.length,

            lastError:
                lastError,

            lastErrorAt:
                lastErrorAt,

            uptime:
                Date.now() -
                startedAt

        };

    }


    // =========================================================
    // Reset Statistics
    // =========================================================

    function resetStatistics() {

        errors = [];

        totalErrors = 0;

        lastError = null;

        lastErrorAt = null;

        mode =
            MODES.NORMAL;

        startedAt =
            Date.now();


        return true;

    }


    // =========================================================
    // Public API
    // =========================================================

    return {

        version:
            VERSION,

        modes:
            { ...MODES },

        recordError:
            recordError,

        reportError:
            reportError,

        isSafe:
            isSafe,

        shouldRestrict:
            shouldRestrict,

        enterSafeMode:
            enterSafeMode,

        enterLockdown:
            enterLockdown,

        recover:
            recover,

        getErrors:
            getErrors,

        getStatus:
            getStatus,

        resetStatistics:
            resetStatistics

    };

})();