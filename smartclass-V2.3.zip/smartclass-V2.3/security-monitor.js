"use strict";

// ==========================================
// SmartClass Security Monitor
// Version 3.0
// Advanced Behavioral Security Monitoring
// ==========================================

window.SmartClassSecurityMonitor = (function () {

    const VERSION = "3.0";

    let running = false;

    // ==========================================
    // Counters
    // ==========================================

    let eventCount = 0;
    let clickCount = 0;
    let inputCount = 0;
    let changeCount = 0;

    let eventWindowStart = 0;
    let clickWindowStart = 0;
    let inputWindowStart = 0;
    let changeWindowStart = 0;

    // ==========================================
    // Risk
    // ==========================================

    let riskScore = 0;
    let violations = 0;

    let lastEventTime = 0;
    let lastClickTime = 0;
    let lastInputTime = 0;
    let lastChangeTime = 0;

    // ==========================================
    // Timers
    // ==========================================

    let riskTimer = null;

    // ==========================================
    // Configuration
    // ==========================================

    const CONFIG = {

        maxEvents: 30,
        eventWindow: 10000,

        rapidClicks: 20,
        clickWindow: 3000,

        rapidInputs: 15,
        inputWindow: 3000,

        rapidChanges: 15,
        changeWindow: 5000,

        extremeEvents: 80,
        extremeWindow: 5000,

        repeatedInterval: 80,

        riskDecay: 5,
        riskDecayInterval: 10000,

        maxRiskScore: 100,

        responseThreshold: 80,

        maxViolations: 1000

    };

    // ==========================================
    // Safe Log
    // ==========================================

    function log(
        level,
        type,
        message,
        details
    ) {

        try {

            if (
                window.SmartClassSecurityLog &&
                typeof window.SmartClassSecurityLog.log ===
                "function"
            ) {

                window.SmartClassSecurityLog.log(
                    level,
                    type,
                    message,
                    details || {}
                );

            }

        } catch (error) {

            console.error(
                "Security Monitor Log Error:",
                error
            );

        }

    }

    // ==========================================
    // Safe Number
    // ==========================================

    function safeNumber(
        value,
        fallback
    ) {

        const number =
            Number(value);

        if (
            !Number.isFinite(number)
        ) {
            return fallback;
        }

        return number;

    }

    // ==========================================
    // Add Risk
    // ==========================================

    function addRisk(
        amount,
        reason
    ) {

        const safeAmount =
            Math.max(
                0,
                safeNumber(
                    amount,
                    0
                )
            );

        riskScore =
            Math.min(
                CONFIG.maxRiskScore,
                riskScore +
                safeAmount
            );

        violations =
            Math.min(
                CONFIG.maxViolations,
                violations + 1
            );

        if (
            riskScore >=
            CONFIG.responseThreshold
        ) {

            log(
                "HIGH",
                "HIGH_RISK_ACTIVITY",
                "فعالیت با ریسک بالا شناسایی شد.",
                {
                    riskScore:
                        riskScore,

                    reason:
                        reason,

                    violations:
                        violations
                }
            );

            triggerResponse(
                "HIGH_RISK_ACTIVITY"
            );

        } else if (
            riskScore >= 50
        ) {

            log(
                "MEDIUM",
                "SUSPICIOUS_BEHAVIOR",
                "رفتار مشکوک شناسایی شد.",
                {
                    riskScore:
                        riskScore,

                    reason:
                        reason,

                    violations:
                        violations
                }
            );

        }

    }

    // ==========================================
    // Automatic Response
    // ==========================================

    function triggerResponse(
        reason
    ) {

        try {

            if (
                window.SmartClassSecurityResponse &&
                typeof window.SmartClassSecurityResponse.restrict ===
                "function"
            ) {

                const duration =
                    Math.min(
                        30000,
                        5000 +
                        riskScore * 100
                    );

                window.SmartClassSecurityResponse.restrict(
                    reason,
                    duration
                );

            }

        } catch (error) {

            log(
                "CRITICAL",
                "MONITOR_RESPONSE_ERROR",
                "واکنش خودکار مانیتور با خطا مواجه شد.",
                {
                    message:
                        String(
                            error &&
                            error.message
                                ? error.message
                                : error
                        )
                }
            );

        }

    }

    // ==========================================
    // Reset Counters
    // ==========================================

    function resetEventCounter() {

        eventCount = 0;

        eventWindowStart =
            Date.now();

    }

    function resetClickCounter() {

        clickCount = 0;

        clickWindowStart =
            Date.now();

    }

    function resetInputCounter() {

        inputCount = 0;

        inputWindowStart =
            Date.now();

    }

    function resetChangeCounter() {

        changeCount = 0;

        changeWindowStart =
            Date.now();

    }

    // ==========================================
    // Rapid Activity Detection
    // ==========================================

    function detectRapidActivity(
        current,
        previousTime,
        reason
    ) {

        if (
            previousTime <= 0
        ) {
            return;
        }

        const interval =
            current -
            previousTime;

        if (
            interval >= 0 &&
            interval <
            CONFIG.repeatedInterval
        ) {

            addRisk(
                3,
                reason
            );

        }

    }

    // ==========================================
    // Click Monitoring
    // ==========================================

    function handleClick() {

        if (!running) {
            return;
        }

        const current =
            Date.now();

        if (
            current -
            clickWindowStart >=
            CONFIG.clickWindow
        ) {

            resetClickCounter();

        }

        clickCount++;

        detectRapidActivity(
            current,
            lastClickTime,
            "EXTREMELY_FAST_CLICKS"
        );

        lastClickTime =
            current;

        if (
            clickCount >=
            CONFIG.rapidClicks
        ) {

            addRisk(
                15,
                "RAPID_CLICKS"
            );

            log(
                "MEDIUM",
                "RAPID_CLICK_ACTIVITY",
                "فعالیت کلیکی سریع شناسایی شد.",
                {
                    count:
                        clickCount,

                    window:
                        CONFIG.clickWindow
                }
            );

            resetClickCounter();

        }

    }

    // ==========================================
    // Input Monitoring
    // ==========================================

    function handleInput() {

        if (!running) {
            return;
        }

        const current =
            Date.now();

        if (
            current -
            inputWindowStart >=
            CONFIG.inputWindow
        ) {

            resetInputCounter();

        }

        inputCount++;

        detectRapidActivity(
            current,
            lastInputTime,
            "EXTREMELY_FAST_INPUT"
        );

        lastInputTime =
            current;

        if (
            inputCount >=
            CONFIG.rapidInputs
        ) {

            addRisk(
                10,
                "RAPID_INPUT_ACTIVITY"
            );

            log(
                "MEDIUM",
                "RAPID_INPUT_ACTIVITY",
                "فعالیت ورودی سریع شناسایی شد.",
                {
                    count:
                        inputCount,

                    window:
                        CONFIG.inputWindow
                }
            );

            resetInputCounter();

        }

    }

    // ==========================================
    // Change Monitoring
    // ==========================================

    function handleChange() {

        if (!running) {
            return;
        }

        const current =
            Date.now();

        if (
            current -
            changeWindowStart >=
            CONFIG.changeWindow
        ) {

            resetChangeCounter();

        }

        changeCount++;

        detectRapidActivity(
            current,
            lastChangeTime,
            "EXTREMELY_FAST_CHANGES"
        );

        lastChangeTime =
            current;

        if (
            changeCount >=
            CONFIG.rapidChanges
        ) {

            addRisk(
                10,
                "RAPID_CHANGE_ACTIVITY"
            );

            log(
                "MEDIUM",
                "RAPID_CHANGE_ACTIVITY",
                "تغییرات سریع و غیرعادی شناسایی شد.",
                {
                    count:
                        changeCount,

                    window:
                        CONFIG.changeWindow
                }
            );

            resetChangeCounter();

        }

    }

    // ==========================================
    // General Event Monitoring
    // ==========================================

    function handleEvent() {

        if (!running) {
            return;
        }

        const current =
            Date.now();

        if (
            current -
            eventWindowStart >=
            CONFIG.eventWindow
        ) {

            resetEventCounter();

        }

        eventCount++;

        detectRapidActivity(
            current,
            lastEventTime,
            "EXTREMELY_FAST_EVENTS"
        );

        lastEventTime =
            current;

        // Extreme burst

        if (
            eventCount >=
            CONFIG.extremeEvents
        ) {

            addRisk(
                30,
                "EXTREME_EVENT_BURST"
            );

            log(
                "HIGH",
                "EXTREME_EVENT_BURST",
                "تعداد بسیار زیادی رویداد در مدت کوتاه شناسایی شد.",
                {
                    count:
                        eventCount,

                    window:
                        CONFIG.extremeWindow
                }
            );

            resetEventCounter();

            return;

        }

        // Normal burst

        if (
            eventCount >=
            CONFIG.maxEvents
        ) {

            addRisk(
                10,
                "EVENT_BURST"
            );

            log(
                "MEDIUM",
                "EVENT_BURST",
                "تعداد زیادی رویداد در مدت کوتاه شناسایی شد.",
                {
                    count:
                        eventCount,

                    window:
                        CONFIG.eventWindow
                }
            );

            resetEventCounter();

        }

    }

    // ==========================================
    // Risk Decay
    // ==========================================

    function decayRisk() {

        if (!running) {
            return;
        }

        if (
            riskScore > 0
        ) {

            riskScore =
                Math.max(
                    0,
                    riskScore -
                    CONFIG.riskDecay
                );

        }

        riskTimer =
            setTimeout(
                decayRisk,
                CONFIG.riskDecayInterval
            );

    }

    // ==========================================
    // Start
    // ==========================================

    function start() {

        if (running) {
            return;
        }

        try {

            running = true;

            riskScore = 0;
            violations = 0;

            resetEventCounter();
            resetClickCounter();
            resetInputCounter();
            resetChangeCounter();

            lastEventTime = 0;
            lastClickTime = 0;
            lastInputTime = 0;
            lastChangeTime = 0;

            document.addEventListener(
                "click",
                handleClick,
                true
            );

            document.addEventListener(
                "input",
                handleInput,
                true
            );

            document.addEventListener(
                "change",
                handleChange,
                true
            );

            document.addEventListener(
                "keydown",
                handleEvent,
                true
            );

            document.addEventListener(
                "submit",
                handleEvent,
                true
            );

            document.addEventListener(
                "focus",
                handleEvent,
                true
            );

            decayRisk();

            try {

                if (
                    window.SmartClassSecurityUI &&
                    typeof window.SmartClassSecurityUI.setState ===
                    "function"
                ) {

                    window.SmartClassSecurityUI.setState(
                        "monitoring",
                        true
                    );

                }

            } catch (error) {}

            log(
                "INFO",
                "MONITOR_STARTED",
                "مانیتور امنیتی SmartClass فعال شد.",
                {
                    version:
                        VERSION
                }
            );

            console.log(
                "SmartClass Security Monitor 3.0 Started"
            );

        } catch (error) {

            running = false;

            log(
                "CRITICAL",
                "MONITOR_START_ERROR",
                "راه‌اندازی مانیتور امنیتی با خطا مواجه شد.",
                {
                    message:
                        String(
                            error &&
                            error.message
                                ? error.message
                                : error
                        )
                }
            );

        }

    }

    // ==========================================
    // Stop
    // ==========================================

    function stop() {

        if (!running) {
            return;
        }

        running = false;

        document.removeEventListener(
            "click",
            handleClick,
            true
        );

        document.removeEventListener(
            "input",
            handleInput,
            true
        );

        document.removeEventListener(
            "change",
            handleChange,
            true
        );

        document.removeEventListener(
            "keydown",
            handleEvent,
            true
        );

        document.removeEventListener(
            "submit",
            handleEvent,
            true
        );

        document.removeEventListener(
            "focus",
            handleEvent,
            true
        );

        if (riskTimer) {

            clearTimeout(
                riskTimer
            );

            riskTimer = null;

        }

        try {

            if (
                window.SmartClassSecurityUI &&
                typeof window.SmartClassSecurityUI.setState ===
                "function"
            ) {

                window.SmartClassSecurityUI.setState(
                    "monitoring",
                    false
                );

            }

        } catch (error) {}

        log(
            "INFO",
            "MONITOR_STOPPED",
            "مانیتور امنیتی SmartClass متوقف شد.",
            {
                version:
                    VERSION
            }
        );

        console.log(
            "SmartClass Security Monitor 3.0 Stopped"
        );

    }

    // ==========================================
    // Status
    // ==========================================

    function getStatus() {

        return {

            version:
                VERSION,

            running:
                running,

            eventCount:
                eventCount,

            clickCount:
                clickCount,

            inputCount:
                inputCount,

            changeCount:
                changeCount,

            riskScore:
                riskScore,

            violations:
                violations,

            riskLevel:
                getRiskLevel(),

            lastEventTime:
                lastEventTime,

            lastClickTime:
                lastClickTime,

            lastInputTime:
                lastInputTime,

            lastChangeTime:
                lastChangeTime,

            config: {

                maxEvents:
                    CONFIG.maxEvents,

                eventWindow:
                    CONFIG.eventWindow,

                rapidClicks:
                    CONFIG.rapidClicks,

                clickWindow:
                    CONFIG.clickWindow,

                rapidInputs:
                    CONFIG.rapidInputs,

                inputWindow:
                    CONFIG.inputWindow,

                rapidChanges:
                    CONFIG.rapidChanges,

                changeWindow:
                    CONFIG.changeWindow,

                extremeEvents:
                    CONFIG.extremeEvents,

                extremeWindow:
                    CONFIG.extremeWindow,

                repeatedInterval:
                    CONFIG.repeatedInterval,

                riskDecay:
                    CONFIG.riskDecay,

                riskDecayInterval:
                    CONFIG.riskDecayInterval,

                maxRiskScore:
                    CONFIG.maxRiskScore

            }

        };

    }

    // ==========================================
    // Risk Level
    // ==========================================

    function getRiskLevel() {

        if (
            riskScore >= 80
        ) {
            return "CRITICAL";
        }

        if (
            riskScore >= 50
        ) {
            return "HIGH";
        }

        if (
            riskScore >= 25
        ) {
            return "MEDIUM";
        }

        if (
            riskScore > 0
        ) {
            return "LOW";
        }

        return "NORMAL";

    }

    // ==========================================
    // Public API
    // ==========================================

    return {

        version:
            VERSION,

        start:
            start,

        stop:
            stop,

        getStatus:
            getStatus,

        getRiskLevel:
            getRiskLevel

    };

})();