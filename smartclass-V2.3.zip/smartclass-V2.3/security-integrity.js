"use strict";

// ============================================================
// SmartClass Security Integrity
// Version 2.0
// ============================================================

window.SmartClassSecurityIntegrity = (function () {

    const VERSION = "2.0";

    const STATUS = {
        HEALTHY: "HEALTHY",
        WARNING: "WARNING",
        COMPROMISED: "COMPROMISED",
        ERROR: "ERROR"
    };

    const CONFIG = {
        maxChecks: 100,
        maxFailures: 50,
        criticalFailureScore: 70,
        compromisedScore: 40,
        warningScore: 15,
        checkTimeout: 3000
    };

    let lastReport = null;

    let lastCheckAt = null;

    let checkCount = 0;

    let failureCount = 0;

    let integrityScore = 100;

    let lastError = null;


    // =========================================================
    // Security Log
    // =========================================================

    function log(
        level,
        type,
        message,
        details
    ) {

        try {

            if (
                window.SmartClassSecurityLog &&
                typeof window.SmartClassSecurityLog.log ===
                "function"
            ) {

                window.SmartClassSecurityLog.log(
                    level,
                    type,
                    message,
                    details || {}
                );

            }

        } catch (error) {

            lastError =
                "Integrity logging failed.";

            console.error(
                "Integrity Log Error:",
                error
            );

        }

    }


    // =========================================================
    // Safe String
    // =========================================================

    function safeString(
        value,
        maxLength
    ) {

        try {

            return String(value)
                .slice(
                    0,
                    maxLength || 300
                );

        } catch (error) {

            return "";

        }

    }


    // =========================================================
    // Check Global Object
    // =========================================================

    function checkGlobal(
        name
    ) {

        const result = {
            name:
                name,

            exists:
                false,

            valid:
                false,

            type:
                null,

            methods:
                [],

            missingMethods:
                []
        };


        try {

            const object =
                window[name];


            if (
                !object
            ) {

                return result;

            }


            result.exists = true;

            result.type =
                typeof object;


            return result;

        } catch (error) {

            return result;

        }

    }


    // =========================================================
    // Required Security Modules
    // =========================================================

    const MODULES = [

        {
            name:
                "SmartClassSecurityLog",

            methods: [
                "log",
                "getLogs",
                "clearLogs",
                "countByLevel"
            ],

            critical:
                true
        },

        {
            name:
                "SmartClassSecurityRules",

            methods: [
                "checkInput",
                "analyzeInput",
                "isSafe"
            ],

            critical:
                true
        },

        {
            name:
                "SmartClassSecurityRate",

            methods: [
                "check",
                "reset",
                "getStatus"
            ],

            critical:
                true
        },

        {
            name:
                "SmartClassSecurityMonitor",

            methods: [
                "start",
                "stop",
                "getStatus",
                "getRiskLevel"
            ],

            critical:
                true
        },

        {
            name:
                "SmartClassSecurityResponse",

            methods: [
                "restrict",
                "isRestricted",
                "clearRestriction",
                "getStatus"
            ],

            critical:
                true
        },

        {
            name:
                "SmartClassSecuritySettings",

            methods: [
                "get",
                "set",
                "toggle",
                "getAll"
            ],

            critical:
                true
        },

        {
            name:
                "SmartClassSecurityStorage",

            methods: [
                "get",
                "set",
                "remove",
                "scan"
            ],

            critical:
                false
        },

        {
            name:
                "SmartClassSecurityCSP",

            methods: [
                "apply",
                "getStatus"
            ],

            critical:
                false
        },

        {
            name:
                "SmartClassSecurityUI",

            methods: [
                "setState",
                "setStatus",
                "getState"
            ],

            critical:
                false
        },

        {
            name:
                "SmartClassSecurityReport",

            methods: [
                "getSummary",
                "getLatest",
                "getFullReport"
            ],

            critical:
                false
        }

    ];


    // =========================================================
    // Check Module
    // =========================================================

    function inspectModule(
        definition
    ) {

        const result = {

            name:
                definition.name,

            critical:
                Boolean(
                    definition.critical
                ),

            exists:
                false,

            valid:
                false,

            missingMethods:
                [],

            availableMethods:
                [],

            error:
                null

        };


        try {

            const module =
                window[
                    definition.name
                ];


            if (
                !module
            ) {

                return result;

            }


            result.exists = true;


            if (
                typeof module !== "object" &&
                typeof module !== "function"
            ) {

                result.error =
                    "Invalid module type.";

                return result;

            }


            definition.methods.forEach(
                function (method) {

                    try {

                        if (
                            typeof module[method] ===
                            "function"
                        ) {

                            result.availableMethods
                                .push(method);

                        } else {

                            result.missingMethods
                                .push(method);

                        }

                    } catch (error) {

                        result.missingMethods
                            .push(method);

                    }

                }
            );


            result.valid =
                result.exists &&
                result.missingMethods.length === 0;


            return result;

        } catch (error) {

            result.error =
                safeString(error);

            return result;

        }

    }


    // =========================================================
    // Check Browser Environment
    // =========================================================

    function checkEnvironment() {

        const result = {

            window:
                false,

            document:
                false,

            localStorage:
                false,

            crypto:
                false,

            json:
                false,

            setTimeout:
                false,

            addEventListener:
                false

        };


        try {

            result.window =
                typeof window !== "undefined";

            result.document =
                typeof document !== "undefined";

            result.localStorage =
                Boolean(
                    window.localStorage
                );

            result.crypto =
                Boolean(
                    window.crypto
                );

            result.json =
                typeof JSON === "object" &&
                typeof JSON.stringify ===
                "function" &&
                typeof JSON.parse ===
                "function";

            result.setTimeout =
                typeof setTimeout ===
                "function";

            result.addEventListener =
                typeof window.addEventListener ===
                "function";

        } catch (error) {

            lastError =
                "Environment integrity check failed.";

        }


        return result;

    }


    // =========================================================
    // Check Critical APIs
    // =========================================================

    function checkCriticalAPIs() {

        const result = {

            rules:
                false,

            rate:
                false,

            monitor:
                false,

            response:
                false,

            settings:
                false,

            storage:
                false

        };


        try {

            result.rules =
                Boolean(
                    window.SmartClassSecurityRules &&
                    typeof window.SmartClassSecurityRules
                        .checkInput === "function"
                );


            result.rate =
                Boolean(
                    window.SmartClassSecurityRate &&
                    typeof window.SmartClassSecurityRate
                        .check === "function"
                );


            result.monitor =
                Boolean(
                    window.SmartClassSecurityMonitor &&
                    typeof window.SmartClassSecurityMonitor
                        .getStatus === "function"
                );


            result.response =
                Boolean(
                    window.SmartClassSecurityResponse &&
                    typeof window.SmartClassSecurityResponse
                        .restrict === "function"
                );


            result.settings =
                Boolean(
                    window.SmartClassSecuritySettings &&
                    typeof window.SmartClassSecuritySettings
                        .getAll === "function"
                );


            result.storage =
                Boolean(
                    window.SmartClassSecurityStorage &&
                    typeof window.SmartClassSecurityStorage
                        .scan === "function"
                );

        } catch (error) {

            lastError =
                "Critical API inspection failed.";

        }


        return result;

    }


    // =========================================================
    // Check Settings Integrity
    // =========================================================

    function checkSettings() {

        const result = {

            available:
                false,

            valid:
                false,

            settings:
                null,

            invalid:
                []

        };


        try {

            if (
                !window.SmartClassSecuritySettings ||
                typeof window.SmartClassSecuritySettings
                    .getAll !== "function"
            ) {

                return result;

            }


            result.available = true;


            const settings =
                window.SmartClassSecuritySettings
                    .getAll();


            if (
                !settings ||
                typeof settings !== "object"
            ) {

                return result;

            }


            result.settings =
                { ...settings };


            const expected = [

                "inputProtection",
                "rateLimiting",
                "securityMonitor",
                "automaticResponse",
                "securityLogs",
                "csp",
                "suspiciousAlerts",
                "strictMode"

            ];


            expected.forEach(
                function (key) {

                    if (
                        typeof settings[key] !==
                        "boolean"
                    ) {

                        result.invalid
                            .push(key);

                    }

                }
            );


            result.valid =
                result.invalid.length === 0;


        } catch (error) {

            result.invalid
                .push("SETTINGS_ERROR");

        }


        return result;

    }


    // =========================================================
    // Check Security Storage
    // =========================================================

    function checkStorage() {

        const result = {

            available:
                false,

            scan:
                null,

            suspicious:
                false

        };


        try {

            if (
                !window.SmartClassSecurityStorage ||
                typeof window.SmartClassSecurityStorage
                    .scan !== "function"
            ) {

                return result;

            }


            result.available = true;


            result.scan =
                window.SmartClassSecurityStorage
                    .scan();


            result.suspicious =
                Boolean(
                    result.scan &&
                    result.scan.suspiciousItems > 0
                );

        } catch (error) {

            result.suspicious = true;

            lastError =
                "Security storage integrity check failed.";

        }


        return result;

    }


    // =========================================================
    // Calculate Integrity Score
    // =========================================================

    function calculateScore(
        modules,
        environment,
        apis,
        settings,
        storage
    ) {

        let score = 100;


        modules.forEach(
            function (module) {

                if (
                    !module.exists
                ) {

                    score -=
                        module.critical
                            ? 25
                            : 8;

                } else if (
                    !module.valid
                ) {

                    score -=
                        module.critical
                            ? 20
                            : 6;

                }

            }
        );


        if (
            !environment.window ||
            !environment.document ||
            !environment.json
        ) {

            score -= 20;

        }


        if (
            !environment.localStorage
        ) {

            score -= 10;

        }


        Object.keys(apis).forEach(
            function (key) {

                if (
                    !apis[key]
                ) {

                    score -= 8;

                }

            }
        );


        if (
            !settings.available ||
            !settings.valid
        ) {

            score -= 15;

        }


        if (
            storage.suspicious
        ) {

            score -= 20;

        }


        return Math.max(
            0,
            Math.min(
                100,
                score
            )
        );

    }


    // =========================================================
    // Determine Status
    // =========================================================

    function determineStatus(
        score,
        criticalFailures
    ) {

        if (
            criticalFailures > 0 ||
            score < CONFIG.compromisedScore
        ) {

            return STATUS.COMPROMISED;

        }


        if (
            score < CONFIG.warningScore
        ) {

            return STATUS.WARNING;

        }


        return STATUS.HEALTHY;

    }


    // =========================================================
    // Full Integrity Check
    // =========================================================

    function check() {

        checkCount++;

        lastCheckAt =
            Date.now();

        try {

            const modules =
                MODULES.map(
                    inspectModule
                );


            const environment =
                checkEnvironment();


            const apis =
                checkCriticalAPIs();


            const settings =
                checkSettings();


            const storage =
                checkStorage();


            let criticalFailures = 0;


            modules.forEach(
                function (module) {

                    if (
                        module.critical &&
                        !module.valid
                    ) {

                        criticalFailures++;

                    }

                }
            );


            integrityScore =
                calculateScore(
                    modules,
                    environment,
                    apis,
                    settings,
                    storage
                );


            const status =
                determineStatus(
                    integrityScore,
                    criticalFailures
                );


            const failedModules =
                modules
                    .filter(
                        function (module) {
                            return !module.valid;
                        }
                    )
                    .map(
                        function (module) {
                            return module.name;
                        }
                    );


            if (
                failedModules.length > 0
            ) {

                failureCount +=
                    failedModules.length;

            }


            const report = {

                version:
                    VERSION,

                status:
                    status,

                score:
                    integrityScore,

                timestamp:
                    Date.now(),

                checkCount:
                    checkCount,

                criticalFailures:
                    criticalFailures,

                failedModules:
                    failedModules,

                modules:
                    modules,

                environment:
                    environment,

                apis:
                    apis,

                settings:
                    settings,

                storage:
                    storage

            };


            lastReport =
                report;

            lastError = null;


            if (
                status === STATUS.COMPROMISED
            ) {

                log(
                    "CRITICAL",
                    "INTEGRITY_COMPROMISED",
                    "یکپارچگی سیستم امنیتی مشکوک یا مختل شده است.",
                    {
                        score:
                            integrityScore,

                        failedModules:
                            failedModules
                    }
                );

            } else if (
                status === STATUS.WARNING
            ) {

                log(
                    "HIGH",
                    "INTEGRITY_WARNING",
                    "هشدار یکپارچگی سیستم امنیتی.",
                    {
                        score:
                            integrityScore
                    }
                );

            }


            return report;

        } catch (error) {

            failureCount++;

            integrityScore = 0;

            lastError =
                safeString(error);


            log(
                "CRITICAL",
                "INTEGRITY_CHECK_ERROR",
                "خطای جدی هنگام بررسی یکپارچگی امنیتی.",
                {
                    error:
                        lastError
                }
            );


            return {

                version:
                    VERSION,

                status:
                    STATUS.ERROR,

                score:
                    0,

                timestamp:
                    Date.now(),

                error:
                    lastError

            };

        }

    }


    // =========================================================
    // Quick Check
    // =========================================================

    function quickCheck() {

        try {

            const result = {

                rules:
                    Boolean(
                        window.SmartClassSecurityRules
                    ),

                rate:
                    Boolean(
                        window.SmartClassSecurityRate
                    ),

                monitor:
                    Boolean(
                        window.SmartClassSecurityMonitor
                    ),

                response:
                    Boolean(
                        window.SmartClassSecurityResponse
                    ),

                settings:
                    Boolean(
                        window.SmartClassSecuritySettings
                    ),

                storage:
                    Boolean(
                        window.SmartClassSecurityStorage
                    )

            };


            result.healthy =
                Object.keys(result)
                    .every(
                        function (key) {

                            if (
                                key === "healthy"
                            ) {

                                return true;

                            }

                            return result[key] === true;

                        }
                    );


            return result;

        } catch (error) {

            return {
                healthy:
                    false,

                error:
                    true
            };

        }

    }


    // =========================================================
    // Get Last Report
    // =========================================================

    function getLastReport() {

        if (
            !lastReport
        ) {

            return null;

        }


        try {

            return JSON.parse(
                JSON.stringify(
                    lastReport
                )
            );

        } catch (error) {

            return null;

        }

    }


    // =========================================================
    // Get Status
    // =========================================================

    function getStatus() {

        return {

            version:
                VERSION,

            score:
                integrityScore,

            lastCheckAt:
                lastCheckAt,

            checkCount:
                checkCount,

            failureCount:
                failureCount,

            lastError:
                lastError,

            status:
                lastReport
                    ? lastReport.status
                    : "NOT_CHECKED"

        };

    }


    // =========================================================
    // Reset
    // =========================================================

    function reset() {

        lastReport = null;

        lastCheckAt = null;

        checkCount = 0;

        failureCount = 0;

        integrityScore = 100;

        lastError = null;

        return true;

    }


    // =========================================================
    // Public API
    // =========================================================

    return {

        version:
            VERSION,

        check:
            check,

        quickCheck:
            quickCheck,

        getLastReport:
            getLastReport,

        getStatus:
            getStatus,

        reset:
            reset

    };

})();