"use strict";

// ==========================================
// SmartClass Security Storage
// Version 1.0
// ==========================================

window.SmartClassSecurityStorage = (function () {

    const VERSION = "1.0";

    const PREFIX = "smartclass_";

    const CONFIG = {
        maxKeyLength: 120,
        maxValueLength: 500000,
        maxJsonDepth: 12,
        maxArrayLength: 10000,
        maxObjectKeys: 1000,
        maxStoredItems: 500,
        suspiciousKeyLimit: 5
    };

    let statistics = {
        reads: 0,
        writes: 0,
        removes: 0,
        blocked: 0,
        invalid: 0,
        errors: 0
    };


    // ==========================================
    // Safe Log
    // ==========================================

    function log(level, type, message, details) {

        try {

            if (
                window.SmartClassSecurityLog &&
                typeof window.SmartClassSecurityLog.log === "function"
            ) {

                window.SmartClassSecurityLog.log(
                    level,
                    type,
                    message,
                    details || {}
                );

            }

        } catch (error) {

            console.error(
                "SmartClass Storage Log Error:",
                error
            );

        }

    }


    // ==========================================
    // Safe String
    // ==========================================

    function safeString(value, maxLength) {

        try {

            const text = String(value);

            return text.slice(
                0,
                maxLength || CONFIG.maxValueLength
            );

        } catch (error) {

            return "";

        }

    }


    // ==========================================
    // Validate Key
    // ==========================================

    function validateKey(key) {

        const result = {
            valid: false,
            key: "",
            reason: null
        };

        try {

            const normalized =
                String(key)
                    .normalize("NFKC")
                    .trim();

            if (!normalized) {

                result.reason =
                    "Storage key is empty.";

                return result;

            }

            if (
                normalized.length >
                CONFIG.maxKeyLength
            ) {

                result.reason =
                    "Storage key is too long.";

                return result;

            }

            /*
             * SmartClass storage keys should use
             * the application's namespace.
             */

            if (
                !normalized.startsWith(PREFIX)
            ) {

                result.reason =
                    "Storage key is outside SmartClass namespace.";

                return result;

            }

            /*
             * Reject control characters.
             */

            if (
                /[\u0000-\u001F\u007F]/.test(
                    normalized
                )
            ) {

                result.reason =
                    "Storage key contains control characters.";

                return result;

            }

            result.valid = true;

            result.key = normalized;

            return result;

        } catch (error) {

            result.reason =
                "Storage key validation failed.";

            return result;

        }

    }


    // ==========================================
    // Calculate Object Depth
    // ==========================================

    function getDepth(
        value,
        depth,
        seen
    ) {

        depth =
            Number.isFinite(depth)
                ? depth
                : 0;

        seen =
            seen ||
            new WeakSet();


        if (
            value === null ||
            typeof value !== "object"
        ) {

            return depth;

        }


        if (depth > CONFIG.maxJsonDepth) {

            return depth;

        }


        if (seen.has(value)) {

            return CONFIG.maxJsonDepth + 1;

        }

        seen.add(value);


        let maximum =
            depth;


        if (Array.isArray(value)) {

            if (
                value.length >
                CONFIG.maxArrayLength
            ) {

                return CONFIG.maxJsonDepth + 1;

            }


            for (
                let i = 0;
                i < value.length;
                i++
            ) {

                const childDepth =
                    getDepth(
                        value[i],
                        depth + 1,
                        seen
                    );

                maximum =
                    Math.max(
                        maximum,
                        childDepth
                    );

                if (
                    maximum >
                    CONFIG.maxJsonDepth
                ) {

                    return maximum;

                }

            }

        } else {

            const keys =
                Object.keys(value);

            if (
                keys.length >
                CONFIG.maxObjectKeys
            ) {

                return CONFIG.maxJsonDepth + 1;

            }


            for (
                let i = 0;
                i < keys.length;
                i++
            ) {

                const childDepth =
                    getDepth(
                        value[keys[i]],
                        depth + 1,
                        seen
                    );

                maximum =
                    Math.max(
                        maximum,
                        childDepth
                    );

                if (
                    maximum >
                    CONFIG.maxJsonDepth
                ) {

                    return maximum;

                }

            }

        }


        return maximum;

    }


    // ==========================================
    // Validate Value
    // ==========================================

    function validateValue(value) {

        const result = {
            valid: false,
            serialized: null,
            reason: null
        };

        try {

            if (
                typeof value === "function" ||
                typeof value === "symbol"
            ) {

                result.reason =
                    "Unsupported storage value type.";

                return result;

            }


            if (
                value === undefined
            ) {

                result.reason =
                    "Undefined values are not allowed.";

                return result;

            }


            if (
                value !== null &&
                typeof value === "object"
            ) {

                const depth =
                    getDepth(
                        value,
                        0
                    );

                if (
                    depth >
                    CONFIG.maxJsonDepth
                ) {

                    result.reason =
                        "Storage object is too deeply nested.";

                    return result;

                }

            }


            const serialized =
                JSON.stringify(value);


            if (
                typeof serialized !== "string"
            ) {

                result.reason =
                    "Value serialization failed.";

                return result;

            }


            if (
                serialized.length >
                CONFIG.maxValueLength
            ) {

                result.reason =
                    "Storage value is too large.";

                return result;

            }


            result.valid = true;

            result.serialized =
                serialized;

            return result;

        } catch (error) {

            result.reason =
                "Storage value validation failed.";

            return result;

        }

    }


    // ==========================================
    // Detect Suspicious Stored Data
    // ==========================================

    function inspectSerializedValue(
        serialized
    ) {

        const result = {
            suspicious: false,
            score: 0,
            reasons: []
        };

        try {

            const value =
                String(serialized || "");


            /*
             * Null bytes / control characters
             */

            if (
                /[\u0000]/.test(value)
            ) {

                result.suspicious = true;

                result.score += 30;

                result.reasons.push(
                    "NULL_BYTE"
                );

            }


            /*
             * Extremely long encoded data
             */

            if (
                value.length >
                100000
            ) {

                result.suspicious = true;

                result.score += 20;

                result.reasons.push(
                    "LARGE_PAYLOAD"
                );

            }


            /*
             * Common executable HTML patterns.
             * This is detection only; it does not execute anything.
             */

            const patterns = [

                /<script\b/i,

                /javascript\s*:/i,

                /vbscript\s*:/i,

                /<iframe\b/i,

                /<object\b/i,

                /<embed\b/i,

                /onerror\s*=/i,

                /onload\s*=/i,

                /onclick\s*=/i,

                /eval\s*\(/i,

                /Function\s*\(/i,

                /data\s*:\s*text\/html/i

            ];


            patterns.forEach(
                function (pattern) {

                    if (
                        pattern.test(value)
                    ) {

                        result.suspicious = true;

                        result.score += 10;

                        result.reasons.push(
                            "SUSPICIOUS_PATTERN"
                        );

                    }

                }
            );


            result.score =
                Math.min(
                    result.score,
                    100
                );


            return result;

        } catch (error) {

            result.suspicious = true;

            result.score = 100;

            result.reasons.push(
                "INSPECTION_ERROR"
            );

            return result;

        }

    }


    // ==========================================
    // Get Storage
    // ==========================================

    function getStorage() {

        try {

            if (
                typeof window === "undefined" ||
                !window.localStorage
            ) {

                return null;

            }

            return window.localStorage;

        } catch (error) {

            statistics.errors++;

            log(
                "CRITICAL",
                "STORAGE_ACCESS_ERROR",
                "دسترسی به localStorage ممکن نیست."
            );

            return null;

        }

    }


    // ==========================================
    // Get
    // ==========================================

    function get(key, fallback) {

        statistics.reads++;

        const validation =
            validateKey(key);


        if (!validation.valid) {

            statistics.blocked++;

            log(
                "MEDIUM",
                "STORAGE_READ_BLOCKED",
                "خواندن کلید ذخیره‌سازی مسدود شد.",
                {
                    reason:
                        validation.reason
                }
            );

            return fallback;

        }


        const storage =
            getStorage();


        if (!storage) {

            return fallback;

        }


        try {

            const raw =
                storage.getItem(
                    validation.key
                );


            if (raw === null) {

                return fallback;

            }


            if (
                raw.length >
                CONFIG.maxValueLength
            ) {

                statistics.blocked++;

                log(
                    "HIGH",
                    "STORAGE_VALUE_BLOCKED",
                    "داده ذخیره‌شده بیش از حد مجاز است.",
                    {
                        key:
                            validation.key
                    }
                );

                return fallback;

            }


            const inspection =
                inspectSerializedValue(
                    raw
                );


            if (
                inspection.score >= 70
            ) {

                statistics.blocked++;

                log(
                    "HIGH",
                    "SUSPICIOUS_STORAGE_DATA",
                    "داده مشکوک در storage شناسایی شد.",
                    {
                        key:
                            validation.key,
                        score:
                            inspection.score,
                        reasons:
                            inspection.reasons
                    }
                );

                return fallback;

            }


            try {

                return JSON.parse(raw);

            } catch (jsonError) {

                statistics.invalid++;

                log(
                    "MEDIUM",
                    "STORAGE_INVALID_JSON",
                    "داده ذخیره‌شده JSON معتبر نیست.",
                    {
                        key:
                            validation.key
                    }
                );

                return fallback;

            }

        } catch (error) {

            statistics.errors++;

            log(
                "HIGH",
                "STORAGE_READ_ERROR",
                "خطا هنگام خواندن داده ذخیره‌شده.",
                {
                    key:
                        validation.key
                }
            );

            return fallback;

        }

    }


    // ==========================================
    // Set
    // ==========================================

    function set(key, value) {

        statistics.writes++;

        const validation =
            validateKey(key);


        if (!validation.valid) {

            statistics.blocked++;

            log(
                "MEDIUM",
                "STORAGE_WRITE_BLOCKED",
                "نوشتن کلید ذخیره‌سازی مسدود شد.",
                {
                    reason:
                        validation.reason
                }
            );

            return false;

        }


        const valueValidation =
            validateValue(value);


        if (!valueValidation.valid) {

            statistics.blocked++;

            log(
                "HIGH",
                "STORAGE_VALUE_REJECTED",
                "داده نامعتبر برای ذخیره‌سازی رد شد.",
                {
                    key:
                        validation.key,
                    reason:
                        valueValidation.reason
                }
            );

            return false;

        }


        const inspection =
            inspectSerializedValue(
                valueValidation.serialized
            );


        if (
            inspection.score >= 90
        ) {

            statistics.blocked++;

            log(
                "CRITICAL",
                "STORAGE_WRITE_BLOCKED",
                "نوشتن داده با ریسک بسیار بالا مسدود شد.",
                {
                    key:
                        validation.key,
                    score:
                        inspection.score,
                    reasons:
                        inspection.reasons
                }
            );

            return false;

        }


        const storage =
            getStorage();


        if (!storage) {

            return false;

        }


        try {

            storage.setItem(
                validation.key,
                valueValidation.serialized
            );

            return true;

        } catch (error) {

            statistics.errors++;

            log(
                "HIGH",
                "STORAGE_WRITE_ERROR",
                "خطا هنگام نوشتن داده.",
                {
                    key:
                        validation.key
                }
            );

            return false;

        }

    }


    // ==========================================
    // Remove
    // ==========================================

    function remove(key) {

        statistics.removes++;

        const validation =
            validateKey(key);


        if (!validation.valid) {

            statistics.blocked++;

            return false;

        }


        const storage =
            getStorage();


        if (!storage) {

            return false;

        }


        try {

            storage.removeItem(
                validation.key
            );

            return true;

        } catch (error) {

            statistics.errors++;

            log(
                "HIGH",
                "STORAGE_REMOVE_ERROR",
                "خطا هنگام حذف داده.",
                {
                    key:
                        validation.key
                }
            );

            return false;

        }

    }


    // ==========================================
    // Exists
    // ==========================================

    function exists(key) {

        const validation =
            validateKey(key);


        if (!validation.valid) {

            return false;

        }


        const storage =
            getStorage();


        if (!storage) {

            return false;

        }


        try {

            return (
                storage.getItem(
                    validation.key
                ) !== null
            );

        } catch (error) {

            statistics.errors++;

            return false;

        }

    }


    // ==========================================
    // Scan SmartClass Storage
    // ==========================================

    function scan() {

        const storage =
            getStorage();


        const report = {
            version:
                VERSION,

            available:
                Boolean(storage),

            totalItems: 0,

            suspiciousItems: 0,

            oversizedItems: 0,

            invalidJsonItems: 0,

            items: []
        };


        if (!storage) {

            return report;

        }


        try {

            const total =
                storage.length;


            for (
                let i = 0;
                i < total;
                i++
            ) {

                if (
                    report.totalItems >=
                    CONFIG.maxStoredItems
                ) {

                    break;

                }


                const key =
                    storage.key(i);


                if (
                    typeof key !== "string" ||
                    !key.startsWith(PREFIX)
                ) {

                    continue;

                }


                report.totalItems++;


                const raw =
                    storage.getItem(key) || "";


                const item = {

                    key:
                        safeString(
                            key,
                            CONFIG.maxKeyLength
                        ),

                    size:
                        raw.length,

                    suspicious:
                        false,

                    score:
                        0,

                    validJson:
                        false
                };


                if (
                    raw.length >
                    CONFIG.maxValueLength
                ) {

                    item.oversized = true;

                    report.oversizedItems++;

                }


                const inspection =
                    inspectSerializedValue(
                        raw
                    );


                item.suspicious =
                    inspection.suspicious;

                item.score =
                    inspection.score;


                if (
                    item.suspicious
                ) {

                    report.suspiciousItems++;

                }


                try {

                    JSON.parse(raw);

                    item.validJson = true;

                } catch (error) {

                    report.invalidJsonItems++;

                }


                report.items.push(item);

            }


            return report;

        } catch (error) {

            statistics.errors++;

            log(
                "HIGH",
                "STORAGE_SCAN_ERROR",
                "خطا هنگام اسکن storage."
            );

            return report;

        }

    }


    // ==========================================
    // Clear SmartClass Storage
    // ==========================================

    function clearNamespace() {

        const storage =
            getStorage();


        if (!storage) {

            return false;

        }


        const keys = [];


        try {

            for (
                let i = 0;
                i < storage.length;
                i++
            ) {

                const key =
                    storage.key(i);


                if (
                    typeof key === "string" &&
                    key.startsWith(PREFIX)
                ) {

                    keys.push(key);

                }

            }


            keys.forEach(
                function (key) {

                    storage.removeItem(key);

                }
            );


            log(
                "INFO",
                "STORAGE_NAMESPACE_CLEARED",
                "داده‌های SmartClass پاک شدند.",
                {
                    count:
                        keys.length
                }
            );


            return true;

        } catch (error) {

            statistics.errors++;

            return false;

        }

    }


    // ==========================================
    // Statistics
    // ==========================================

    function getStatistics() {

        return {
            version:
                VERSION,

            ...statistics
        };

    }


    // ==========================================
    // Reset Statistics
    // ==========================================

    function resetStatistics() {

        statistics = {
            reads: 0,
            writes: 0,
            removes: 0,
            blocked: 0,
            invalid: 0,
            errors: 0
        };

        return true;

    }


    // ==========================================
    // Configuration
    // ==========================================

    function getConfig() {

        return {
            ...CONFIG
        };

    }


    // ==========================================
    // Public API
    // ==========================================

    return {

        version:
            VERSION,

        get:
            get,

        set:
            set,

        remove:
            remove,

        exists:
            exists,

        scan:
            scan,

        clearNamespace:
            clearNamespace,

        getStatistics:
            getStatistics,

        resetStatistics:
            resetStatistics,

        getConfig:
            getConfig

    };

})();