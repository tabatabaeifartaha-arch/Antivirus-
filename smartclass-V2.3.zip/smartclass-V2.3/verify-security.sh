#!/data/data/com.termux/files/usr/bin/bash

set -e

PROJECT_DIR="/storage/emulated/0/Khoram project/smartclass-V2.3/smartclass-V2.3"

KEY_DIR="$HOME/.smartclass-security/keys"
PUBLIC_KEY="$KEY_DIR/smartclass-public.pem"
SIGN_DIR="$HOME/.smartclass-security/signatures"

cd "$PROJECT_DIR"

if [ ! -f "$PUBLIC_KEY" ]; then
    echo "ERROR: Public key not found."
    exit 1
fi

echo "=================================="
echo " SmartClass Integrity Verification"
echo "=================================="
echo

failed=0

for file in security-*.js; do

    [ -f "$file" ] || continue

    signature="$SIGN_DIR/$file.sig"

    if [ ! -f "$signature" ]; then
        echo "[MISSING] $file"
        failed=1
        continue
    fi

    if openssl dgst \
        -sha256 \
        -verify "$PUBLIC_KEY" \
        -signature "$signature" \
        "$file" >/dev/null 2>&1
    then
        echo "[VALID]   $file"
    else
        echo "[MODIFIED] $file"
        failed=1
    fi

done

echo

if [ "$failed" -eq 0 ]; then
    echo "RESULT: ALL SECURITY FILES ARE VALID"
    exit 0
else
    echo "RESULT: SECURITY INTEGRITY VIOLATION DETECTED"
    exit 2
fi
