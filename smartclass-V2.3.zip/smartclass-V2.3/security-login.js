"use strict";

/* =========================================================
   SmartClass
   Login Security Layer
   =========================================================

   این فایل یک لایه دفاعی برای صفحه ورود مدیریت است.

   وظایف:
   - بررسی وضعیت امنیتی
   - جلوگیری از اجرای چندباره
   - بررسی Session/Storage
   - کنترل وضعیت Login
   - ثبت رویدادهای امنیتی
   - هماهنگی با Security Core
   - Fail-safe در صورت خطا

   توجه:
   احراز هویت واقعی همچنان باید سمت سرور انجام شود.
========================================================= */


(function () {


    const LoginSecurity = {

        initialized: false,

        failedChecks: 0,

        maxFailedChecks: 3,


        /* =====================================================
           Logger
        ===================================================== */

        log: function (
            event,
            message,
            level
        ) {

            try {

                if (
                    window.SmartClassSecurityLog
                ) {

                    const logger =
                        window.SmartClassSecurityLog;


                    const method =
                        String(
                            level || "INFO"
                        ).toLowerCase();


                    if (
                        typeof logger[method] ===
                        "function"
                    ) {

                        logger[method](
                            event,
                            message
                        );

                        return;

                    }


                    if (
                        typeof logger.info ===
                        "function"
                    ) {

                        logger.info(
                            event,
                            message
                        );

                    }

                }

            } catch (error) {

                /*
                 * Fail-safe:
                 * خطای Logger نباید صفحه را متوقف کند.
                 */

            }

        },


        /* =====================================================
           بررسی محیط
        ===================================================== */

        checkEnvironment: function () {

            try {

                if (
                    typeof window ===
                    "undefined"
                ) {

                    return false;

                }


                if (
                    typeof document ===
                    "undefined"
                ) {

                    return false;

                }


                return true;

            } catch (error) {

                return false;

            }

        },


        /* =====================================================
           بررسی Storage
        ===================================================== */

        checkStorage: function () {

            try {

                const testKey =
                    "__smartclass_login_security_test__";


                localStorage.setItem(
                    testKey,
                    "1"
                );


                localStorage.removeItem(
                    testKey
                );


                return true;

            } catch (error) {

                this.log(
                    "LOGIN_STORAGE_CHECK_FAILED",
                    "Storage صفحه ورود قابل استفاده نیست.",
                    "MEDIUM"
                );


                return false;

            }

        },


        /* =====================================================
           بررسی Login State
        ===================================================== */

        checkLoginState: function () {

            try {

                const loggedIn =
                    localStorage.getItem(
                        "admin_logged_in"
                    );


                /*
                 * اگر قبلاً وارد شده باشد،
                 * دوباره در صفحه Login ماندن لازم نیست.
                 */

                if (
                    loggedIn === "true"
                ) {

                    this.log(
                        "LOGIN_ALREADY_AUTHENTICATED",
                        "کاربر قبلاً وضعیت ورود فعال دارد.",
                        "INFO"
                    );


                    return true;

                }

            } catch (error) {

                this.log(
                    "LOGIN_STATE_CHECK_FAILED",
                    "بررسی وضعیت ورود انجام نشد.",
                    "MEDIUM"
                );

            }


            return false;

        },


        /* =====================================================
           بررسی ماژول‌های امنیتی
        ===================================================== */

        checkSecurityModules: function () {

            const modules = [

                "SmartClassSecurityLog",

                "SmartClassSecurityRules",

                "SmartClassSecurityRate",

                "SmartClassSecurityMonitor",

                "SmartClassSecurityResponse",

                "SmartClassSecuritySettings",

                "SmartClassSecurityInput",

                "SmartClassSecurityStorage",

                "SmartClassSecurityIntegrity",

                "SmartClassSecurityFailSafe",

                "SmartClassSecurityHealth",

                "SmartClassSecurityAccess",

                "SmartClassSecurityData",

                "SmartClassSecurityStartup",

                "SmartClassSecurityDetection",

                "SmartClassSecurityAlert",

                "SmartClassSecurityCore"

            ];


            let available = 0;


            modules.forEach(
                function (name) {

                    if (
                        window[name]
                    ) {

                        available++;

                    }

                }
            );


            if (
                available === 0
            ) {

                this.log(
                    "LOGIN_SECURITY_MODULES_MISSING",
                    "هیچ‌یک از ماژول‌های امنیتی در صفحه ورود موجود نیست.",
                    "HIGH"
                );


                return false;

            }


            if (
                available <
                Math.ceil(
                    modules.length * 0.5
                )
            ) {

                this.log(
                    "LOGIN_SECURITY_MODULES_PARTIAL",
                    "بخشی از ماژول‌های امنیتی صفحه ورود در دسترس نیستند.",
                    "MEDIUM"
                );

            }


            return true;

        },


        /* =====================================================
           بررسی Security Core
        ===================================================== */

        startCore: function () {

            try {

                if (
                    window.SmartClassSecurityCore &&
                    typeof window
                        .SmartClassSecurityCore
                        .start === "function"
                ) {

                    const result =
                        window
                            .SmartClassSecurityCore
                            .start();


                    if (
                        result &&
                        result.status
                    ) {

                        this.log(
                            "LOGIN_SECURITY_CORE_STATUS",
                            "وضعیت Security Core: " +
                            result.status,
                            "INFO"
                        );

                    }


                    return true;

                }

            } catch (error) {

                this.log(
                    "LOGIN_SECURITY_CORE_ERROR",
                    "راه‌اندازی Security Core در صفحه ورود با خطا مواجه شد.",
                    "HIGH"
                );

            }


            return false;

        },


        /* =====================================================
           بررسی Input
        ===================================================== */

       inspectInput: function () {

            const input =
                document.getElementById(
                    "admin-password"
                );


            if (!input) {

                this.log(
                    "LOGIN_PASSWORD_FIELD_MISSING",
                    "فیلد رمز عبور پیدا نشد.",
                    "HIGH"
                );


                return false;

            }


            return true;

        },


        /* =====================================================
           محافظت از صفحه
        ===================================================== */

       protectPage: function () {

            try {

                /*
                 * جلوگیری از ارسال ناخواسته فرم
                 * در صورت وجود فرم خارجی.
                 */

                document.addEventListener(
                    "submit",
                    function (event) {

                        const target =
                            event.target;


                        if (
                            target &&
                            target.closest
                        ) {

                            const loginBox =
                                target.closest(
                                    ".login-box"
                                );


                            if (
                                loginBox
                            ) {

                                event.preventDefault();

                            }

                        }

                    },
                    true
                );


                /*
                 * ثبت تلاش برای خروج از صفحه
                 * فقط به عنوان رویداد امنیتی.
                 */

                window.addEventListener(
                    "pagehide",
                    function () {

                        /*
                         * عمداً وضعیت ورود
                         * حذف نمی‌شود.
                         */

                    }
                );


                return true;

            } catch (error) {

                this.log(
                    "LOGIN_PAGE_PROTECTION_ERROR",
                    "خطا در فعال‌سازی محافظت صفحه ورود.",
                    "MEDIUM"
                );


                return false;

            }

        },


        /* =====================================================
           بررسی نهایی
        ===================================================== */

       healthCheck: function () {

            const checks = [

                this.checkEnvironment(),

                this.checkStorage(),

                this.checkSecurityModules(),

                this.inspectInput()

            ];


            const passed =
                checks.filter(
                    Boolean
                ).length;


            if (
                passed !== checks.length
            ) {

                this.failedChecks++;


                this.log(
                    "LOGIN_SECURITY_HEALTH_WARNING",
                    "بررسی سلامت امنیتی صفحه ورود کامل نبود.",
                    "MEDIUM"
                );


                return false;

            }


            return true;

        },


        /* =====================================================
           Initialize
        ===================================================== */

       initialize: function () {

            if (
                this.initialized
            ) {

                return;

            }


            this.initialized = true;


            if (
                !this.checkEnvironment()
            ) {

                return;

            }


            this.log(
                "LOGIN_SECURITY_START",
                "لایه امنیتی صفحه ورود شروع شد.",
                "INFO"
            );


            /*
             * بررسی Storage
             */

            this.checkStorage();


            /*
             * بررسی ماژول‌ها
             */

            this.checkSecurityModules();


            /*
             * بررسی Core
             */

            this.startCore();


            /*
             * بررسی فیلد رمز
             */

            this.inspectInput();


            /*
             * محافظت صفحه
             */

            this.protectPage();


            /*
             * Health Check
             */

            const healthy =
                this.healthCheck();


            if (
                healthy
            ) {

                this.log(
                    "LOGIN_SECURITY_READY",
                    "لایه امنیتی صفحه ورود آماده است.",
                    "INFO"
                );

            } else {

                this.log(
                    "LOGIN_SECURITY_PARTIAL",
                    "لایه امنیتی صفحه ورود با وضعیت نسبی فعال شد.",
                    "MEDIUM"
                );

            }

        }

    };


    /*
     * API عمومی
     */

    window.SmartClassLoginSecurity =
        LoginSecurity;


    /*
     * شروع
     */

    if (
        document.readyState ===
        "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            function () {

                LoginSecurity.initialize();

            },
            {
                once: true
            }
        );

    } else {

        LoginSecurity.initialize();

    }


})();