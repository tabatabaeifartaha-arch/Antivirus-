#!/data/data/com.termux/files/usr/bin/bash

set -e

PROJECT_DIR="/storage/emulated/0/Khoram project/smartclass-V2.3/smartclass-V2.3"
KEY_DIR="$HOME/.smartclass-security/keys"
PRIVATE_KEY="$KEY_DIR/smartclass-private.pem"

SIGN_DIR="$HOME/.smartclass-security/signatures"
MANIFEST="$SIGN_DIR/security.manifest"

mkdir -p "$SIGN_DIR"

if [ ! -f "$PRIVATE_KEY" ]; then
    echo "ERROR: Private key not found."
    exit 1
fi

cd "$PROJECT_DIR"

echo "=================================="
echo " SmartClass Security Signer"
echo "=================================="
echo

: > "$MANIFEST"

for file in security-*.js; do

    if [ ! -f "$file" ]; then
        continue
    fi

    hash=$(sha256sum "$file" | awk '{print $1}')

    signature_file="$SIGN_DIR/$file.sig"

    echo
    echo "Signing: $file"

    openssl dgst \
        -sha256 \
        -sign "$PRIVATE_KEY" \
        -out "$signature_file" \
        "$file"

    echo "$file:$hash" >> "$MANIFEST"

done

echo
echo "=================================="
echo "Signing completed."
echo "=================================="
echo
echo "Manifest:"
echo "$MANIFEST"
echo
echo "Private key was NOT copied into project."
