"use strict";

window.SmartClassSecuritySettings = (function () {

    const STORAGE_KEY = "smartclass_security_settings";

    const DEFAULTS = {
        inputProtection: true,
        rateLimiting: true,
        securityMonitor: true,
        automaticResponse: true,
        securityLogs: true,
        csp: true,
        suspiciousAlerts: true,
        strictMode: false
    };

    function clone(obj) {
        return JSON.parse(JSON.stringify(obj));
    }

    function load() {
        try {

            const saved = localStorage.getItem(STORAGE_KEY);

            if (!saved) {
                return clone(DEFAULTS);
            }

            const parsed = JSON.parse(saved);

            if (
                !parsed ||
                typeof parsed !== "object" ||
                Array.isArray(parsed)
            ) {
                throw new Error("Invalid security settings format");
            }

            return {
                ...clone(DEFAULTS),
                ...parsed
            };

        } catch (error) {

            if (window.SmartClassSecurityLog) {
                SmartClassSecurityLog.high(
                    "SECURITY_SETTINGS",
                    "Failed to load security settings",
                    {
                        error: String(error)
                    }
                );
            }

            return clone(DEFAULTS);
        }
    }

    function save(settings) {
        try {

            if (
                !settings ||
                typeof settings !== "object" ||
                Array.isArray(settings)
            ) {
                return false;
            }

            const finalSettings = {
                ...clone(DEFAULTS),
                ...settings
            };

            localStorage.setItem(
                STORAGE_KEY,
                JSON.stringify(finalSettings)
            );

            if (window.SmartClassSecurityLog) {
                SmartClassSecurityLog.info(
                    "SECURITY_SETTINGS",
                    "Security settings updated"
                );
            }

            return true;

        } catch (error) {

            if (window.SmartClassSecurityLog) {
                SmartClassSecurityLog.high(
                    "SECURITY_SETTINGS",
                    "Failed to save security settings",
                    {
                        error: String(error)
                    }
                );
            }

            return false;
        }
    }

    function get(name) {

        const settings = load();

        if (
            !Object.prototype.hasOwnProperty.call(
                DEFAULTS,
                name
            )
        ) {
            return null;
        }

        return settings[name];
    }

    function set(name, value) {

        const settings = load();

        if (
            !Object.prototype.hasOwnProperty.call(
                DEFAULTS,
                name
            )
        ) {

            if (window.SmartClassSecurityLog) {
                SmartClassSecurityLog.medium(
                    "SECURITY_SETTINGS",
                    "Unknown security setting rejected",
                    {
                        setting: String(name)
                    }
                );
            }

            return false;
        }

        settings[name] = Boolean(value);

        return save(settings);
    }

    function toggle(name) {

        const current = get(name);

        if (current === null) {
            return false;
        }

        return set(name, !current);
    }

    function getAll() {
        return load();
    }

    function reset() {
        return save(clone(DEFAULTS));
    }

    function getSummary() {

        const settings = load();

        const keys = Object.keys(DEFAULTS);

        let enabled = 0;

        keys.forEach(function (key) {

            if (settings[key] === true) {
                enabled++;
            }

        });

        return {
            total: keys.length,
            enabled: enabled,
            disabled: keys.length - enabled,
            strictMode: settings.strictMode === true,
            percentage: Math.round(
                (enabled / keys.length) * 100
            )
        };
    }

    return {

        version: "1.0",

        defaults: clone(DEFAULTS),

        get,
        set,
        toggle,
        getAll,
        save,
        reset,
        getSummary

    };

})();