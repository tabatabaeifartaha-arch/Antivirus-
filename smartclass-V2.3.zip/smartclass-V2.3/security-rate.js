"use strict";

// ==========================================
// SmartClass Security Rate Limiter
// Version 3.0
// Advanced Client-Side Rate Protection
// ==========================================

window.SmartClassSecurityRate = (function () {

    const VERSION = "3.0";

    // ==========================================
    // Internal Storage
    // ==========================================

    const actions = new Map();

    // ==========================================
    // Configuration
    // ==========================================

    const CONFIG = {

        defaultLimit: 10,
        defaultWindow: 10000,

        burstLimit: 5,
        burstWindow: 1000,

        extremeBurstLimit: 8,
        extremeBurstWindow: 1000,

        lockBase: 5000,
        maxLock: 30000,

        cleanupInterval: 60000,
        staleActionAge: 120000,

        maxActions: 500,
        maxEventsPerAction: 100,

        riskDecayInterval: 10000,
        riskDecayAmount: 5,

        maxRiskScore: 100

    };

    let lastCleanup = Date.now();

    // ==========================================
    // Time
    // ==========================================

    function now() {
        return Date.now();
    }

    // ==========================================
    // Safe Action Name
    // ==========================================

    function normalizeAction(action) {

        let name;

        try {
            name = String(action || "default");
        } catch (error) {
            name = "default";
        }

        name = name.trim();

        if (!name) {
            name = "default";
        }

        if (name.length > 120) {
            name = name.slice(0, 120);
        }

        return name;
    }

    // ==========================================
    // Safe Positive Number
    // ==========================================

    function positiveNumber(value, fallback) {

        const number = Number(value);

        if (
            !Number.isFinite(number) ||
            number <= 0
        ) {
            return fallback;
        }

        return number;
    }

    // ==========================================
    // Security Logger
    // ==========================================

    function securityLog(
        level,
        type,
        message,
        details
    ) {

        try {

            if (
                window.SmartClassSecurityLog &&
                typeof window.SmartClassSecurityLog.log ===
                "function"
            ) {

                window.SmartClassSecurityLog.log(
                    level,
                    type,
                    message,
                    details || {}
                );

            }

        } catch (error) {

            console.error(
                "SmartClass Rate Log Error:",
                error
            );

        }

    }

    // ==========================================
    // Create State
    // ==========================================

    function createState(current) {

        return {

            events: [],

            start: current,

            count: 0,

            blocked: false,

            lockedUntil: 0,

            violations: 0,

            lockCount: 0,

            burstCount: 0,

            extremeBurstCount: 0,

            riskScore: 0,

            lastRiskUpdate: current,

            lastActivity: current,

            totalRequests: 0,

            acceptedRequests: 0,

            rejectedRequests: 0

        };

    }

    // ==========================================
    // Cleanup
    // ==========================================

    function cleanup() {

        const current = now();

        if (
            current - lastCleanup <
            CONFIG.cleanupInterval
        ) {
            return;
        }

        lastCleanup = current;

        for (
            const [name, data]
            of actions.entries()
        ) {

            const inactive =
                current -
                data.lastActivity >
                CONFIG.staleActionAge;

            const unlocked =
                data.lockedUntil <= current;

            const noEvents =
                data.events.length === 0;

            if (
                inactive &&
                unlocked &&
                noEvents
            ) {
                actions.delete(name);
            }

        }

        // ======================================
        // Hard Memory Limit
        // ======================================

        if (
            actions.size >
            CONFIG.maxActions
        ) {

            const entries =
                Array.from(
                    actions.entries()
                );

            entries.sort(
                function (a, b) {

                    return (
                        a[1].lastActivity -
                        b[1].lastActivity
                    );

                }
            );

            const removeCount =
                actions.size -
                CONFIG.maxActions;

            for (
                let i = 0;
                i < removeCount;
                i++
            ) {

                actions.delete(
                    entries[i][0]
                );

            }

        }

    }

    // ==========================================
    // Prune Events
    // ==========================================

    function pruneEvents(
        data,
        current,
        windowMs
    ) {

        const minimum =
            current - windowMs;

        data.events =
            data.events.filter(
                function (timestamp) {

                    return (
                        timestamp >=
                        minimum
                    );

                }
            );

        // Extra memory protection.

        if (
            data.events.length >
            CONFIG.maxEventsPerAction
        ) {

            data.events =
                data.events.slice(
                    -CONFIG.maxEventsPerAction
                );

        }

        data.count =
            data.events.length;

    }

    // ==========================================
    // Burst Detection
    // ==========================================

    function getRecentCount(
        data,
        current,
        windowMs
    ) {

        const minimum =
            current - windowMs;

        let count = 0;

        for (
            let i = data.events.length - 1;
            i >= 0;
            i--
        ) {

            if (
                data.events[i] <
                minimum
            ) {
                break;
            }

            count++;

        }

        return count;

    }

    // ==========================================
    // Risk Calculation
    // ==========================================

    function calculateRisk(
        data,
        limit,
        burstCount,
        extremeBurst
    ) {

        let score = 0;

        const ratio =
            limit > 0
                ? data.count / limit
                : 1;

        if (ratio >= 0.5) {
            score += 20;
        }

        if (ratio >= 0.8) {
            score += 20;
        }

        if (ratio >= 1) {
            score += 25;
        }

        if (burstCount >= CONFIG.burstLimit) {
            score += 15;
        }

        if (extremeBurst) {
            score += 25;
        }

        if (data.violations >= 1) {
            score += 10;
        }

        if (data.violations >= 3) {
            score += 15;
        }

        return Math.min(
            CONFIG.maxRiskScore,
            score
        );

    }

    // ==========================================
    // Risk Decay
    // ==========================================

    function decayRisk(
        data,
        current
    ) {

        if (
            current -
            data.lastRiskUpdate <
            CONFIG.riskDecayInterval
        ) {
            return;
        }

        const intervals =
            Math.floor(
                (
                    current -
                    data.lastRiskUpdate
                ) /
                CONFIG.riskDecayInterval
            );

        data.riskScore =
            Math.max(
                0,
                data.riskScore -
                (
                    intervals *
                    CONFIG.riskDecayAmount
                )
            );

        data.lastRiskUpdate =
            current;

    }

    // ==========================================
    // Lock Duration
    // ==========================================

    function getLockDuration(
        violations
    ) {

        const level =
            Math.max(
                1,
                Math.min(
                    6,
                    Number(violations) || 1
                )
            );

        return Math.min(
            CONFIG.maxLock,
            CONFIG.lockBase * level
        );

    }

    // ==========================================
    // Apply Lock
    // ==========================================

    function applyLock(
        name,
        data,
        current,
        reason
    ) {

        data.violations++;

        data.lockCount++;

        const duration =
            getLockDuration(
                data.violations
            );

        data.lockedUntil =
            current +
            duration;

        data.blocked = true;

        data.rejectedRequests++;

        data.riskScore =
            Math.min(
                CONFIG.maxRiskScore,
                Math.max(
                    data.riskScore,
                    70
                )
            );

        securityLog(
            data.violations >= 3
                ? "HIGH"
                : "MEDIUM",

            "RATE_LIMIT_LOCK",

            "فعالیت بیش‌ازحد شناسایی و موقتاً محدود شد.",

            {
                action: name,
                reason: reason,
                violations:
                    data.violations,
                lockCount:
                    data.lockCount,
                duration:
                    duration,
                riskScore:
                    data.riskScore
            }
        );

    }

    // ==========================================
    // Build Result
    // ==========================================

    function buildResult(
        allowed,
        data,
        limit,
        current,
        blocked
    ) {

        const locked =
            data.lockedUntil >
            current;

        const remaining =
            locked
                ? 0
                : Math.max(
                    0,
                    limit -
                    data.count
                );

        return {

            allowed:
                Boolean(
                    allowed &&
                    !locked
                ),

            remaining:
                remaining,

            count:
                data.count,

            limit:
                limit,

            blocked:
                Boolean(
                    blocked ||
                    locked
                ),

            riskScore:
                data.riskScore,

            burstCount:
                data.burstCount,

            extremeBurstCount:
                data.extremeBurstCount,

            violations:
                data.violations,

            lockCount:
                data.lockCount,

            lockedUntil:
                data.lockedUntil,

            retryAfter:
                locked
                    ? Math.max(
                        0,
                        data.lockedUntil -
                        current
                    )
                    : 0

        };

    }

    // ==========================================
    // Main Rate Check
    // ==========================================

    function check(
        action,
        limit,
        windowMs
    ) {

        try {

            cleanup();

            const name =
                normalizeAction(action);

            const max =
                positiveNumber(
                    limit,
                    CONFIG.defaultLimit
                );

            const duration =
                positiveNumber(
                    windowMs,
                    CONFIG.defaultWindow
                );

            const current =
                now();

            let data =
                actions.get(name);

            // ==================================
            // First Request
            // ==================================

            if (!data) {

                data =
                    createState(
                        current
                    );

                data.events.push(
                    current
                );

                data.count = 1;

                data.totalRequests = 1;

                data.acceptedRequests = 1;

                actions.set(
                    name,
                    data
                );

                return buildResult(
                    true,
                    data,
                    max,
                    current,
                    false
                );

            }

            data.lastActivity =
                current;

            data.totalRequests++;

            decayRisk(
                data,
                current
            );

            // ==================================
            // Existing Lock
            // ==================================

            if (
                data.lockedUntil >
                current
            ) {

                data.blocked = true;

                data.rejectedRequests++;

                data.riskScore =
                    Math.min(
                        CONFIG.maxRiskScore,
                        data.riskScore + 3
                    );

                securityLog(
                    "HIGH",
                    "RATE_LIMIT_BLOCKED",

                    "درخواست در زمان محدودیت امنیتی رد شد.",

                    {
                        action: name,

                        remainingLock:
                            data.lockedUntil -
                            current,

                        violations:
                            data.violations,

                        riskScore:
                            data.riskScore

                    }
                );

                return buildResult(
                    false,
                    data,
                    max,
                    current,
                    true
                );

            }

            // ==================================
            // Unlock
            // ==================================

            if (
                data.lockedUntil > 0 &&
                data.lockedUntil <= current
            ) {

                data.lockedUntil = 0;

                data.blocked = false;

                data.start =
                    current;

                data.count = 0;

                data.events = [];

                data.burstCount = 0;

                data.extremeBurstCount = 0;

                data.riskScore =
                    Math.max(
                        0,
                        data.riskScore - 10
                    );

                securityLog(
                    "INFO",
                    "RATE_LIMIT_UNLOCK",

                    "محدودیت موقت پایان یافت.",

                    {
                        action: name
                    }
                );

            }

            // ==================================
            // Sliding Window
            // ==================================

            pruneEvents(
                data,
                current,
                duration
            );

            // ==================================
            // Burst Detection
            // ==================================

            const burstCount =
                getRecentCount(
                    data,
                    current,
                    CONFIG.burstWindow
                );

            const extremeBurstCount =
                getRecentCount(
                    data,
                    current,
                    CONFIG.extremeBurstWindow
                );

            data.burstCount =
                burstCount;

            data.extremeBurstCount =
                extremeBurstCount;

            const burstDetected =
                burstCount >=
                CONFIG.burstLimit;

            const extremeBurst =
                extremeBurstCount >=
                CONFIG.extremeBurstLimit;

            // ==================================
            // Risk Update
            // ==================================

            data.riskScore =
                Math.max(
                    data.riskScore,
                    calculateRisk(
                        data,
                        max,
                        burstCount,
                        extremeBurst
                    )
                );

            // ==================================
            // Extreme Burst
            // ==================================

            if (extremeBurst) {

                securityLog(
                    "HIGH",
                    "RATE_LIMIT_EXTREME_BURST",

                    "الگوی فعالیت بسیار سریع شناسایی شد.",

                    {
                        action: name,

                        burstCount:
                            burstCount,

                        extremeBurstCount:
                            extremeBurstCount,

                        riskScore:
                            data.riskScore

                    }
                );

                applyLock(
                    name,
                    data,
                    current,
                    "EXTREME_BURST"
                );

                return buildResult(
                    false,
                    data,
                    max,
                    current,
                    true
                );

            }

            // ==================================
            // Window Limit
            // ==================================

            if (
                data.events.length >=
                max
            ) {

                data.riskScore =
                    Math.max(
                        data.riskScore,
                        70
                    );

                applyLock(
                    name,
                    data,
                    current,
                    "WINDOW_LIMIT"
                );

                return buildResult(
                    false,
                    data,
                    max,
                    current,
                    true
                );

            }

            // ==================================
            // Accept Request
            // ==================================

            data.events.push(
                current
            );

            data.count =
                data.events.length;

            data.acceptedRequests++;

            data.riskScore =
                calculateRisk(
                    data,
                    max,
                    burstCount,
                    extremeBurst
                );

            // ==================================
            // Suspicious Burst Logging
            // ==================================

            if (
                burstDetected &&
                !extremeBurst
            ) {

                securityLog(
                    "MEDIUM",
                    "RATE_LIMIT_BURST",

                    "فعالیت سریع و غیرعادی شناسایی شد.",

                    {
                        action: name,

                        burstCount:
                            burstCount,

                        riskScore:
                            data.riskScore

                    }
                );

            }

            actions.set(
                name,
                data
            );

            return buildResult(
                true,
                data,
                max,
                current,
                false
            );

        } catch (error) {

            // ==================================
            // Fail-Safe
            // ==================================
            // If the limiter itself fails,
            // don't crash SmartClass.

            securityLog(
                "CRITICAL",
                "RATE_LIMIT_ERROR",

                "خطا در موتور محدودسازی فعالیت.",

                {
                    message:
                        String(
                            error &&
                            error.message
                                ? error.message
                                : error
                        )
                }
            );

            return {

                allowed: true,

                remaining: 0,

                count: 0,

                limit:
                    positiveNumber(
                        limit,
                        CONFIG.defaultLimit
                    ),

                blocked: false,

                riskScore: 100,

                burstCount: 0,

                extremeBurstCount: 0,

                violations: 0,

                lockCount: 0,

                lockedUntil: 0,

                retryAfter: 0,

                error: true

            };

        }

    }

    // ==========================================
    // Reset One Action
    // ==========================================

    function reset(action) {

        const name =
            normalizeAction(action);

        actions.delete(name);

    }

    // ==========================================
    // Reset All
    // ==========================================

    function resetAll() {

        actions.clear();

    }

    // ==========================================
    // Get Status
    // ==========================================

    function getStatus(action) {

        const name =
            normalizeAction(action);

        const data =
            actions.get(name);

        if (!data) {

            return {

                active: false,

                count: 0,

                blocked: false,

                locked: false,

                riskScore: 0,

                burstCount: 0,

                extremeBurstCount: 0,

                violations: 0,

                lockCount: 0,

                totalRequests: 0,

                acceptedRequests: 0,

                rejectedRequests: 0

            };

        }

        const current =
            now();

        decayRisk(
            data,
            current
        );

        const locked =
            data.lockedUntil >
            current;

        return {

            active: true,

            count:
                data.count,

            blocked:
                Boolean(
                    data.blocked ||
                    locked
                ),

            locked:
                locked,

            startedAt:
                data.start,

            lastActivity:
                data.lastActivity,

            lockedUntil:
                data.lockedUntil,

            retryAfter:
                locked
                    ? Math.max(
                        0,
                        data.lockedUntil -
                        current
                    )
                    : 0,

            violations:
                data.violations,

            lockCount:
                data.lockCount,

            burstCount:
                data.burstCount,

            extremeBurstCount:
                data.extremeBurstCount,

            riskScore:
                data.riskScore,

            totalRequests:
                data.totalRequests,

            acceptedRequests:
                data.acceptedRequests,

            rejectedRequests:
                data.rejectedRequests

        };

    }

    // ==========================================
    // Get All Status
    // ==========================================

    function getAllStatus() {

        const result = {};

        actions.forEach(
            function (data, name) {

                result[name] =
                    getStatus(name);

            }
        );

        return result;

    }

    // ==========================================
    // Get Statistics
    // ==========================================

    function getStatistics() {

        const current =
            now();

        let active = 0;

        let blocked = 0;

        let locked = 0;

        let violations = 0;

        let totalRisk = 0;

        let totalRequests = 0;

        let acceptedRequests = 0;

        let rejectedRequests = 0;

        actions.forEach(
            function (data) {

                decayRisk(
                    data,
                    current
                );

                active++;

                if (
                    data.blocked
                ) {
                    blocked++;
                }

                if (
                    data.lockedUntil >
                    current
                ) {
                    locked++;
                }

                violations +=
                    data.violations;

                totalRisk +=
                    data.riskScore;

                totalRequests +=
                    data.totalRequests;

                acceptedRequests +=
                    data.acceptedRequests;

                rejectedRequests +=
                    data.rejectedRequests;

            }
        );

        return {

            actions:
                active,

            blocked:
                blocked,

            locked:
                locked,

            violations:
                violations,

            totalRequests:
                totalRequests,

            acceptedRequests:
                acceptedRequests,

            rejectedRequests:
                rejectedRequests,

            averageRisk:
                active
                    ? Math.round(
                        totalRisk /
                        active
                    )
                    : 0

        };

    }

    // ==========================================
    // Configuration Information
    // ==========================================

    function getConfig() {

        return {
            defaultLimit:
                CONFIG.defaultLimit,

            defaultWindow:
                CONFIG.defaultWindow,

            burstLimit:
                CONFIG.burstLimit,

            burstWindow:
                CONFIG.burstWindow,

            extremeBurstLimit:
                CONFIG.extremeBurstLimit,

            extremeBurstWindow:
                CONFIG.extremeBurstWindow,

            lockBase:
                CONFIG.lockBase,

            maxLock:
                CONFIG.maxLock,

            maxActions:
                CONFIG.maxActions,

            maxEventsPerAction:
                CONFIG.maxEventsPerAction

        };

    }

    // ==========================================
    // Public API
    // ==========================================

    return {

        version:
            VERSION,

        check:
            check,

        reset:
            reset,

        resetAll:
            resetAll,

        getStatus:
            getStatus,

        getAllStatus:
            getAllStatus,

        getStatistics:
            getStatistics,

        getConfig:
            getConfig

    };

})();