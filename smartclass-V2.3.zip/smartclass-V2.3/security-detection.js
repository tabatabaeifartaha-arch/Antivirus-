"use strict";

// ============================================================
// SmartClass Security Detection
// Version 1.0
// ============================================================

window.SmartClassSecurityDetection = (function () {

    const VERSION = "1.0";

    const LEVELS = {
        NORMAL: "NORMAL",
        LOW: "LOW",
        MEDIUM: "MEDIUM",
        HIGH: "HIGH",
        CRITICAL: "CRITICAL"
    };

    const CONFIG = {
        maxInputLength: 5000,
        highRiskScore: 70,
        criticalRiskScore: 90,
        rapidActionLimit: 15,
        rapidActionWindow: 3000,
        maxHistory: 100
    };

    let history = [];
    let actionTimes = [];

    let statistics = {
        checks: 0,
        normal: 0,
        suspicious: 0,
        highRisk: 0,
        critical: 0
    };


    // =========================================================
    // Safe Log
    // =========================================================

    function log(
        level,
        type,
        message,
        details
    ) {

        try {

            if (
                window.SmartClassSecurityLog &&
                typeof window.SmartClassSecurityLog.log ===
                "function"
            ) {

                window.SmartClassSecurityLog.log(
                    level,
                    type,
                    message,
                    details || {}
                );

            }

        } catch (error) {

            console.error(
                "Security Detection Log Error:",
                error
            );

        }

    }


    // =========================================================
    // Safe String
    // =========================================================

    function safeString(
        value,
        maxLength
    ) {

        try {

            return String(value)
                .normalize("NFKC")
                .replace(
                    /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g,
                    ""
                )
                .replace(
                    /[\u200B-\u200D\uFEFF]/g,
                    ""
                )
                .trim()
                .slice(
                    0,
                    maxLength || 500
                );

        } catch (error) {

            return "";

        }

    }


    // =========================================================
    // Cleanup Action History
    // =========================================================

    function cleanupActions(
        now
    ) {

        const limit =
            now -
            CONFIG.rapidActionWindow;


        actionTimes =
            actionTimes.filter(
                function (time) {

                    return time >= limit;

                }
            );

    }


    // =========================================================
    // Check Rapid Activity
    // =========================================================

    function checkRapidActivity() {

        const now =
            Date.now();

        cleanupActions(now);

        actionTimes.push(now);


        return {

            count:
                actionTimes.length,

            suspicious:
                actionTimes.length >
                CONFIG.rapidActionLimit

        };

    }


    // =========================================================
    // Check Text
    // =========================================================

    function checkText(
        value
    ) {

        const text =
            safeString(
                value,
                CONFIG.maxInputLength
            );


        if (
            text.length === 0
        ) {

            return {

                score:
                    0,

                level:
                    LEVELS.NORMAL,

                matches:
                    []

            };

        }


        try {

            if (
                window.SmartClassSecurityInput &&
                typeof window.SmartClassSecurityInput.inspect ===
                "function"
            ) {

                const result =
                    window.SmartClassSecurityInput.inspect(
                        text
                    );


                return {

                    score:
                        Number(result.riskScore) || 0,

                    level:
                        result.riskLevel ||
                        LEVELS.NORMAL,

                    matches:
                        Array.isArray(result.matches)
                            ? result.matches.slice(0, 20)
                            : []

                };

            }

        } catch (error) {

            log(
                "HIGH",
                "DETECTION_INPUT_ERROR",
                "خطا هنگام بررسی ورودی."
            );

        }


        /*
         * بررسی مستقل در صورت نبودن
         * ماژول Input Protection
         */

        const patterns = [

            {
                regex:
                    /<script\b/i,

                score:
                    60,

                name:
                    "SCRIPT_TAG"

            },

            {
                regex:
                    /javascript\s*:/i,

                score:
                    60,

                name:
                    "JAVASCRIPT_SCHEME"

            },

            {
                regex:
                    /<iframe\b/i,

                score:
                    40,

                name:
                    "IFRAME"

            },

            {
                regex:
                    /on[a-z]+\s*=/i,

                score:
                    50,

                name:
                    "EVENT_HANDLER"

            },

            {
                regex:
                    /eval\s*\(/i,

                score:
                    40,

                name:
                    "EVAL"

            }

        ];


        let score = 0;
        const matches = [];


        patterns.forEach(
            function (item) {

                try {

                    if (
                        item.regex.test(text)
                    ) {

                        score +=
                            item.score;

                        matches.push(
                            item.name
                        );

                    }

                } catch (error) {

                    // Ignore pattern errors.

                }

            }
        );


        score =
            Math.min(
                score,
                100
            );


        return {

            score:
                score,

            level:
                getLevel(score),

            matches:
                matches

        };

    }


    // =========================================================
    // Risk Level
    // =========================================================

    function getLevel(
        score
    ) {

        score =
            Number(score) || 0;


        if (
            score >=
            CONFIG.criticalRiskScore
        ) {

            return LEVELS.CRITICAL;

        }


        if (
            score >=
            CONFIG.highRiskScore
        ) {

            return LEVELS.HIGH;

        }


        if (
            score >= 40
        ) {

            return LEVELS.MEDIUM;

        }


        if (
            score > 0
        ) {

            return LEVELS.LOW;

        }


        return LEVELS.NORMAL;

    }


    // =========================================================
    // Analyze
    // =========================================================

    function analyze(
        value,
        action
    ) {

        statistics.checks++;


        const safeAction =
            safeString(
                action || "unknown",
                100
            );


        const rapid =
            checkRapidActivity();


        const textResult =
            checkText(
                value
            );


        let score =
            textResult.score;


        const matches =
            [...textResult.matches];


        if (
            rapid.suspicious
        ) {

            score += 30;

            matches.push(
                "RAPID_ACTIVITY"
            );

        }


        score =
            Math.min(
                score,
                100
            );


        const level =
            getLevel(score);


        const result = {

            safe:
                score <
                CONFIG.highRiskScore,

            suspicious:
                score > 0,

            score:
                score,

            level:
                level,

            action:
                safeAction,

            matches:
                [...new Set(matches)],

            timestamp:
                Date.now()

        };


        history.push(result);


        if (
            history.length >
            CONFIG.maxHistory
        ) {

            history.shift();

        }


        if (
            level === LEVELS.CRITICAL
        ) {

            statistics.critical++;

            log(
                "CRITICAL",
                "SECURITY_CRITICAL_DETECTION",
                "فعالیت با ریسک بحرانی شناسایی شد.",
                {
                    action:
                        safeAction,

                    score:
                        score,

                    matches:
                        result.matches
                }
            );

        } else if (
            level === LEVELS.HIGH
        ) {

            statistics.highRisk++;

            log(
                "HIGH",
                "SECURITY_HIGH_RISK_DETECTION",
                "فعالیت پرریسک شناسایی شد.",
                {
                    action:
                        safeAction,

                    score:
                        score,

                    matches:
                        result.matches
                }
            );

        } else if (
            level === LEVELS.MEDIUM ||
            level === LEVELS.LOW
        ) {

            statistics.suspicious++;

        } else {

            statistics.normal++;

        }


        return result;

    }


    // =========================================================
    // Get History
    // =========================================================

    function getHistory() {

        return history.map(
            function (item) {

                return {
                    ...item,
                    matches:
                        [...item.matches]
                };

            }
        );

    }


    // =========================================================
    // Get Statistics
    // =========================================================

    function getStatistics() {

        return {

            version:
                VERSION,

            ...statistics,

            historySize:
                history.length,

            rapidActions:
                actionTimes.length

        };

    }


    // =========================================================
    // Clear History
    // =========================================================

    function clearHistory() {

        history = [];
        actionTimes = [];

        return true;

    }


    // =========================================================
    // Reset Statistics
    // =========================================================

    function resetStatistics() {

        statistics = {

            checks: 0,
            normal: 0,
            suspicious: 0,
            highRisk: 0,
            critical: 0

        };


        return true;

    }


    // =========================================================
    // Public API
    // =========================================================

    return {

        version:
            VERSION,

        levels:
            { ...LEVELS },

        analyze:
            analyze,

        getLevel:
            getLevel,

        getHistory:
            getHistory,

        getStatistics:
            getStatistics,

        clearHistory:
            clearHistory,

        resetStatistics:
            resetStatistics

    };

})();