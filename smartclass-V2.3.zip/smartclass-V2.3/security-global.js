"use strict";

/*
 * ============================================================
 * SmartClass
 * Global Security Connector
 * ============================================================
 *
 * این فایل لایه‌های امنیتی موجود را به تمام صفحات SmartClass
 * متصل می‌کند.
 *
 * نکته:
 * این لایه امنیت مرورگر است و جایگزین امنیت سمت سرور نیست.
 * ============================================================
 */

(function () {

    const GlobalSecurity = {

        version: "1.0.0",

        initialized: false,

        modules: {},

        settings: {},

        /*
         * --------------------------------------------------------
         * بررسی تنظیمات
         * --------------------------------------------------------
         */

        loadSettings: function () {

            try {

                const raw =
                    localStorage.getItem(
                        "smartclass_advanced_security"
                    );

                if (!raw) {
                    this.settings = {};
                    return;
                }

                const parsed =
                    JSON.parse(raw);

                if (
                    parsed &&
                    typeof parsed === "object" &&
                    !Array.isArray(parsed)
                ) {

                    this.settings = parsed;

                } else {

                    this.settings = {};

                }

            } catch (error) {

                this.settings = {};

            }

        },


        /*
         * --------------------------------------------------------
         * بررسی فعال بودن تنظیم
         * --------------------------------------------------------
         */

        isEnabled: function (key, defaultValue) {

            if (
                Object.prototype.hasOwnProperty.call(
                    this.settings,
                    key
                )
            ) {

                return Boolean(
                    this.settings[key]
                );

            }

            return Boolean(defaultValue);

        },


        /*
         * --------------------------------------------------------
         * ثبت وضعیت ماژول‌ها
         * --------------------------------------------------------
         */

        detectModules: function () {

            this.modules = {

                log:
                    !!window.SmartClassSecurityLog,

                rules:
                    !!window.SmartClassSecurityRules,

                rate:
                    !!window.SmartClassSecurityRate,

                monitor:
                    !!window.SmartClassSecurityMonitor,

                response:
                    !!window.SmartClassSecurityResponse,

                settings:
                    !!window.SmartClassSecuritySettings,

                input:
                    !!window.SmartClassSecurityInput,

                storage:
                    !!window.SmartClassSecurityStorage,

                integrity:
                    !!window.SmartClassSecurityIntegrity,

                failsafe:
                    !!window.SmartClassSecurityFailSafe,

                health:
                    !!window.SmartClassSecurityHealth,

                access:
                    !!window.SmartClassSecurityAccess,

                data:
                    !!window.SmartClassSecurityData,

                startup:
                    !!window.SmartClassSecurityStartup,

                detection:
                    !!window.SmartClassSecurityDetection,

                alert:
                    !!window.SmartClassSecurityAlert,

                core:
                    !!window.SmartClassSecurityCore

            };

        },


        /*
         * --------------------------------------------------------
         * محافظت ورودی
         * --------------------------------------------------------
         */

        inspectInput: function (value) {

            if (
                !this.isEnabled(
                    "inputProtection",
                    true
                )
            ) {

                return {
                    allowed: true,
                    risk: 0
                };

            }

            try {

                if (
                    this.modules.rules &&
                    typeof window
                        .SmartClassSecurityRules
                        .inspect === "function"
                ) {

                    return window
                        .SmartClassSecurityRules
                        .inspect(String(value));

                }

            } catch (error) {

                this.log(
                    "INPUT_SECURITY_ERROR",
                    "خطا در بررسی ورودی.",
                    "MEDIUM"
                );

            }

            return {
                allowed: true,
                risk: 0
            };

        },


        /*
         * --------------------------------------------------------
         * ثبت رویداد امنیتی
         * --------------------------------------------------------
         */

        log: function (
            event,
            message,
            level
        ) {

            if (
                !this.isEnabled(
                    "securityLogs",
                    true
                )
            ) {
                return;
            }

            try {

                if (
                    this.modules.log
                ) {

                    const logger =
                        window
                            .SmartClassSecurityLog;

                    if (
                        typeof logger[level?.toLowerCase()] ===
                        "function"
                    ) {

                        logger[
                            level.toLowerCase()
                        ](
                            event,
                            message
                        );

                        return;

                    }

                    if (
                        typeof logger.info ===
                        "function"
                    ) {

                        logger.info(
                            event,
                            message
                        );

                    }

                }

            } catch (error) {

                // امنیت نباید باعث توقف صفحه شود.

            }

        },


        /*
         * --------------------------------------------------------
         * بررسی دسترسی عملیات
         * --------------------------------------------------------
         */

        checkAccess: function (
            action
        ) {

            if (
                !this.isEnabled(
                    "adminProtection",
                    true
                )
            ) {

                return true;

            }

            try {

                if (
                    this.modules.access &&
                    typeof window
                        .SmartClassSecurityAccess
                        .can === "function"
                ) {

                    return Boolean(
                        window
                            .SmartClassSecurityAccess
                            .can(action)
                    );

                }

            } catch (error) {

                this.log(
                    "ACCESS_CHECK_ERROR",
                    "خطا در بررسی دسترسی.",
                    "HIGH"
                );

            }

            return true;

        },


        /*
         * --------------------------------------------------------
         * اتصال محافظت به Input ها
         * --------------------------------------------------------
         */

        attachInputProtection: function () {

            if (
                !this.isEnabled(
                    "inputProtection",
                    true
                )
            ) {
                return;
            }

            document.addEventListener(
                "input",
                function (event) {

                    const target =
                        event.target;

                    if (
                        !target ||
                        !(
                            target instanceof
                            HTMLInputElement
                        ) &&
                        !(
                            target instanceof
                            HTMLTextAreaElement
                        )
                    ) {
                        return;
                    }

                    const value =
                        target.value;

                    if (!value) {
                        return;
                    }

                    const result =
                        GlobalSecurity
                            .inspectInput(value);

                    if (
                        result &&
                        Number(result.risk) >= 80
                    ) {

                        GlobalSecurity.log(
                            "HIGH_RISK_INPUT",
                            "ورودی با سطح ریسک بالا شناسایی شد.",
                            "HIGH"
                        );

                    }

                },
                true
            );

        },


        /*
         * --------------------------------------------------------
         * اتصال مانیتور امنیتی
         * --------------------------------------------------------
         */

        startMonitor: function () {

            if (
                !this.isEnabled(
                    "securityMonitor",
                    true
                )
            ) {
                return;
            }

            try {

                if (
                    this.modules.monitor &&
                    typeof window
                        .SmartClassSecurityMonitor
                        .start === "function"
                ) {

                    window
                        .SmartClassSecurityMonitor
                        .start();

                }

            } catch (error) {

                this.log(
                    "MONITOR_START_ERROR",
                    "مانیتور امنیتی نتوانست شروع شود.",
                    "MEDIUM"
                );

            }

        },


        /*
         * --------------------------------------------------------
         * شروع Core
         * --------------------------------------------------------
         */

        startCore: function () {

            try {

                if (
                    this.modules.core &&
                    typeof window
                        .SmartClassSecurityCore
                        .start === "function"
                ) {

                    return window
                        .SmartClassSecurityCore
                        .start();

                }

            } catch (error) {

                this.log(
                    "CORE_START_ERROR",
                    "خطا در راه‌اندازی Security Core.",
                    "HIGH"
                );

            }

            return null;

        },


        /*
         * --------------------------------------------------------
         * اجرای کلی
         * --------------------------------------------------------
         */

        initialize: function () {

            if (this.initialized) {
                return;
            }

            this.initialized = true;

            this.loadSettings();

            this.detectModules();

            this.startCore();

            this.startMonitor();

            this.attachInputProtection();

            this.log(
                "GLOBAL_SECURITY_INITIALIZED",
                "لایه امنیتی سراسری SmartClass فعال شد.",
                "INFO"
            );

        }

    };


    /*
     * API عمومی
     */

    window.SmartClassGlobalSecurity =
        GlobalSecurity;


    /*
     * شروع پس از آماده شدن DOM
     */

    if (
        document.readyState ===
        "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            function () {

                GlobalSecurity.initialize();

            },
            {
                once: true
            }
        );

    } else {

        GlobalSecurity.initialize();

    }

})();