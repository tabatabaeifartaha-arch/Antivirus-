"use strict";

window.SmartClassSecurityPage = (function () {

    const ADVANCED_STORAGE_KEY =
        "smartclass_advanced_security";

    function safeLog(type, message, details) {
        try {
            if (
                window.SmartClassSecurityLog &&
                typeof SmartClassSecurityLog[type] === "function"
            ) {
                SmartClassSecurityLog[type](
                    "SECURITY_PAGE",
                    message,
                    details || {}
                );
            }
        } catch (error) {
            console.warn(
                "Security page log error:",
                error
            );
        }
    }

    function loadAdvancedSettings() {

        try {

            const saved =
                localStorage.getItem(
                    ADVANCED_STORAGE_KEY
                );

            if (!saved) {
                return {};
            }

            const parsed = JSON.parse(saved);

            if (
                !parsed ||
                typeof parsed !== "object" ||
                Array.isArray(parsed)
            ) {
                return {};
            }

            return parsed;

        } catch (error) {

            safeLog(
                "high",
                "Failed to load advanced security settings",
                {
                    error: String(error)
                }
            );

            return {};
        }
    }

    function saveAdvancedSettings(settings) {

        try {

            localStorage.setItem(
                ADVANCED_STORAGE_KEY,
                JSON.stringify(settings)
            );

            return true;

        } catch (error) {

            safeLog(
                "high",
                "Failed to save advanced security settings",
                {
                    error: String(error)
                }
            );

            return false;
        }
    }

    function collectSettings() {

        const settings = {};

        const inputs =
            document.querySelectorAll(
                "[data-setting]"
            );

        inputs.forEach(function (input) {

            const key =
                input.getAttribute("data-setting");

            if (!key) {
                return;
            }

            settings[key] =
                Boolean(input.checked);

        });

        return settings;
    }

    function applySettings(settings) {

        if (
            !settings ||
            typeof settings !== "object"
        ) {
            return;
        }

        const inputs =
            document.querySelectorAll(
                "[data-setting]"
            );

        inputs.forEach(function (input) {

            const key =
                input.getAttribute("data-setting");

            if (
                key &&
                Object.prototype.hasOwnProperty.call(
                    settings,
                    key
                )
            ) {
                input.checked =
                    Boolean(settings[key]);
            }

        });
    }

    function saveAll() {

        try {

            const settings =
                collectSettings();

            if (
                window.SmartClassSecuritySettings
            ) {

                Object.keys(settings).forEach(
                    function (key) {

                        const known =
                            Object.prototype.hasOwnProperty.call(
                                SmartClassSecuritySettings.defaults,
                                key
                            );

                        if (known) {

                            SmartClassSecuritySettings.set(
                                key,
                                settings[key]
                            );
                        }

                    }
                );
            }

            const saved =
                saveAdvancedSettings(settings);

            if (!saved) {
                return false;
            }

            safeLog(
                "info",
                "Security settings saved successfully"
            );

            return true;

        } catch (error) {

            safeLog(
                "high",
                "Security settings save failed",
                {
                    error: String(error)
                }
            );

            return false;
        }
    }

    function showSaveStatus(success) {

        const element =
            document.getElementById(
                "save-status"
            );

        if (!element) {
            return;
        }

        if (success) {

            element.textContent =
                "تنظیمات با موفقیت ذخیره شد ✓";

            element.className =
                "save-status success";

        } else {

            element.textContent =
                "ذخیره تنظیمات انجام نشد ✕";

            element.className =
                "save-status error";
        }

    }

    function updateReport() {

        try {

            if (
                !window.SmartClassSecurityReport
            ) {
                return;
            }

            const summary =
                SmartClassSecurityReport.getSummary();

            const total =
                document.getElementById(
                    "report-total"
                );

            const high =
                document.getElementById(
                    "report-high"
                );

            const status =
                document.getElementById(
                    "report-status"
                );

            if (total) {
                total.textContent =
                    summary.total;
            }

            if (high) {
                high.textContent =
                    summary.highRisk;
            }

            if (status) {
                status.textContent =
                    summary.status;
            }

        } catch (error) {

            safeLog(
                "high",
                "Security report update failed",
                {
                    error: String(error)
                }
            );
        }
    }

    function updateSecurityStatus() {

        const element =
            document.getElementById(
                "security-status"
            );

        if (!element) {
            return;
        }

        try {

            if (
                !window.SmartClassSecurityCore
            ) {
                element.textContent =
                    "در حال بررسی...";
                return;
            }

            const status =
                SmartClassSecurityCore.getStatus();

            switch (status.status) {

                case "PROTECTED":
                    element.textContent =
                        "محافظت فعال";
                    break;

                case "PARTIAL":
                    element.textContent =
                        "محافظت نسبی";
                    break;

                case "WARNING":
                    element.textContent =
                        "هشدار امنیتی";
                    break;

                case "ERROR":
                    element.textContent =
                        "خطای امنیتی";
                    break;

                default:
                    element.textContent =
                        "در حال بررسی...";
            }

        } catch (error) {

            element.textContent =
                "در حال بررسی...";
        }
    }

    function setupInfoButtons() {

        document
            .querySelectorAll(".info-button")
            .forEach(function (button) {

                button.addEventListener(
                    "click",
                    function (event) {

                        event.preventDefault();
                        event.stopPropagation();

                        const row =
                            button.closest(
                                ".setting-row"
                            );

                        if (row) {
                            row.classList.toggle(
                                "description-open"
                            );
                        }

                    }
                );

            });
    }

    function setupSaveButton() {

        const button =
            document.getElementById(
                "save-security-settings"
            );

        if (!button) {
            return;
        }

        button.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                const success =
                    saveAll();

                showSaveStatus(
                    success
                );

                updateReport();

                updateSecurityStatus();

            }
        );
    }

    function setupRefreshButton() {

        const button =
            document.getElementById(
                "refresh-security-report"
            );

        if (!button) {
            return;
        }

        button.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                updateReport();
                updateSecurityStatus();

            }
        );
    }

    function initialize() {

        const advancedSettings =
            loadAdvancedSettings();

        applySettings(
            advancedSettings
        );

        setupInfoButtons();
        setupSaveButton();
        setupRefreshButton();

        updateReport();
        updateSecurityStatus();

        safeLog(
            "info",
            "Security settings page initialized"
        );
    }

    return {

        version: "1.0",

        initialize,
        loadAdvancedSettings,
        saveAdvancedSettings,
        collectSettings,
        applySettings,
        saveAll,
        updateReport,
        updateSecurityStatus

    };

})();