#!/data/data/com.termux/files/usr/bin/bash

set -e

PROJECT_DIR="/storage/emulated/0/Khoram project/smartclass-V2.3/smartclass-V2.3"

KEY_DIR="$HOME/.smartclass-security/keys"
PRIVATE_KEY="$KEY_DIR/smartclass-private.pem"
PUBLIC_KEY="$KEY_DIR/smartclass-public.pem"

SIGN_DIR="$HOME/.smartclass-security/signatures"

cd "$PROJECT_DIR"

echo "=================================="
echo " SmartClass Security Gate"
echo "=================================="
echo

if [ ! -f "$PUBLIC_KEY" ]; then
    echo "ERROR: Public key not found."
    exit 1
fi

failed=0
changed_files=""

for file in security-*.js; do

    [ -f "$file" ] || continue

    signature="$SIGN_DIR/$file.sig"

    if [ ! -f "$signature" ]; then
        echo "[MISSING] $file"
        failed=1
        changed_files="$changed_files $file"
        continue
    fi

    if openssl dgst \
        -sha256 \
        -verify "$PUBLIC_KEY" \
        -signature "$signature" \
        "$file" >/dev/null 2>&1
    then
        echo "[VALID]   $file"
    else
        echo "[MODIFIED] $file"
        failed=1
        changed_files="$changed_files $file"
    fi

done

echo

if [ "$failed" -eq 0 ]; then
    echo "=================================="
    echo "ACCESS GRANTED"
    echo "Integrity verification successful."
    echo "=================================="
    exit 0
fi

echo "=================================="
echo "ACCESS DENIED"
echo "Security integrity violation."
echo "=================================="
echo
echo "Modified files:"
echo "$changed_files"
echo
echo "No release is allowed."
exit 2