// ==========================
// SmartClass Admin JS
// ==========================


// ==========================
// Student Management
// ==========================

const studentInput =
document.getElementById("student-name-input");

const addStudentButton =
document.getElementById("add-student");

const studentsList =
document.getElementById("students-list");


let students =
JSON.parse(
    localStorage.getItem("smartclass_students")
)
||
[];


function saveStudents(){

    localStorage.setItem(
        "smartclass_students",
        JSON.stringify(students)
    );

}


function renderStudents(){

    if(!studentsList)
        return;

    studentsList.innerHTML = "";

    students.forEach((student,index)=>{

        const li =
        document.createElement("li");

        li.innerHTML = `

            <span>
                ${student}
            </span>

            <button
            class="delete-student"
            data-index="${index}">

                حذف

            </button>

        `;

        studentsList.appendChild(li);

    });

}


if(addStudentButton){

    addStudentButton.addEventListener(
    "click",
    ()=>{

        const name =
        studentInput.value.trim();

        if(name === "")
            return;

        students.push(name);

        saveStudents();

        studentInput.value = "";

        renderStudents();

    });

}


if(studentsList){

    studentsList.addEventListener(
    "click",
    (event)=>{

        if(
            event.target.classList.contains(
            "delete-student"
            )
        ){

            const index =
            event.target.dataset.index;

            students.splice(index,1);

            saveStudents();

            renderStudents();

        }

    });

}


renderStudents();


// ==========================
// Bell Schedule Management
// ==========================

const bellNameInput =
document.getElementById("bell-name");

const bellStartInput =
document.getElementById("bell-start");

const bellEndInput =
document.getElementById("bell-end");

const addBellButton =
document.getElementById("add-bell");

const bellList =
document.getElementById("bell-list");


let bells =
JSON.parse(
    localStorage.getItem("smartclass_bells")
)
||
[];


function saveBells(){

    localStorage.setItem(
        "smartclass_bells",
        JSON.stringify(bells)
    );

}


function renderBells(){

    if(!bellList)
        return;

    bellList.innerHTML = "";

    bells.forEach((bell,index)=>{

        const li =
        document.createElement("li");

        li.innerHTML = `

            <strong>
                ${bell.name}
            </strong>

            <br>

            شروع:
            ${bell.start}

            |

            پایان:
            ${bell.end}

            <br>

            <button
            class="delete-bell"
            data-index="${index}">

                حذف

            </button>

        `;

        bellList.appendChild(li);

    });

}


if(addBellButton){

    addBellButton.addEventListener(
    "click",
    ()=>{

        const name =
        bellNameInput.value.trim();

        const start =
        bellStartInput.value;

        const end =
        bellEndInput.value;

        if(
            name === "" ||
            start === "" ||
            end === ""
        ){

            return;

        }

        bells.push({

            name:name,

            start:start,

            end:end

        });

        saveBells();

        bellNameInput.value = "";

        bellStartInput.value = "";

        bellEndInput.value = "";

        renderBells();

    });

}


if(bellList){

    bellList.addEventListener(
    "click",
    (event)=>{

        if(
            event.target.classList.contains(
            "delete-bell"
            )
        ){

            const index =
            event.target.dataset.index;

            bells.splice(index,1);

            saveBells();

            renderBells();

        }

    });

}


renderBells();


// ==========================
// General Settings
// ==========================

const bellStatusSelect =
document.getElementById("bell-status");

const bellTypeSelect =
document.getElementById("bell-type");

const saveSettingsButton =
document.getElementById("save-settings");


let systemSettings =
JSON.parse(
    localStorage.getItem("smartclass_settings")
)
||
{
    bellStatus:"enabled",
    bellType:"school"
};


// ==========================
// Load Saved Settings
// ==========================

if(bellStatusSelect){

    bellStatusSelect.value =
    systemSettings.bellStatus;

}


if(bellTypeSelect){

    bellTypeSelect.value =
    systemSettings.bellType;

}


// ==========================
// Save Settings
// ==========================

if(saveSettingsButton){

    saveSettingsButton.addEventListener(
    "click",
    ()=>{

        systemSettings = {

            bellStatus:
            bellStatusSelect.value,

            bellType:
            bellTypeSelect.value

        };

        localStorage.setItem(
            "smartclass_settings",
            JSON.stringify(systemSettings)
        );

        alert(
            "تنظیمات ذخیره شد"
        );

    });

}


// ==================================================
// SmartClass Security Settings
// ==================================================

const securitySettingMap = {

    "security-input-protection":
        "inputProtection",

    "security-rate-limiting":
        "rateLimiting",

    "security-monitor":
        "securityMonitor",

    "security-automatic-response":
        "automaticResponse",

    "security-logs":
        "securityLogs",

    "security-csp":
        "csp",

    "security-alerts":
        "suspiciousAlerts",

    "security-strict-mode":
        "strictMode"

};


// ==========================
// Load Security Settings
// ==========================

function loadSecuritySettings(){

    if(!window.SmartClassSecuritySettings){

        console.error(
            "SmartClassSecuritySettings پیدا نشد."
        );

        return;

    }


    Object.keys(
        securitySettingMap
    ).forEach(
        (elementId)=>{

            const element =
            document.getElementById(
                elementId
            );

            const settingName =
            securitySettingMap[
                elementId
            ];


            if(!element)
                return;


            const value =
            window.SmartClassSecuritySettings.get(
                settingName
            );


            if(
                value !== null &&
                value !== undefined
            ){

                /*
                 * HTML از enabled / disabled استفاده می‌کند.
                 * بنابراین مقدار Boolean تنظیمات امنیتی
                 * به همین دو مقدار تبدیل می‌شود.
                 */

                element.value =
                    value
                    ? "enabled"
                    : "disabled";

            }

        }
    );

}


// ==========================
// Save Security Settings
// ==========================

function saveSecuritySettings(){

    if(!window.SmartClassSecuritySettings){

        alert(
            "سیستم تنظیمات امنیتی بارگذاری نشده است."
        );

        return;

    }


    Object.keys(
        securitySettingMap
    ).forEach(
        (elementId)=>{

            const element =
            document.getElementById(
                elementId
            );

            const settingName =
            securitySettingMap[
                elementId
            ];


            if(!element)
                return;


            /*
             * HTML از enabled / disabled استفاده می‌کند.
             * پس enabled یعنی true و disabled یعنی false.
             */

            const value =
                element.value === "enabled";


            window.SmartClassSecuritySettings.set(
                settingName,
                value
            );

        }
    );


    alert(
        "تنظیمات امنیتی با موفقیت ذخیره شد."
    );


    updateSecurityReport();

}


// ==========================
// Security Settings Events
// ==========================

document.addEventListener(
    "DOMContentLoaded",
    ()=>{

        loadSecuritySettings();


        const saveSecurityButton =
        document.getElementById(
            "save-security-settings"
        );


        if(saveSecurityButton){

            saveSecurityButton.addEventListener(
                "click",
                saveSecuritySettings
            );

        }

    }
);


// ==================================================
// SmartClass Security Report
// ==================================================

function updateSecurityReport(){

    if(!window.SmartClassSecurityReport){

        console.error(
            "SmartClassSecurityReport پیدا نشد."
        );

        return;

    }


    const report =
    window.SmartClassSecurityReport.getSummary();


    const totalElement =
    document.getElementById(
        "security-report-total"
    );


    const riskElement =
    document.getElementById(
        "security-report-risk"
    );


    const statusElement =
    document.getElementById(
        "security-report-status"
    );


    // تعداد کل رویدادها

    if(totalElement){

        totalElement.textContent =
            report.total;

    }


    // مجموع رویدادهای پرخطر

    if(riskElement){

        riskElement.textContent =
            Number(report.high || 0) +
            Number(report.critical || 0);

    }


    // وضعیت کلی امنیت

    if(statusElement){

        statusElement.textContent =
            report.status || "NORMAL";

    }

}


// ==========================
// Security Report Events
// ==========================

document.addEventListener(
    "DOMContentLoaded",
    ()=>{

        updateSecurityReport();


        const refreshButton =
        document.getElementById(
            "security-refresh-report"
        );


        if(refreshButton){

            refreshButton.addEventListener(
                "click",
                ()=>{

                    updateSecurityReport();

                }

            );

        }

    }
);


// ==========================
// Admin Panel Loaded
// ==========================

console.log(
    "SmartClass Admin Panel Loaded Successfully 🚀"
);
// ==========================
// Admin Logout
// ==========================


const logoutButton =
document.getElementById("logout");



if(logoutButton){


    logoutButton.addEventListener("click",()=>{


        localStorage.removeItem(
            "admin_logged_in"
        );


        window.location.href =
        "admin-login.html";


    });


}