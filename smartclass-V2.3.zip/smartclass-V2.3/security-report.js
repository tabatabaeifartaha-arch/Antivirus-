"use strict";

// ==========================================
// SmartClass Security Report
// ==========================================

window.SmartClassSecurityReport = (function () {

    const VERSION = "1.0";

    // ==========================================
    // Get Logs
    // ==========================================

    function getLogs() {

        if (
            !window.SmartClassSecurityLog ||
            typeof window.SmartClassSecurityLog.getLogs !== "function"
        ) {
            return [];
        }

        try {

            return window.SmartClassSecurityLog.getLogs();

        } catch (error) {

            console.error(
                "Security Report: خطا در دریافت لاگ‌ها",
                error
            );

            return [];

        }

    }


    // ==========================================
    // Summary
    // ==========================================

    function getSummary() {

        const logs = getLogs();

        let info = 0;
        let low = 0;
        let medium = 0;
        let high = 0;
        let critical = 0;


        logs.forEach(function (log) {

            const level =
                String(
                    log.level || "INFO"
                ).toUpperCase();


            switch (level) {

                case "LOW":
                    low++;
                    break;

                case "MEDIUM":
                    medium++;
                    break;

                case "HIGH":
                    high++;
                    break;

                case "CRITICAL":
                    critical++;
                    break;

                default:
                    info++;

            }

        });


        let status = "NORMAL";


        if (critical > 0) {

            status = "CRITICAL";

        } else if (high > 0) {

            status = "HIGH";

        } else if (medium > 0) {

            status = "MEDIUM";

        } else if (low > 0) {

            status = "LOW";

        }


        return {

            total: logs.length,

            info: info,

            low: low,

            medium: medium,

            high: high,

            critical: critical,

            status: status

        };

    }


    // ==========================================
    // Latest Logs
    // ==========================================

    function getLatest(limit) {

        const logs = getLogs();

        const amount =
            Number(limit) > 0
            ? Math.floor(Number(limit))
            : 10;


        return logs
            .slice()
            .reverse()
            .slice(0, amount);

    }


    // ==========================================
    // Latest High Risk Activity
    // ==========================================

    function getLatestHighRisk() {

        const logs =
            getLogs()
            .slice()
            .reverse();


        for (
            let i = 0;
            i < logs.length;
            i++
        ) {

            const level =
                String(
                    logs[i].level || ""
                ).toUpperCase();


            if (
                level === "HIGH" ||
                level === "CRITICAL"
            ) {

                return logs[i];

            }

        }


        return null;

    }


    // ==========================================
    // Get Full Report
    // ==========================================

    function getFullReport() {

        return {

            version: VERSION,

            summary: getSummary(),

            latest: getLatest(10),

            latestHighRisk:
                getLatestHighRisk()

        };

    }


    // ==========================================
    // Public API
    // ==========================================

    return {

        version: VERSION,

        getSummary: getSummary,

        getLatest: getLatest,

        getLatestHighRisk: getLatestHighRisk,

        getFullReport: getFullReport

    };

})();