"use strict";

// ============================================================
// SmartClass Security Alert
// Version 1.0
// ============================================================

window.SmartClassSecurityAlert = (function () {

    const VERSION = "1.0";

    const LEVELS = {
        INFO: "INFO",
        LOW: "LOW",
        MEDIUM: "MEDIUM",
        HIGH: "HIGH",
        CRITICAL: "CRITICAL"
    };

    const CONFIG = {
        maxAlerts: 100,
        maxMessageLength: 300,
        maxReasonLength: 300,
        duplicateWindow: 5000
    };

    let alerts = [];

    let statistics = {
        total: 0,
        info: 0,
        low: 0,
        medium: 0,
        high: 0,
        critical: 0,
        dismissed: 0
    };


    // =========================================================
    // Safe String
    // =========================================================

    function safeString(
        value,
        maxLength
    ) {

        try {

            return String(value)
                .normalize("NFKC")
                .replace(
                    /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g,
                    ""
                )
                .replace(
                    /[\u200B-\u200D\uFEFF]/g,
                    ""
                )
                .trim()
                .slice(
                    0,
                    maxLength ||
                    CONFIG.maxMessageLength
                );

        } catch (error) {

            return "";

        }

    }


    // =========================================================
    // Safe Log
    // =========================================================

    function log(
        level,
        type,
        message,
        details
    ) {

        try {

            if (
                window.SmartClassSecurityLog &&
                typeof window.SmartClassSecurityLog.log ===
                "function"
            ) {

                window.SmartClassSecurityLog.log(
                    level,
                    type,
                    message,
                    details || {}
                );

            }

        } catch (error) {

            console.error(
                "Security Alert Log Error:",
                error
            );

        }

    }


    // =========================================================
    // Normalize Level
    // =========================================================

    function normalizeLevel(
        level
    ) {

        const value =
            safeString(
                level,
                20
            ).toUpperCase();


        if (
            Object.prototype.hasOwnProperty.call(
                LEVELS,
                value
            )
        ) {

            return value;

        }


        return LEVELS.INFO;

    }


    // =========================================================
    // Check Duplicate
    // =========================================================

    function isDuplicate(
        type,
        message
    ) {

        const now =
            Date.now();


        return alerts.some(
            function (alert) {

                return (
                    alert.type === type &&
                    alert.message === message &&
                    now - alert.timestamp <=
                    CONFIG.duplicateWindow
                );

            }
        );

    }


    // =========================================================
    // Add Alert
    // =========================================================

    function add(
        level,
        type,
        message,
        details
    ) {

        const normalizedLevel =
            normalizeLevel(level);


        const safeType =
            safeString(
                type || "SECURITY_ALERT",
                100
            );


        const safeMessage =
            safeString(
                message || "Security event detected.",
                CONFIG.maxMessageLength
            );


        if (
            isDuplicate(
                safeType,
                safeMessage
            )
        ) {

            return {

                success:
                    false,

                duplicate:
                    true,

                alert:
                    null

            };

        }


        const alert = {

            id:
                "alert_" +
                Date.now() +
                "_" +
                Math.random()
                    .toString(36)
                    .slice(2, 8),

            level:
                normalizedLevel,

            type:
                safeType,

            message:
                safeMessage,

            details:
                sanitizeDetails(details),

            timestamp:
                Date.now(),

            dismissed:
                false

        };


        alerts.push(alert);


        if (
            alerts.length >
            CONFIG.maxAlerts
        ) {

            alerts.shift();

        }


        statistics.total++;


        switch (
            normalizedLevel
        ) {

            case LEVELS.LOW:
                statistics.low++;
                break;

            case LEVELS.MEDIUM:
                statistics.medium++;
                break;

            case LEVELS.HIGH:
                statistics.high++;
                break;

            case LEVELS.CRITICAL:
                statistics.critical++;
                break;

            default:
                statistics.info++;

        }


        if (
            normalizedLevel ===
            LEVELS.CRITICAL
        ) {

            log(
                "CRITICAL",
                "SECURITY_ALERT_CRITICAL",
                safeMessage,
                {
                    type:
                        safeType
                }
            );

        } else if (
            normalizedLevel ===
            LEVELS.HIGH
        ) {

            log(
                "HIGH",
                "SECURITY_ALERT_HIGH",
                safeMessage,
                {
                    type:
                        safeType
                }
            );

        }


        return {

            success:
                true,

            duplicate:
                false,

            alert:
                { ...alert }

        };

    }


    // =========================================================
    // Sanitize Details
    // =========================================================

    function sanitizeDetails(
        details
    ) {

        if (
            !details ||
            typeof details !== "object"
        ) {

            return {};

        }


        const output = {};
        const keys =
            Object.keys(details)
                .slice(0, 20);


        keys.forEach(
            function (key) {

                const safeKey =
                    safeString(
                        key,
                        80
                    );


                if (!safeKey) {
                    return;
                }


                const value =
                    details[key];


                if (
                    typeof value === "string"
                ) {

                    output[safeKey] =
                        safeString(
                            value,
                            300
                        );

                } else if (
                    typeof value === "number" &&
                    Number.isFinite(value)
                ) {

                    output[safeKey] =
                        value;

                } else if (
                    typeof value === "boolean"
                ) {

                    output[safeKey] =
                        value;

                }

            }
        );


        return output;

    }


    // =========================================================
    // Convenience Alerts
    // =========================================================

    function info(
        type,
        message,
        details
    ) {

        return add(
            LEVELS.INFO,
            type,
            message,
            details
        );

    }


    function low(
        type,
        message,
        details
    ) {

        return add(
            LEVELS.LOW,
            type,
            message,
            details
        );

    }


    function medium(
        type,
        message,
        details
    ) {

        return add(
            LEVELS.MEDIUM,
            type,
            message,
            details
        );

    }


    function high(
        type,
        message,
        details
    ) {

        return add(
            LEVELS.HIGH,
            type,
            message,
            details
        );

    }


    function critical(
        type,
        message,
        details
    ) {

        return add(
            LEVELS.CRITICAL,
            type,
            message,
            details
        );

    }


    // =========================================================
    // Dismiss Alert
    // =========================================================

    function dismiss(
        id
    ) {

        const safeId =
            safeString(
                id,
                100
            );


        const alert =
            alerts.find(
                function (item) {

                    return item.id === safeId;

                }
            );


        if (!alert) {

            return false;

        }


        if (
            !alert.dismissed
        ) {

            alert.dismissed =
                true;

            statistics.dismissed++;

        }


        return true;

    }


    // =========================================================
    // Get Alerts
    // =========================================================

    function getAlerts(
        includeDismissed
    ) {

        return alerts
            .filter(
                function (alert) {

                    return (
                        includeDismissed === true ||
                        !alert.dismissed
                    );

                }
            )
            .map(
                function (alert) {

                    return {

                        ...alert,

                        details:
                            {
                                ...alert.details
                            }

                    };

                }
            );

    }


    // =========================================================
    // Get Latest
    // =========================================================

    function getLatest(
        limit
    ) {

        let count =
            Number(limit);


        if (
            !Number.isFinite(count) ||
            count < 1
        ) {

            count = 10;

        }


        count =
            Math.min(
                Math.floor(count),
                CONFIG.maxAlerts
            );


        return getAlerts(true)
            .slice(-count)
            .reverse();

    }


    // =========================================================
    // Get Statistics
    // =========================================================

    function getStatistics() {

        return {

            version:
                VERSION,

            ...statistics,

            active:
                alerts.filter(
                    function (alert) {

                        return !alert.dismissed;

                    }
                ).length

        };

    }


    // =========================================================
    // Clear
    // =========================================================

    function clear() {

        alerts = [];


        return true;

    }


    // =========================================================
    // Reset Statistics
    // =========================================================

    function resetStatistics() {

        statistics = {

            total: 0,
            info: 0,
            low: 0,
            medium: 0,
            high: 0,
            critical: 0,
            dismissed: 0

        };


        return true;

    }


    // =========================================================
    // Public API
    // =========================================================

    return {

        version:
            VERSION,

        levels:
            { ...LEVELS },

        add:
            add,

        info:
            info,

        low:
            low,

        medium:
            medium,

        high:
            high,

        critical:
            critical,

        dismiss:
            dismiss,

        getAlerts:
            getAlerts,

        getLatest:
            getLatest,

        getStatistics:
            getStatistics,

        clear:
            clear,

        resetStatistics:
            resetStatistics

    };

})();