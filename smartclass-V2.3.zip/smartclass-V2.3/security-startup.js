"use strict";

// ============================================================
// SmartClass Security Startup
// Version 1.0
// ============================================================

window.SmartClassSecurityStartup = (function () {

    const VERSION = "1.0";

    const STATUS = {
        IDLE: "IDLE",
        STARTING: "STARTING",
        READY: "READY",
        PARTIAL: "PARTIAL",
        FAILED: "FAILED"
    };

    const REQUIRED_MODULES = [
        "SmartClassSecurityLog",
        "SmartClassSecurityRules",
        "SmartClassSecurityRate",
        "SmartClassSecurityMonitor",
        "SmartClassSecurityResponse",
        "SmartClassSecuritySettings",
        "SmartClassSecurityStorage",
        "SmartClassSecurityIntegrity",
        "SmartClassSecurityFailSafe",
        "SmartClassSecurityHealth",
        "SmartClassSecurityAccess",
        "SmartClassSecurityData",
        "SmartClassSecurityCSP",
        "SmartClassSecurityUI",
        "SmartClassSecurityReport"
    ];

    let state = {
        status: STATUS.IDLE,
        started: false,
        startedAt: null,
        readyAt: null,
        availableModules: 0,
        missingModules: [],
        errors: []
    };


    // =========================================================
    // Safe Log
    // =========================================================

    function log(
        level,
        type,
        message,
        details
    ) {

        try {

            if (
                window.SmartClassSecurityLog &&
                typeof window.SmartClassSecurityLog.log ===
                "function"
            ) {

                window.SmartClassSecurityLog.log(
                    level,
                    type,
                    message,
                    details || {}
                );

            }

        } catch (error) {

            console.error(
                "Security Startup Log Error:",
                error
            );

        }

    }


    // =========================================================
    // Safe Error
    // =========================================================

    function safeError(
        error
    ) {

        try {

            if (
                error instanceof Error
            ) {

                return error.message
                    .slice(0, 300);

            }

            return String(error)
                .slice(0, 300);

        } catch (e) {

            return "Unknown startup error.";

        }

    }


    // =========================================================
    // Check Module
    // =========================================================

    function moduleExists(
        name
    ) {

        try {

            return Boolean(
                window[name]
            );

        } catch (error) {

            return false;

        }

    }


    // =========================================================
    // Check Modules
    // =========================================================

    function checkModules() {

        const missing = [];
        let available = 0;


        REQUIRED_MODULES.forEach(
            function (name) {

                if (
                    moduleExists(name)
                ) {

                    available++;

                } else {

                    missing.push(name);

                }

            }
        );


        state.availableModules =
            available;

        state.missingModules =
            missing;


        return {

            available:
                available,

            total:
                REQUIRED_MODULES.length,

            missing:
                [...missing],

            complete:
                missing.length === 0

        };

    }


    // =========================================================
    // Safe Initialize Module
    // =========================================================

    function initializeModule(
        name
    ) {

        try {

            if (
                !moduleExists(name)
            ) {

                return {

                    success:
                        false,

                    reason:
                        "MODULE_MISSING"

                };

            }


            const module =
                window[name];


            /*
             * فقط متدهای شناخته‌شده را در صورت
             * وجود بررسی می‌کنیم.
             *
             * هیچ متدی را اجباری اجرا نمی‌کنیم.
             */

            if (
                typeof module === "object"
            ) {

                return {

                    success:
                        true,

                    reason:
                        "AVAILABLE"

                };

            }


            return {

                success:
                    false,

                reason:
                    "INVALID_MODULE"

            };

        } catch (error) {

            return {

                success:
                    false,

                reason:
                    safeError(error)

            };

        }

    }


    // =========================================================
    // Start
    // =========================================================

    function start() {

        if (
            state.started &&
            (
                state.status === STATUS.READY ||
                state.status === STATUS.PARTIAL
            )
        ) {

            return getStatus();

        }


        state.status =
            STATUS.STARTING;

        state.started =
            false;

        state.startedAt =
            Date.now();

        state.readyAt =
            null;

        state.errors =
            [];


        try {

            const moduleCheck =
                checkModules();


            if (
                moduleCheck.available === 0
            ) {

                state.status =
                    STATUS.FAILED;

                state.errors.push(
                    "No security modules are available."
                );


                log(
                    "CRITICAL",
                    "SECURITY_STARTUP_FAILED",
                    "هیچ ماژول امنیتی در دسترس نیست."
                );


                return getStatus();

            }


            REQUIRED_MODULES.forEach(
                function (name) {

                    const result =
                        initializeModule(
                            name
                        );


                    if (
                        !result.success &&
                        moduleCheck.missing.indexOf(name) === -1
                    ) {

                        state.errors.push(
                            name + ": " +
                            result.reason
                        );

                    }

                }
            );


            state.started =
                true;

            state.readyAt =
                Date.now();


            if (
                moduleCheck.complete &&
                state.errors.length === 0
            ) {

                state.status =
                    STATUS.READY;


                log(
                    "INFO",
                    "SECURITY_STARTUP_READY",
                    "سیستم امنیتی آماده است."
                );

            } else {

                state.status =
                    STATUS.PARTIAL;


                log(
                    "HIGH",
                    "SECURITY_STARTUP_PARTIAL",
                    "سیستم امنیتی به‌صورت ناقص آماده شد.",
                    {
                        available:
                            moduleCheck.available,

                        total:
                            moduleCheck.total,

                        missing:
                            moduleCheck.missing
                    }
                );

            }


        } catch (error) {

            state.status =
                STATUS.FAILED;

            state.errors.push(
                safeError(error)
            );


            log(
                "CRITICAL",
                "SECURITY_STARTUP_ERROR",
                "خطا هنگام راه‌اندازی سیستم امنیتی."
            );

        }


        return getStatus();

    }


    // =========================================================
    // Stop
    // =========================================================

    function stop() {

        state.started =
            false;

        state.status =
            STATUS.IDLE;

        state.readyAt =
            null;


        log(
            "INFO",
            "SECURITY_STARTUP_STOPPED",
            "راه‌اندازی امنیتی متوقف شد."
        );


        return true;

    }


    // =========================================================
    // Is Ready
    // =========================================================

    function isReady() {

        return (
            state.started === true &&
            (
                state.status === STATUS.READY ||
                state.status === STATUS.PARTIAL
            )
        );

    }


    // =========================================================
    // Get Status
    // =========================================================

    function getStatus() {

        return {

            version:
                VERSION,

            status:
                state.status,

            started:
                state.started,

            startedAt:
                state.startedAt,

            readyAt:
                state.readyAt,

            availableModules:
                state.availableModules,

            totalModules:
                REQUIRED_MODULES.length,

            missingModules:
                [...state.missingModules],

            errors:
                [...state.errors]

        };

    }


    // =========================================================
    // Reset
    // =========================================================

    function reset() {

        state = {

            status:
                STATUS.IDLE,

            started:
                false,

            startedAt:
                null,

            readyAt:
                null,

            availableModules:
                0,

            missingModules:
                [],

            errors:
                []

        };


        return true;

    }


    // =========================================================
    // Public API
    // =========================================================

    return {

        version:
            VERSION,

        statuses:
            { ...STATUS },

        start:
            start,

        stop:
            stop,

        isReady:
            isReady,

        checkModules:
            checkModules,

        getStatus:
            getStatus,

        reset:
            reset

    };

})();