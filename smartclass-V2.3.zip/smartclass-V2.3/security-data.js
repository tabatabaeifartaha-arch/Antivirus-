"use strict";

// ============================================================
// SmartClass Security Data Protection
// Version 1.0
// ============================================================

window.SmartClassSecurityData = (function () {

    const VERSION = "1.0";

    const STATUS = {
        VALID: "VALID",
        INVALID: "INVALID",
        SUSPICIOUS: "SUSPICIOUS",
        BLOCKED: "BLOCKED"
    };

    const CONFIG = {
        maxStringLength: 500,
        maxNameLength: 100,
        maxIdLength: 100,
        maxArrayLength: 1000,
        maxObjectKeys: 100,
        maxDepth: 8,
        maxNumber: 1000000000
    };

    let statistics = {
        checks: 0,
        valid: 0,
        invalid: 0,
        suspicious: 0,
        blocked: 0
    };


    // =========================================================
    // Safe Log
    // =========================================================

    function log(
        level,
        type,
        message,
        details
    ) {

        try {

            if (
                window.SmartClassSecurityLog &&
                typeof window.SmartClassSecurityLog.log ===
                "function"
            ) {

                window.SmartClassSecurityLog.log(
                    level,
                    type,
                    message,
                    details || {}
                );

            }

        } catch (error) {

            console.error(
                "Security Data Log Error:",
                error
            );

        }

    }


    // =========================================================
    // Safe String
    // =========================================================

    function safeString(
        value,
        maxLength
    ) {

        try {

            return String(value)
                .normalize("NFKC")
                .replace(
                    /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g,
                    ""
                )
                .replace(
                    /[\u200B-\u200D\uFEFF]/g,
                    ""
                )
                .trim()
                .slice(
                    0,
                    maxLength ||
                    CONFIG.maxStringLength
                );

        } catch (error) {

            return "";

        }

    }


    // =========================================================
    // Validate String
    // =========================================================

    function validateString(
        value,
        options
    ) {

        options =
            options || {};


        const maxLength =
            Number.isFinite(
                Number(options.maxLength)
            )
                ? Number(options.maxLength)
                : CONFIG.maxStringLength;


        if (
            typeof value !== "string"
        ) {

            return {

                valid:
                    false,

                reason:
                    "Value must be a string."

            };

        }


        if (
            value.length === 0 &&
            options.allowEmpty !== true
        ) {

            return {

                valid:
                    false,

                reason:
                    "String cannot be empty."

            };

        }


        if (
            value.length >
            maxLength
        ) {

            return {

                valid:
                    false,

                reason:
                    "String is too long."

            };

        }


        if (
            /[\u0000]/.test(value)
        ) {

            return {

                valid:
                    false,

                reason:
                    "Null byte detected."

            };

        }


        return {

            valid:
                true,

            reason:
                null

        };

    }


    // =========================================================
    // Detect Dangerous Patterns
    // =========================================================

    function inspectString(
        value
    ) {

        const result = {

            suspicious:
                false,

            score:
                0,

            matches:
                []

        };


        if (
            typeof value !== "string"
        ) {

            return result;

        }


        const patterns = [

            {
                pattern:
                    /<script\b/i,

                score:
                    50,

                name:
                    "SCRIPT_TAG"
            },

            {
                pattern:
                    /javascript\s*:/i,

                score:
                    50,

                name:
                    "JAVASCRIPT_SCHEME"
            },

            {
                pattern:
                    /vbscript\s*:/i,

                score:
                    50,

                name:
                    "VBSCRIPT_SCHEME"
            },

            {
                pattern:
                    /<iframe\b/i,

                score:
                    35,

                name:
                    "IFRAME"
            },

            {
                pattern:
                    /<object\b/i,

                score:
                    35,

                name:
                    "OBJECT"
            },

            {
                pattern:
                    /<embed\b/i,

                score:
                    35,

                name:
                    "EMBED"
            },

            {
                pattern:
                    /on[a-z]+\s*=/i,

                score:
                    45,

                name:
                    "EVENT_HANDLER"
            },

            {
                pattern:
                    /data\s*:\s*text\/html/i,

                score:
                    45,

                name:
                    "HTML_DATA_URI"
            },

            {
                pattern:
                    /eval\s*\(/i,

                score:
                    40,

                name:
                    "EVAL"
            },

            {
                pattern:
                    /Function\s*\(/i,

                score:
                    40,

                name:
                    "FUNCTION_CONSTRUCTOR"
            },

            {
                pattern:
                    /<svg\b/i,

                score:
                    30,

                name:
                    "SVG"
            },

            {
                pattern:
                    /<style\b/i,

                score:
                    20,

                name:
                    "STYLE_TAG"
            }

        ];


        patterns.forEach(
            function (item) {

                try {

                    if (
                        item.pattern.test(
                            value
                        )
                    ) {

                        result.suspicious = true;

                        result.score +=
                            item.score;

                        result.matches.push(
                            item.name
                        );

                    }

                } catch (error) {

                    // Ignore individual pattern errors.

                }

            }
        );


        result.score =
            Math.min(
                result.score,
                100
            );


        return result;

    }


    // =========================================================
    // Calculate Object Depth
    // =========================================================

    function getDepth(
        value,
        depth,
        seen
    ) {

        depth =
            Number.isFinite(depth)
                ? depth
                : 0;

        seen =
            seen ||
            new WeakSet();


        if (
            value === null ||
            typeof value !== "object"
        ) {

            return depth;

        }


        if (
            depth >
            CONFIG.maxDepth
        ) {

            return depth;

        }


        if (
            seen.has(value)
        ) {

            return CONFIG.maxDepth + 1;

        }


        seen.add(value);


        let maxDepth =
            depth;


        if (
            Array.isArray(value)
        ) {

            if (
                value.length >
                CONFIG.maxArrayLength
            ) {

                return CONFIG.maxDepth + 1;

            }


            value.forEach(
                function (item) {

                    maxDepth =
                        Math.max(
                            maxDepth,
                            getDepth(
                                item,
                                depth + 1,
                                seen
                            )
                        );

                }
            );

        } else {

            const keys =
                Object.keys(value);


            if (
                keys.length >
                CONFIG.maxObjectKeys
            ) {

                return CONFIG.maxDepth + 1;

            }


            keys.forEach(
                function (key) {

                    maxDepth =
                        Math.max(
                            maxDepth,
                            getDepth(
                                value[key],
                                depth + 1,
                                seen
                            )
                        );

                }
            );

        }


        return maxDepth;

    }


    // =========================================================
    // Generic Data Check
    // =========================================================

    function inspect(
        value
    ) {

        statistics.checks++;


        try {

            const depth =
                getDepth(
                    value,
                    0
                );


            if (
                depth >
                CONFIG.maxDepth
            ) {

                statistics.blocked++;


                log(
                    "HIGH",
                    "DATA_DEPTH_BLOCKED",
                    "داده بیش از حد تو در تو مسدود شد."
                );


                return {

                    valid:
                        false,

                    status:
                        STATUS.BLOCKED,

                    score:
                        100,

                    reason:
                        "Maximum data depth exceeded.",

                    matches:
                        []

                };

            }


            const serialized =
                JSON.stringify(
                    value
                );


            if (
                typeof serialized !==
                "string"
            ) {

                statistics.invalid++;


                return {

                    valid:
                        false,

                    status:
                        STATUS.INVALID,

                    score:
                        80,

                    reason:
                        "Data serialization failed.",

                    matches:
                        []

                };

            }


            const inspection =
                inspectString(
                    serialized
                );


            if (
                inspection.score >= 70
            ) {

                statistics.blocked++;


                log(
                    "HIGH",
                    "DATA_SUSPICIOUS_BLOCKED",
                    "داده مشکوک مسدود شد.",
                    {
                        score:
                            inspection.score,

                        matches:
                            inspection.matches
                    }
                );


                return {

                    valid:
                        false,

                    status:
                        STATUS.BLOCKED,

                    score:
                        inspection.score,

                    reason:
                        "Suspicious data detected.",

                    matches:
                        inspection.matches

                };

            }


            if (
                inspection.suspicious
            ) {

                statistics.suspicious++;


                return {

                    valid:
                        true,

                    status:
                        STATUS.SUSPICIOUS,

                    score:
                        inspection.score,

                    reason:
                        "Suspicious pattern detected.",

                    matches:
                        inspection.matches

                };

            }


            statistics.valid++;


            return {

                valid:
                    true,

                status:
                    STATUS.VALID,

                score:
                    0,

                reason:
                    null,

                matches:
                    []

            };

        } catch (error) {

            statistics.invalid++;


            log(
                "CRITICAL",
                "DATA_INSPECTION_ERROR",
                "خطا هنگام بررسی داده."
            );


            return {

                valid:
                    false,

                status:
                    STATUS.INVALID,

                score:
                    100,

                reason:
                    "Data inspection failed.",

                matches:
                    []

            };

        }

    }


    // =========================================================
    // Student Data
    // =========================================================

    function validateStudent(
        student
    ) {

        if (
            !student ||
            typeof student !== "object"
        ) {

            return {

                valid:
                    false,

                status:
                    STATUS.INVALID,

                reason:
                    "Invalid student object."

            };

        }


        const name =
            safeString(
                student.name,
                CONFIG.maxNameLength
            );


        const grade =
            safeString(
                student.grade,
                50
            );


        if (
            !validateString(
                name,
                {
                    maxLength:
                        CONFIG.maxNameLength
                }
            ).valid
        ) {

            return {

                valid:
                    false,

                status:
                    STATUS.INVALID,

                reason:
                    "Invalid student name."

            };

        }


        if (
            grade.length > 50
        ) {

            return {

                valid:
                    false,

                status:
                    STATUS.INVALID,

                reason:
                    "Invalid student grade."

            };

        }


        const inspection =
            inspect({
                name:
                    name,

                grade:
                    grade
            });


        return inspection;

    }


    // =========================================================
    // Bell Data
    // =========================================================

    function validateBell(
        bell
    ) {

        if (
            !bell ||
            typeof bell !== "object"
        ) {

            return {

                valid:
                    false,

                status:
                    STATUS.INVALID,

                reason:
                    "Invalid bell object."

            };

        }


        const title =
            safeString(
                bell.title,
                100
            );


        const time =
            safeString(
                bell.time,
                20
            );


        if (
            title &&
            title.length > 100
        ) {

            return {

                valid:
                    false,

                status:
                    STATUS.INVALID,

                reason:
                    "Bell title is too long."

            };

        }


        if (
            time &&
            !/^\d{1,2}:\d{2}$/.test(time)
        ) {

            return {

                valid:
                    false,

                status:
                    STATUS.INVALID,

                reason:
                    "Invalid bell time."

            };

        }


        return inspect({

            title:
                title,

            time:
                time

        });

    }


    // =========================================================
    // Settings Data
    // =========================================================

    function validateSettings(
        settings
    ) {

        if (
            !settings ||
            typeof settings !== "object"
        ) {

            return {

                valid:
                    false,

                status:
                    STATUS.INVALID,

                reason:
                    "Invalid settings object."

            };

        }


        const allowedBooleanKeys = [

            "bellStatus",

            "sound",

            "notifications",

            "darkMode"

        ];


        for (
            let i = 0;
            i < allowedBooleanKeys.length;
            i++
        ) {

            const key =
                allowedBooleanKeys[i];


            if (
                Object.prototype.hasOwnProperty.call(
                    settings,
                    key
                ) &&
                typeof settings[key] !==
                "boolean"
            ) {

                return {

                    valid:
                        false,

                    status:
                        STATUS.INVALID,

                    reason:
                        "Invalid boolean setting."

                };

            }

        }


        return inspect(
            settings
        );

    }


    // =========================================================
    // Sanitize Object
    // =========================================================

    function sanitize(
        value,
        depth,
        seen
    ) {

        depth =
            Number.isFinite(depth)
                ? depth
                : 0;

        seen =
            seen ||
            new WeakSet();


        if (
            depth >
            CONFIG.maxDepth
        ) {

            return null;

        }


        if (
            value === null
        ) {

            return null;

        }


        if (
            typeof value === "string"
        ) {

            return safeString(
                value
            );

        }


        if (
            typeof value === "number"
        ) {

            if (
                !Number.isFinite(value) ||
                Math.abs(value) >
                CONFIG.maxNumber
            ) {

                return null;

            }

            return value;

        }


        if (
            typeof value === "boolean"
        ) {

            return value;

        }


        if (
            typeof value !== "object"
        ) {

            return null;

        }


        if (
            seen.has(value)
        ) {

            return null;

        }


        seen.add(value);


        if (
            Array.isArray(value)
        ) {

            if (
                value.length >
                CONFIG.maxArrayLength
            ) {

                return [];

            }


            return value.map(
                function (item) {

                    return sanitize(
                        item,
                        depth + 1,
                        seen
                    );

                }
            );

        }


        const output = {};

        const keys =
            Object.keys(value)
                .slice(
                    0,
                    CONFIG.maxObjectKeys
                );


        keys.forEach(
            function (key) {

                const cleanKey =
                    safeString(
                        key,
                        100
                    );


                if (
                    !cleanKey ||
                    cleanKey === "__proto__" ||
                    cleanKey === "prototype" ||
                    cleanKey === "constructor"
                ) {

                    return;

                }


                output[cleanKey] =
                    sanitize(
                        value[key],
                        depth + 1,
                        seen
                    );

            }
        );


        return output;

    }


    // =========================================================
    // Statistics
    // =========================================================

    function getStatistics() {

        return {

            version:
                VERSION,

            ...statistics

        };

    }


    // =========================================================
    // Reset
    // =========================================================

    function resetStatistics() {

        statistics = {

            checks:
                0,

            valid:
                0,

            invalid:
                0,

            suspicious:
                0,

            blocked:
                0

        };


        return true;

    }


    // =========================================================
    // Public API
    // =========================================================

    return {

        version:
            VERSION,

        statuses:
            { ...STATUS },

        inspect:
            inspect,

        validateStudent:
            validateStudent,

        validateBell:
            validateBell,

        validateSettings:
            validateSettings,

        sanitize:
            sanitize,

        getStatistics:
            getStatistics,

        resetStatistics:
            resetStatistics

    };

})();