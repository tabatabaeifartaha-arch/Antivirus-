"use strict";

/* =========================================
   SmartClass
   Admin Login System
========================================= */


const passwordInput =
    document.getElementById("admin-password");


const loginButton =
    document.getElementById("login-button");


const loginMessage =
    document.getElementById("login-message");



/*
 * =========================================
 * رمز پنل مدیریت
 * =========================================
 *
 * توجه:
 * این رمز داخل JavaScript قرار دارد و بنابراین
 * برای امنیت واقعی مناسب نیست.
 *
 * احراز هویت واقعی باید در Backend انجام شود.
 */

const ADMIN_PASSWORD = "123456";



/*
 * =========================================
 * Login Protection
 * =========================================
 */

const LOGIN_LIMIT = 5;

const LOGIN_WINDOW = 60 * 1000;

const LOGIN_LOCK_TIME = 30 * 1000;


let loginAttempts = 0;

let loginWindowStart = Date.now();

let loginLockedUntil = 0;



/*
 * =========================================
 * Security Logger
 * =========================================
 */

function securityLog(
    event,
    message,
    level = "INFO"
) {

    try {

        if (
            window.SmartClassSecurityLog
        ) {

            const logger =
                window.SmartClassSecurityLog;

            const method =
                String(level).toLowerCase();

            if (
                typeof logger[method] ===
                "function"
            ) {

                logger[method](
                    event,
                    message
                );

                return;

            }

            if (
                typeof logger.info ===
                "function"
            ) {

                logger.info(
                    event,
                    message
                );

            }

        }

    } catch (error) {

        /*
         * خطای سیستم امنیتی نباید
         * مانع عملکرد صفحه ورود شود.
         */

    }

}



/*
 * =========================================
 * Reset Login Window
 * =========================================
 */

function resetLoginWindowIfNeeded() {

    const now =
        Date.now();


    if (
        now - loginWindowStart >=
        LOGIN_WINDOW
    ) {

        loginAttempts = 0;

        loginWindowStart = now;

    }

}



/*
 * =========================================
 * Check Login Lock
 * =========================================
 */

function isLoginLocked() {

    const now =
        Date.now();


    if (
        loginLockedUntil > now
    ) {

        return true;

    }


    if (
        loginLockedUntil !== 0
    ) {

        loginLockedUntil = 0;

        loginAttempts = 0;

        loginWindowStart = now;

    }


    return false;

}



/*
 * =========================================
 * Start Temporary Login Lock
 * =========================================
 */

function lockLogin() {

    loginLockedUntil =
        Date.now() +
        LOGIN_LOCK_TIME;


    loginAttempts = 0;


    securityLog(
        "ADMIN_LOGIN_RATE_LIMIT",
        "تعداد تلاش‌های ورود بیش از حد مجاز بود.",
        "HIGH"
    );


    if (loginMessage) {

        loginMessage.style.color =
            "#d63031";

        loginMessage.innerText =
            "تلاش‌های ورود بیش از حد مجاز است. کمی بعد دوباره تلاش کنید.";

    }

}



/*
 * =========================================
 * Check Login Rate
 * =========================================
 */

function checkLoginRate() {

    resetLoginWindowIfNeeded();


    if (isLoginLocked()) {

        return false;

    }


    loginAttempts++;


    if (
        loginAttempts >
        LOGIN_LIMIT
    ) {

        lockLogin();

        return false;

    }


    return true;

}



/*
 * =========================================
 * Input Security Check
 * =========================================
 */

function inspectPasswordInput(
    value
) {

    try {

        if (
            window.SmartClassSecurityInput &&
            typeof window
                .SmartClassSecurityInput
                .inspect === "function"
        ) {

            return window
                .SmartClassSecurityInput
                .inspect(value);

        }


        if (
            window.SmartClassSecurityRules &&
            typeof window
                .SmartClassSecurityRules
                .inspect === "function"
        ) {

            return window
                .SmartClassSecurityRules
                .inspect(value);

        }

    } catch (error) {

        securityLog(
            "ADMIN_LOGIN_SECURITY_CHECK_ERROR",
            "خطا در بررسی امنیتی ورودی ورود.",
            "MEDIUM"
        );

    }


    return {
        allowed: true,
        risk: 0
    };

}



/*
 * =========================================
 * Login Function
 * =========================================
 */

function performLogin() {


    if (
        !passwordInput ||
        !loginButton ||
        !loginMessage
    ) {

        return;

    }



    /*
     * بررسی محدودیت تلاش
     */

    if (
        !checkLoginRate()
    ) {

        return;

    }



    /*
     * دریافت رمز
     */

    const enteredPassword =
        passwordInput.value.trim();



    /*
     * ورودی خالی
     */

    if (
        enteredPassword === ""
    ) {

        loginMessage.style.color =
            "#d63031";

        loginMessage.innerText =
            "لطفاً رمز عبور را وارد کنید";


        securityLog(
            "ADMIN_LOGIN_EMPTY",
            "تلاش ورود بدون وارد کردن رمز.",
            "LOW"
        );


        return;

    }



    /*
     * بررسی امنیتی ورودی
     */

    const securityResult =
        inspectPasswordInput(
            enteredPassword
        );


    if (
        securityResult &&
        Number(
            securityResult.risk
        ) >= 80
    ) {

        loginMessage.style.color =
            "#d63031";

        loginMessage.innerText =
            "ورودی نامعتبر است";


        securityLog(
            "ADMIN_LOGIN_SUSPICIOUS_INPUT",
            "ورودی مشکوک در صفحه ورود شناسایی شد.",
            "HIGH"
        );


        passwordInput.value = "";

        return;

    }



    /*
     * بررسی رمز
     */

    if (
        enteredPassword ===
        ADMIN_PASSWORD
    ) {


        loginMessage.style.color =
            "#00a878";


        loginMessage.innerText =
            "ورود موفق بود...";


        securityLog(
            "ADMIN_LOGIN_SUCCESS",
            "ورود موفق به پنل مدیریت.",
            "INFO"
        );


        /*
         * ثبت وضعیت ورود
         */

        try {

            localStorage.setItem(
                "admin_logged_in",
                "true"
            );

        } catch (error) {

            securityLog(
                "ADMIN_LOGIN_STORAGE_ERROR",
                "ذخیره وضعیت ورود انجام نشد.",
                "MEDIUM"
            );

        }



        /*
         * انتقال به پنل
         */

        setTimeout(
            function () {

                window.location.href =
                    "admin.html";

            },
            800
        );


    } else {


        loginMessage.style.color =
            "#d63031";


        loginMessage.innerText =
            "رمز عبور اشتباه است";


        passwordInput.value = "";


        securityLog(
            "ADMIN_LOGIN_FAILED",
            "تلاش ناموفق برای ورود به پنل مدیریت.",
            "WARNING"
        );


    }

}



/*
 * =========================================
 * Login Button
 * =========================================
 */

if (
    loginButton
) {

    loginButton.addEventListener(
        "click",
        performLogin
    );

}



/*
 * =========================================
 * Enter Key
 * =========================================
 */

if (
    passwordInput
) {

    passwordInput.addEventListener(
        "keydown",
        function (event) {

            if (
                event.key ===
                "Enter"
            ) {

                event.preventDefault();

                performLogin();

            }

        }
    );

}



/*
 * =========================================
 * Security Startup Log
 * =========================================
 */

securityLog(
    "ADMIN_LOGIN_PAGE_READY",
    "صفحه ورود مدیریت آماده شد.",
    "INFO"
);