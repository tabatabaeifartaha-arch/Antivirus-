"use strict";

/*
========================================
 SmartClass Security Configuration
 Version: 1.0
========================================
*/

(function () {

    const CONFIG = {

        version: "1.0",

        logging: {
            enabled: true,
            maxLogs: 300
        },

        rateLimit: {

            defaultLimit: 10,

            defaultWindowMs: 10000

        },

        monitor: {

            maxEventsPerWindow: 30,

            windowMs: 10000,

            rapidClickThreshold: 20,

            rapidClickWindowMs: 3000

        },

        response: {

            enabled: true,

            maxRestrictionMs: 30000

        }

    };


    function cloneConfig() {

        return JSON.parse(
            JSON.stringify(CONFIG)
        );

    }


    window.SmartClassSecurityConfig = {

        version: CONFIG.version,

        get: cloneConfig

    };


    console.info(
        "SmartClass Security Configuration 1.0 initialized."
    );

})();