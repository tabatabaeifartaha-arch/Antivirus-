"use strict";

// ==========================================
// SmartClass Content Security Policy
// ==========================================

window.SmartClassSecurityCSP = (function () {

    const VERSION = "1.0";

    let applied = false;


    // ==========================================
    // CSP Policy
    // ==========================================

    const POLICY = [
        "default-src 'self'",
        "base-uri 'self'",
        "form-action 'self'",
        "object-src 'none'",
        "frame-ancestors 'self'",
        "script-src 'self' https://cdnjs.cloudflare.com",
        "style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com",
        "font-src 'self' https://cdnjs.cloudflare.com",
        "img-src 'self' data: blob:",
        "media-src 'self'",
        "connect-src 'self'"
    ].join("; ");


    // ==========================================
    // Apply CSP
    // ==========================================

    function apply() {

        if (applied) {
            return true;
        }


        if (
            document.querySelector(
                'meta[http-equiv="Content-Security-Policy"]'
            )
        ) {

            applied = true;

            return true;

        }


        const meta =
            document.createElement("meta");


        meta.httpEquiv =
            "Content-Security-Policy";


        meta.content =
            POLICY;


        document.head.appendChild(
            meta
        );


        applied = true;


        if (
            window.SmartClassSecurityLog &&
            typeof window.SmartClassSecurityLog.log ===
            "function"
        ) {

            window.SmartClassSecurityLog.log(

                "INFO",

                "CSP_APPLIED",

                "سیاست امنیتی محتوا فعال شد.",

                {
                    version: VERSION
                }

            );

        }


        return true;

    }


    // ==========================================
    // Status
    // ==========================================

    function getStatus() {

        return {

            version: VERSION,

            applied:
                applied,

            policy:
                POLICY

        };

    }


    // ==========================================
    // Public API
    // ==========================================

    return {

        version: VERSION,

        apply:
            apply,

        getStatus:
            getStatus

    };

})();