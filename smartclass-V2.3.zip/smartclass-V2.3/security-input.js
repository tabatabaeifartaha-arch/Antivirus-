"use strict";

/*
 * =========================================================
 * SmartClass Security
 * Input Protection Engine
 *
 * Version: 2.0
 *
 * وظیفه:
 * - بررسی ورودی‌ها
 * - استفاده از Security Rules
 * - تشخیص ورودی مشکوک
 * - امتیازدهی ریسک
 * - ثبت رویداد امنیتی
 * - جلوگیری از پردازش ورودی خطرناک
 *
 * توجه:
 * این ماژول فعلاً مستقل است و به فرم‌های SmartClass
 * متصل نمی‌شود.
 * =========================================================
 */

window.SmartClassSecurityInput = (function () {

    "use strict";

    const VERSION = "2.0";

    const CONFIG = Object.freeze({

        enabledByDefault: true,

        maxInputLength: 5000,

        highRiskScore: 70,

        criticalRiskScore: 90,

        maxInspectionLength: 10000,

        logBlockedInput: true,

        logSuspiciousInput: true,

        normalizeInput: true,

        inspectDecodedInput: true,

        maxDecodePasses: 3

    });


    /*
     * ---------------------------------------------------------
     * وضعیت داخلی
     * ---------------------------------------------------------
     */

    let statistics = {

        inspected: 0,

        allowed: 0,

        blocked: 0,

        suspicious: 0,

        errors: 0,

        lastRiskScore: 0,

        lastInspection: null

    };


    /*
     * ---------------------------------------------------------
     * دریافت وضعیت فعال بودن سیستم
     * ---------------------------------------------------------
     */

    function isEnabled() {

        try {

            if (
                window.SmartClassSecuritySettings &&
                typeof window.SmartClassSecuritySettings.get ===
                "function"
            ) {

                const value =
                    window.SmartClassSecuritySettings.get(
                        "inputProtection"
                    );

                if (typeof value === "boolean") {
                    return value;
                }

            }

        } catch (error) {

            log(
                "medium",
                "INPUT_SETTINGS_ERROR",
                "خطا در خواندن تنظیمات محافظت ورودی.",
                {
                    error: String(error)
                }
            );

        }

        return CONFIG.enabledByDefault;
    }


    /*
     * ---------------------------------------------------------
     * تبدیل مقدار به رشته امن
     * ---------------------------------------------------------
     */

    function safeString(value) {

        if (value === null || value === undefined) {
            return "";
        }

        try {

            return String(value);

        } catch (error) {

            return "";

        }

    }


    /*
     * ---------------------------------------------------------
     * نرمال‌سازی
     * ---------------------------------------------------------
     */

    function normalize(value) {

        let text = safeString(value);

        if (!CONFIG.normalizeInput) {
            return text;
        }

        try {

            if (typeof text.normalize === "function") {

                text = text.normalize("NFKC");

            }

        } catch (error) {

            // ادامه با متن اصلی
        }


        /*
         * حذف Zero Width Characters
         */

        text = text.replace(
            /[\u200B-\u200D\uFEFF]/g,
            ""
        );


        /*
         * حذف Null Byte
         */

        text = text.replace(
            /\u0000/g,
            ""
        );


        return text.trim();

    }


    /*
     * ---------------------------------------------------------
     * Decode برای بازرسی
     *
     * فقط برای تشخیص استفاده می‌شود.
     * مقدار اصلی کاربر تغییر نمی‌کند.
     * ---------------------------------------------------------
     */

    function decodeForInspection(value) {

        let current = safeString(value);

        const results = [];

        results.push(current);


        if (!CONFIG.inspectDecodedInput) {
            return results;
        }


        for (
            let i = 0;
            i < CONFIG.maxDecodePasses;
            i++
        ) {

            try {

                const decoded =
                    decodeURIComponent(current);

                if (decoded === current) {
                    break;
                }

                results.push(decoded);

                current = decoded;

            } catch (error) {

                break;

            }

        }

        return results;

    }


    /*
     * ---------------------------------------------------------
     * بررسی طول
     * ---------------------------------------------------------
     */

    function checkLength(value) {

        const length =
            safeString(value).length;


        if (
            length >
            CONFIG.maxInputLength
        ) {

            return {

                safe: false,

                reason:
                    "INPUT_LENGTH_EXCEEDED",

                level:
                    "HIGH",

                score:
                    75

            };

        }


        return null;

    }


    /*
     * ---------------------------------------------------------
     * ثبت لاگ
     * ---------------------------------------------------------
     */

    function log(
        level,
        type,
        message,
        details
    ) {

        try {

            if (
                !window.SmartClassSecurityLog
            ) {
                return;
            }


            const logger =
                window.SmartClassSecurityLog;


            if (
                typeof logger[level] ===
                "function"
            ) {

                logger[level](
                    type,
                    message,
                    details || {}
                );

            }

        } catch (error) {

            /*
             * سیستم لاگ نباید باعث Crash شدن
             * سیستم امنیتی شود.
             */

            statistics.errors++;

        }

    }


    /*
     * ---------------------------------------------------------
     * اجرای Security Rules
     * ---------------------------------------------------------
     */

    function inspectWithRules(value) {

        if (
            !window.SmartClassSecurityRules
        ) {

            return {

                available: false,

                safe: false,

                reason:
                    "SECURITY_RULES_UNAVAILABLE",

                level:
                    "CRITICAL",

                score:
                    100,

                matches: []

            };

        }


        const rules =
            window.SmartClassSecurityRules;


        if (
            typeof rules.checkInput !==
            "function"
        ) {

            return {

                available: false,

                safe: false,

                reason:
                    "SECURITY_RULES_INVALID",

                level:
                    "CRITICAL",

                score:
                    100,

                matches: []

            };

        }


        try {

            const result =
                rules.checkInput(value);


            return {

                available: true,

                safe:
                    Boolean(result.safe),

                reason:
                    result.reason || null,

                level:
                    result.level || "INFO",

                score:
                    Number(result.score) || 0,

                matches:
                    Array.isArray(result.matches)
                        ? result.matches
                        : []

            };

        } catch (error) {

            return {

                available: false,

                safe: false,

                reason:
                    "SECURITY_RULES_ERROR",

                level:
                    "CRITICAL",

                score:
                    100,

                matches: [],

                error:
                    String(error)

            };

        }

    }


    /*
     * ---------------------------------------------------------
     * تعیین سطح ریسک
     * ---------------------------------------------------------
     */

    function getRiskLevel(score) {

        const value =
            Number(score) || 0;


        if (
            value >=
            CONFIG.criticalRiskScore
        ) {

            return "CRITICAL";

        }


        if (
            value >=
            CONFIG.highRiskScore
        ) {

            return "HIGH";

        }


        if (value >= 40) {

            return "MEDIUM";

        }


        if (value > 0) {

            return "LOW";

        }


        return "NORMAL";

    }


    /*
     * ---------------------------------------------------------
     * بازرسی اصلی
     * ---------------------------------------------------------
     */

    function inspect(value) {

        statistics.inspected++;


        /*
         * اگر سیستم خاموش باشد
         */

        if (!isEnabled()) {

            statistics.allowed++;

            return {

                allowed: true,

                blocked: false,

                disabled: true,

                riskLevel: "NORMAL",

                riskScore: 0,

                reason: null,

                matches: []

            };

        }


        const original =
            safeString(value);


        /*
         * بررسی طول اولیه
         */

        const lengthResult =
            checkLength(original);


        if (lengthResult) {

            statistics.blocked++;

            statistics.lastRiskScore =
                lengthResult.score;


            log(
                "high",
                "INPUT_LENGTH_BLOCKED",
                "ورودی بیش از حد مجاز شناسایی شد.",
                {
                    length:
                        original.length,

                    maxLength:
                        CONFIG.maxInputLength,

                    riskScore:
                        lengthResult.score
                }
            );


            return {

                allowed: false,

                blocked: true,

                disabled: false,

                riskLevel:
                    getRiskLevel(
                        lengthResult.score
                    ),

                riskScore:
                    lengthResult.score,

                reason:
                    lengthResult.reason,

                matches: []

            };

        }


        /*
         * نرمال‌سازی
         */

        const normalized =
            normalize(original);


        /*
         * بررسی نسخه اصلی و نسخه نرمال‌شده
         */

        const inspectionValues = [];

        inspectionValues.push(original);


        if (
            normalized !== original
        ) {

            inspectionValues.push(
                normalized
            );

        }


        /*
         * بررسی نسخه‌های Decode شده
         */

        const decodedVersions =
            decodeForInspection(
                normalized
            );


        decodedVersions.forEach(
            function (item) {

                if (
                    inspectionValues.indexOf(
                        item
                    ) === -1
                ) {

                    inspectionValues.push(
                        item
                    );

                }

            }
        );


        /*
         * محدود کردن حجم بازرسی
         */

        let inspectedLength = 0;

        const safeInspectionValues = [];


        for (
            let i = 0;
            i < inspectionValues.length;
            i++
        ) {

            const item =
                inspectionValues[i];


            inspectedLength +=
                item.length;


            if (
                inspectedLength >
                CONFIG.maxInspectionLength
            ) {

                break;

            }


            safeInspectionValues.push(
                item
            );

        }


        /*
         * اجرای Rules
         */

        let highestScore = 0;

        let highestLevel = "NORMAL";

        let highestReason = null;

        let allMatches = [];


        for (
            let i = 0;
            i < safeInspectionValues.length;
            i++
        ) {

            const candidate =
                safeInspectionValues[i];


            const result =
                inspectWithRules(
                    candidate
                );


            if (!result.available) {

                statistics.errors++;

                log(
                    "critical",
                    "INPUT_SECURITY_ENGINE_ERROR",
                    "موتور بررسی ورودی در دسترس نیست یا خطا دارد.",
                    {
                        reason:
                            result.reason,

                        error:
                            result.error || null
                    }
                );


                return {

                    allowed: false,

                    blocked: true,

                    disabled: false,

                    riskLevel: "CRITICAL",

                    riskScore: 100,

                    reason:
                        result.reason,

                    matches: []

                };

            }


            if (
                result.score >
                highestScore
            ) {

                highestScore =
                    result.score;

                highestLevel =
                    result.level;

                highestReason =
                    result.reason;

            }


            if (
                Array.isArray(result.matches)
            ) {

                allMatches =
                    allMatches.concat(
                        result.matches
                    );

            }

        }


        /*
         * حذف Matchهای تکراری
         */

        allMatches =
            Array.from(
                new Set(
                    allMatches.map(
                        function (item) {

                            try {
                                return JSON.stringify(item);
                            } catch (error) {
                                return String(item);
                            }

                        }
                    )
                )
            ).map(
                function (item) {

                    try {
                        return JSON.parse(item);
                    } catch (error) {
                        return item;
                    }

                }
            );


        const riskLevel =
            getRiskLevel(
                highestScore
            );


        statistics.lastRiskScore =
            highestScore;


        statistics.lastInspection =
            Date.now();


        /*
         * ورودی خطرناک
         */

        if (
            highestScore >=
            CONFIG.highRiskScore
        ) {

            statistics.blocked++;


            if (
                CONFIG.logBlockedInput
            ) {

                log(
                    highestScore >=
                    CONFIG.criticalRiskScore
                        ? "critical"
                        : "high",

                    "INPUT_BLOCKED",

                    "ورودی مشکوک توسط لایه محافظت ورودی مسدود شد.",

                    {
                        riskLevel:
                            riskLevel,

                        riskScore:
                            highestScore,

                        reason:
                            highestReason,

                        matches:
                            allMatches.slice(
                                0,
                                20
                            )
                    }
                );

            }


            return {

                allowed: false,

                blocked: true,

                disabled: false,

                riskLevel:
                    riskLevel,

                riskScore:
                    highestScore,

                reason:
                    highestReason,

                matches:
                    allMatches

            };

        }


        /*
         * ورودی مشکوک ولی هنوز
         * زیر آستانه مسدودسازی
         */

        if (
            highestScore > 0
        ) {

            statistics.suspicious++;


            if (
                CONFIG.logSuspiciousInput
            ) {

                log(
                    "medium",
                    "SUSPICIOUS_INPUT",
                    "ورودی مشکوک شناسایی شد.",
                    {
                        riskLevel:
                            riskLevel,

                        riskScore:
                            highestScore,

                        matches:
                            allMatches.slice(
                                0,
                                20
                            )
                    }
                );

            }

        }


        /*
         * ورودی سالم
         */

        statistics.allowed++;


        return {

            allowed: true,

            blocked: false,

            disabled: false,

            riskLevel:
                riskLevel,

            riskScore:
                highestScore,

            reason:
                highestReason,

            matches:
                allMatches

        };

    }


    /*
     * ---------------------------------------------------------
     * API ساده برای بررسی امن بودن
     * ---------------------------------------------------------
     */

    function isSafe(value) {

        const result =
            inspect(value);

        return Boolean(
            result.allowed
        );

    }


    /*
     * ---------------------------------------------------------
     * دریافت آمار
     * ---------------------------------------------------------
     */

    function getStatistics() {

        return {

            version:
                VERSION,

            inspected:
                statistics.inspected,

            allowed:
                statistics.allowed,

            blocked:
                statistics.blocked,

            suspicious:
                statistics.suspicious,

            errors:
                statistics.errors,

            lastRiskScore:
                statistics.lastRiskScore,

            lastInspection:
                statistics.lastInspection

        };

    }


    /*
     * ---------------------------------------------------------
     * وضعیت سیستم
     * ---------------------------------------------------------
     */

    function getStatus() {

        return {

            version:
                VERSION,

            enabled:
                isEnabled(),

            engineAvailable:
                Boolean(
                    window.SmartClassSecurityRules
                ),

            statistics:
                getStatistics(),

            configuration:
                {
                    maxInputLength:
                        CONFIG.maxInputLength,

                    highRiskScore:
                        CONFIG.highRiskScore,

                    criticalRiskScore:
                        CONFIG.criticalRiskScore,

                    maxDecodePasses:
                        CONFIG.maxDecodePasses
                }

        };

    }


    /*
     * ---------------------------------------------------------
     * Reset Statistics
     * ---------------------------------------------------------
     */

    function resetStatistics() {

        statistics = {

            inspected: 0,

            allowed: 0,

            blocked: 0,

            suspicious: 0,

            errors: 0,

            lastRiskScore: 0,

            lastInspection: null

        };

    }


    /*
     * ---------------------------------------------------------
     * API عمومی
     * ---------------------------------------------------------
     */

    return {

        version:
            VERSION,

        isEnabled:
            isEnabled,

        inspect:
            inspect,

        isSafe:
            isSafe,

        getRiskLevel:
            getRiskLevel,

        getStatistics:
            getStatistics,

        getStatus:
            getStatus,

        resetStatistics:
            resetStatistics

    };

})();