console.log("SMARTCLASS FILE RUNNING");


// ==========================
// Global Helpers
// ==========================

function getElement(id){

    return document.getElementById(id);

}


// ==========================
// Live Clock & Date
// ==========================

function updateDateTime(){

    const now = new Date();


    const hours =
    String(now.getHours()).padStart(2,"0");


    const minutes =
    String(now.getMinutes()).padStart(2,"0");


    const seconds =
    String(now.getSeconds()).padStart(2,"0");



    const timeElement =
    getElement("live-time");


    const dateElement =
    getElement("live-date");



    if(timeElement){

        timeElement.innerText =
        `${hours}:${minutes}:${seconds}`;

    }


    if(dateElement){

        dateElement.innerText =
        now.toLocaleDateString("fa-IR");

    }


}


setInterval(updateDateTime,1000);

updateDateTime();





// ==========================
// Calculator
// ==========================


const calculatorDisplay =
getElement("calculator-display");


const calculatorButtons =
document.querySelectorAll(".calc-btn");



let calculatorExpression = "";



calculatorButtons.forEach(button=>{


    button.addEventListener("click",()=>{


        const value =
        button.innerText.trim();



        // Clear

        if(value === "AC"){

            calculatorExpression = "";

            if(calculatorDisplay)
                calculatorDisplay.value = "0";

            return;

        }



        // Delete

        if(value === "⌫"){


            calculatorExpression =
            calculatorExpression.slice(0,-1);


            if(calculatorDisplay){

                calculatorDisplay.value =
                calculatorExpression || "0";

            }


            return;

        }



        // Calculate

        if(value === "="){


            try{


                const result =

                calculatorExpression

                .replaceAll("×","*")

                .replaceAll("÷","/");



                calculatorExpression =
                eval(result);



                calculatorDisplay.value =
                calculatorExpression;


            }


            catch{


                calculatorExpression = "";

                calculatorDisplay.value =
                "خطا";


            }


            return;

        }




        // Percent

        if(value === "%"){


            calculatorExpression =
            Number(calculatorExpression) / 100;


            calculatorDisplay.value =
            calculatorExpression;


            return;

        }




        // Add value

        calculatorExpression += value;


        if(calculatorDisplay){

            calculatorDisplay.value =
            calculatorExpression;

        }


    });


});
// ==========================
// Quiz Timer
// ==========================


const quizTimeElement =
getElement("quiz-time");


const quizMinutesInput =
getElement("quiz-minutes");


const quizStartButton =
getElement("quiz-start");


const quizPauseButton =
getElement("quiz-pause");


const quizResetButton =
getElement("quiz-reset");


const quizStatus =
getElement("quiz-status-text");



let quizSeconds = 0;

let quizInterval = null;



function updateQuizDisplay(){


    if(!quizTimeElement)
        return;



    const minutes =
    Math.floor(quizSeconds / 60);



    const seconds =
    quizSeconds % 60;



    quizTimeElement.innerText =

    `${String(minutes).padStart(2,"0")}:${String(seconds).padStart(2,"0")}`;


}




// Start Timer

if(quizStartButton){


    quizStartButton.addEventListener("click",()=>{


        if(quizInterval)
            return;



        if(quizSeconds <= 0){


            const minutes =
            Number(quizMinutesInput.value);



            if(!minutes || minutes < 1){


                if(quizStatus)
                    quizStatus.innerText =
                    "زمان وارد نشده است";


                return;

            }



            quizSeconds =
            minutes * 60;


        }



        if(quizStatus)
            quizStatus.innerText =
            "آزمون در حال اجرا";



        quizInterval =
        setInterval(()=>{


            quizSeconds--;


            updateQuizDisplay();



            if(quizSeconds <= 0){


                clearInterval(quizInterval);

                quizInterval = null;


                if(quizStatus)
                    quizStatus.innerText =
                    "زمان آزمون تمام شد";


            }


        },1000);



    });


}





// Pause Timer

if(quizPauseButton){


    quizPauseButton.addEventListener("click",()=>{


        clearInterval(quizInterval);


        quizInterval = null;


        if(quizStatus)
            quizStatus.innerText =
            "متوقف شده";


    });


}





// Reset Timer

if(quizResetButton){


    quizResetButton.addEventListener("click",()=>{


        clearInterval(quizInterval);


        quizInterval = null;


        quizSeconds = 0;


        updateQuizDisplay();



        if(quizStatus)
            quizStatus.innerText =
            "آماده شروع";


    });


}



updateQuizDisplay();





// ==========================
// Random Student Picker
// ==========================


const students =

JSON.parse(

    localStorage.getItem(
        "smartclass_students"
    )

)

|| [];




const selectedStudent =
getElement("selected-student");


const pickStudentButton =
getElement("pick-student");


const studentStatus =
getElement("student-status-text");





if(pickStudentButton){


    pickStudentButton.addEventListener("click",()=>{


        if(students.length === 0){


            if(studentStatus)
                studentStatus.innerText =
                "دانش‌آموزی ثبت نشده است";


            return;

        }



        const randomIndex =

        Math.floor(
            Math.random() * students.length
        );



        const selected =
        students[randomIndex];



        if(selectedStudent){

            selectedStudent.innerText =
            selected;

        }



        if(studentStatus){

            studentStatus.innerText =
            selected;

        }



    });


}
// ==========================
// Class Notes
// ==========================


const notesArea =
getElement("class-notes");


const saveNotesBtn =
getElement("save-notes-btn");


const clearNotesBtn =
getElement("clear-notes-btn");


const notesStatus =
getElement("notes-status");



const NOTES_KEY =
"smartclass_notes";





// ==========================
// Load Notes
// ==========================

function loadNotes(){


    if(!notesArea || !notesStatus)
        return;



    const saved =
    localStorage.getItem(NOTES_KEY);



    if(!saved){


        notesStatus.innerText =
        "هنوز یادداشتی ذخیره نشده است";


        return;

    }



    try{


        const data =
        JSON.parse(saved);



        notesArea.value =
        data.text || "";



        if(data.updated){


            notesStatus.innerText =

            `آخرین ذخیره: ${data.updated}`;


        }


        else{


            notesStatus.innerText =
            "یادداشت بارگذاری شد";


        }



    }


    catch{


        notesArea.value =
        saved;



        notesStatus.innerText =
        "یادداشت قدیمی بارگذاری شد";


    }



}




loadNotes();





// ==========================
// Save Notes
// ==========================


if(saveNotesBtn){


    saveNotesBtn.addEventListener("click",()=>{


        if(!notesArea)
            return;



        const note = {


            text:
            notesArea.value,


            updated:
            new Date()
            .toLocaleString("fa-IR")


        };



        localStorage.setItem(

            NOTES_KEY,

            JSON.stringify(note)

        );



        if(notesStatus){


            notesStatus.innerText =

            `✅ آخرین ذخیره: ${note.updated}`;


        }



    });


}





// ==========================
// Clear Notes
// ==========================


if(clearNotesBtn){


    clearNotesBtn.addEventListener("click",()=>{


        if(!confirm("یادداشت پاک شود؟"))
            return;



        localStorage.removeItem(NOTES_KEY);



        if(notesArea){

            notesArea.value = "";

        }



        if(notesStatus){


            notesStatus.innerText =
            "یادداشت حذف شد.";


        }



    });


}
// ==========================
// Class Info From Bell Schedule
// ==========================


const startElement =
getElement("class-start");


const endElement =
getElement("class-end");


const remainingElement =
getElement("class-remaining");


const periodElement =
getElement("current-period");



let lastBellEvent = "";





// ==========================
// Get Bell Schedule
// ==========================

function getBellSchedule(){


    return JSON.parse(

        localStorage.getItem(
            "smartclass_bells"
        )

    )

    || [];

}




// ==========================
// Update Class Information
// ==========================

function updateClassInfo(){


    const bells =
    getBellSchedule();



    if(bells.length === 0){


        if(startElement)
            startElement.innerText = "--:--";


        if(endElement)
            endElement.innerText = "--:--";


        if(periodElement)
            periodElement.innerText =
            "بدون برنامه";


        if(remainingElement)
            remainingElement.innerText =
            "--:--";


        return;

    }




    const now =
    new Date();



    const currentMinutes =

    now.getHours() * 60
    +
    now.getMinutes();



    const currentSecond =
    now.getSeconds();



    const currentTime =

    `${String(now.getHours()).padStart(2,"0")}:${String(now.getMinutes()).padStart(2,"0")}`;




    let currentBell = null;




    bells.forEach(bell=>{


        const start =
        bell.start.split(":");


        const end =
        bell.end.split(":");



        const startMinutes =

        Number(start[0]) * 60
        +
        Number(start[1]);



        const endMinutes =

        Number(end[0]) * 60
        +
        Number(end[1]);



        if(

            currentMinutes >= startMinutes &&
            currentMinutes <= endMinutes

        ){

            currentBell = bell;

        }


    });






    if(currentBell){


        if(startElement)
            startElement.innerText =
            currentBell.start;



        if(endElement)
            endElement.innerText =
            currentBell.end;



        if(periodElement)
            periodElement.innerText =
            currentBell.name;





        const end =
        currentBell.end.split(":");



        const endMinutes =

        Number(end[0]) * 60
        +
        Number(end[1]);



        const remaining =

        endMinutes - currentMinutes;



        if(remaining > 0){


            if(remainingElement)
                remainingElement.innerText =
                remaining + " دقیقه";


        }

        else{


            if(remainingElement)
                remainingElement.innerText =
                "تمام شد";


        }







        // Bell Trigger

        if(currentSecond === 0){


            const eventKey =

            currentBell.name + "_" + currentTime;



            if(

                (currentTime === currentBell.start ||

                currentTime === currentBell.end)

                &&

                lastBellEvent !== eventKey

            ){


                lastBellEvent =
                eventKey;


                playBellSound();


            }


        }



    }


    else{


        if(periodElement)
            periodElement.innerText =
            "بین زنگ‌ها";


        if(startElement)
            startElement.innerText =
            "--:--";


        if(endElement)
            endElement.innerText =
            "--:--";


        if(remainingElement)
            remainingElement.innerText =
            "بین زنگ‌ها";


    }


}





setInterval(
    updateClassInfo,
    1000
);


updateClassInfo();





// ==========================
// School Bell Sound
// ==========================


const bellAudio =
getElement("school-bell");





function playBellSound(){


    if(!bellAudio)
        return;




    const settings =

    JSON.parse(

        localStorage.getItem(
            "smartclass_settings"
        )

    )

    ||

    {

        bellStatus:"enabled",

        bellType:"school"

    };




    if(settings.bellStatus === "disabled")
        return;





    switch(settings.bellType){


        case "classic":

            bellAudio.src =
            "کلاسیک.mp3";

            break;



        case "digital":

            bellAudio.src =
            "دیجیتال.mp3";

            break;



        default:

            bellAudio.src =
            "مدرسه.mp3";


    }





    bellAudio.currentTime = 0;


    bellAudio.play()
    .catch(()=>{});


}
// ==========================
// Physics Unit Converter
// ==========================


const quantityType =
getElement("quantity-type");


const convertFrom =
getElement("convert-from");


const convertTo =
getElement("convert-to");


const convertButton =
getElement("convert-button");


const convertValue =
getElement("convert-value");


const converterResult =
getElement("converter-result");





// ==========================
// SI Physics Units
// ==========================


const units = {


    length: {

        "pm": 0.000000000001,

        "nm": 0.000000001,

        "μm": 0.000001,

        "mm": 0.001,

        "cm": 0.01,

        "dm": 0.1,

        "m": 1,

        "km": 1000,

        "Mm": 1000000

    },



    mass: {

        "mg": 0.000001,

        "g": 0.001,

        "kg": 1,

        "Mg": 1000

    },



    time: {

        "ms": 0.001,

        "s": 1,

        "min": 60,

        "h": 3600

    },



    current: {

        "mA": 0.001,

        "A": 1,

        "kA": 1000

    },



    temperature: {

        "K": 1

    },



    amount: {

        "mol": 1,

        "kmol": 1000

    },



    luminous: {

        "cd": 1,

        "kcd": 1000

    },



    force: {

        "mN": 0.001,

        "N": 1,

        "kN": 1000

    },



    energy: {

        "mJ": 0.001,

        "J": 1,

        "kJ": 1000,

        "MJ": 1000000

    },



    power: {

        "mW": 0.001,

        "W": 1,

        "kW": 1000

    },



    pressure: {

        "Pa": 1,

        "kPa": 1000,

        "MPa": 1000000

    }


};





// ==========================
// Unit Names
// ==========================


const unitNames = {


    "pm":"پیکومتر",

    "nm":"نانومتر",

    "μm":"میکرومتر",

    "mm":"میلی‌متر",

    "cm":"سانتی‌متر",

    "dm":"دسی‌متر",

    "m":"متر",

    "km":"کیلومتر",

    "Mm":"مگامتر",




    "mg":"میلی‌گرم",

    "g":"گرم",

    "kg":"کیلوگرم",

    "Mg":"مگاگرم",




    "ms":"میلی‌ثانیه",

    "s":"ثانیه",

    "min":"دقیقه",

    "h":"ساعت",




    "mA":"میلی‌آمپر",

    "A":"آمپر",

    "kA":"کیلوآمپر",




    "K":"کلوین",




    "mol":"مول",

    "kmol":"کیلومول",




    "cd":"کاندلا",

    "kcd":"کیلوکاندلا",




    "mN":"میلی‌نیوتن",

    "N":"نیوتن",

    "kN":"کیلونیوتن",




    "mJ":"میلی‌ژول",

    "J":"ژول",

    "kJ":"کیلوژول",

    "MJ":"مگاژول",




    "mW":"میلی‌وات",

    "W":"وات",

    "kW":"کیلووات",




    "Pa":"پاسکال",

    "kPa":"کیلوپاسکال",

    "MPa":"مگاپاسکال"


};
// ==========================
// Load Units Into Select
// ==========================


function loadUnits(){


    if(
        !quantityType ||
        !convertFrom ||
        !convertTo
    )

        return;



    const selectedType =
    quantityType.value;



    convertFrom.innerHTML = "";

    convertTo.innerHTML = "";





    Object.keys(
        units[selectedType]
    )

    .forEach(unit=>{


        const optionFrom =
        document.createElement("option");


        optionFrom.value =
        unit;


        optionFrom.innerText =

        `${unit} - ${unitNames[unit]}`;




        convertFrom.appendChild(
            optionFrom
        );





        const optionTo =
        document.createElement("option");


        optionTo.value =
        unit;


        optionTo.innerText =

        `${unit} - ${unitNames[unit]}`;




        convertTo.appendChild(
            optionTo
        );



    });


}







// Change Quantity Type

if(quantityType){


    quantityType.addEventListener(
        "change",
        loadUnits
    );


    loadUnits();


}







// ==========================
// Convert Calculation
// ==========================


if(convertButton){


    convertButton.addEventListener(
        "click",
        ()=>{


            const value =
            Number(convertValue.value);





            if(
                isNaN(value)
            ){


                if(converterResult)

                    converterResult.innerText =
                    "لطفاً مقدار وارد کنید";


                return;

            }







            const type =
            quantityType.value;



            const from =
            convertFrom.value;



            const to =
            convertTo.value;








            const baseValue =

            value *
            units[type][from];







            const result =

            baseValue /
            units[type][to];






            let formattedResult;

if (result === 0) {

    formattedResult = 0;

}
else if (Math.abs(result) < 0.000001 || Math.abs(result) >= 1000000000) {

    formattedResult = result.toExponential(6);

}
else {

    formattedResult = Number(result.toPrecision(12));

}







            if(converterResult){


                converterResult.innerText =

                `${value} ${from} = ${formattedResult} ${to}`;


            }




        }


    );


}