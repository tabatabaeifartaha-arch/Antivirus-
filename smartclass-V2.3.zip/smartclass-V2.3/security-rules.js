"use strict";

// ==========================================
// SmartClass Security Rules
// Advanced Client-Side Input Security Engine
// ==========================================

window.SmartClassSecurityRules = (function () {

    const VERSION = "2.0";

    const DEFAULT_MAX_LENGTH = 500;

    const MAX_NORMALIZED_LENGTH = 2000;

    // ==========================================
    // Threat Levels
    // ==========================================

    const LEVELS = {
        LOW: "LOW",
        MEDIUM: "MEDIUM",
        HIGH: "HIGH",
        CRITICAL: "CRITICAL"
    };

    // ==========================================
    // Suspicious Patterns
    // ==========================================

    const RULES = [

        // --------------------------------------
        // Script / JavaScript
        // --------------------------------------

        {
            id: "XSS_SCRIPT_TAG",
            level: "CRITICAL",
            score: 100,
            pattern: /<\s*script\b/i,
            reason: "Script tag detected."
        },

        {
            id: "XSS_JAVASCRIPT_SCHEME",
            level: "CRITICAL",
            score: 100,
            pattern: /(?:java\s*script|vbscript)\s*:/i,
            reason: "Executable URL scheme detected."
        },

        // --------------------------------------
        // HTML Injection
        // --------------------------------------

        {
            id: "HTML_IFRAME",
            level: "HIGH",
            score: 85,
            pattern: /<\s*iframe\b/i,
            reason: "Iframe injection detected."
        },

        {
            id: "HTML_OBJECT",
            level: "HIGH",
            score: 85,
            pattern: /<\s*object\b/i,
            reason: "Object element detected."
        },

        {
            id: "HTML_EMBED",
            level: "HIGH",
            score: 85,
            pattern: /<\s*embed\b/i,
            reason: "Embed element detected."
        },

        {
            id: "HTML_BASE",
            level: "HIGH",
            score: 80,
            pattern: /<\s*base\b/i,
            reason: "Base element detected."
        },

        // --------------------------------------
        // SVG / MathML
        // --------------------------------------

        {
            id: "SVG_EVENT_HANDLER",
            level: "HIGH",
            score: 90,
            pattern: /<\s*svg\b[^>]*\bon[a-z]+\s*=/i,
            reason: "SVG event handler detected."
        },

        {
            id: "SVG_TAG",
            level: "HIGH",
            score: 80,
            pattern: /<\s*svg\b/i,
            reason: "SVG markup detected."
        },

        {
            id: "MATHML_TAG",
            level: "HIGH",
            score: 75,
            pattern: /<\s*math\b/i,
            reason: "MathML markup detected."
        },

        // --------------------------------------
        // Event Handlers
        // --------------------------------------

        {
            id: "HTML_EVENT_HANDLER",
            level: "HIGH",
            score: 90,
            pattern: /\bon(?:abort|afterprint|animationend|animationstart|beforeprint|beforeunload|blur|canplay|change|click|contextmenu|copy|cut|dblclick|drag|drop|error|focus|input|keydown|keypress|keyup|load|mousedown|mouseenter|mouseleave|mousemove|mouseout|mouseover|mouseup|paste|pointerdown|pointermove|pointerup|reset|resize|scroll|select|submit|touchstart|touchmove|touchend|unload|wheel)\s*=/i,
            reason: "HTML event handler detected."
        },

        // --------------------------------------
        // Dangerous HTML Elements
        // --------------------------------------

        {
            id: "DANGEROUS_FORM_ACTION",
            level: "HIGH",
            score: 85,
            pattern: /<\s*form\b[^>]*(?:action|formaction)\s*=/i,
            reason: "Form action manipulation detected."
        },

        {
            id: "DANGEROUS_META",
            level: "HIGH",
            score: 80,
            pattern: /<\s*meta\b[^>]*(?:http-equiv|content)\s*=/i,
            reason: "Meta injection detected."
        },

        {
            id: "DANGEROUS_LINK",
            level: "MEDIUM",
            score: 55,
            pattern: /<\s*link\b/i,
            reason: "Link element detected."
        },

        // --------------------------------------
        // Data / URL Injection
        // --------------------------------------

        {
            id: "DATA_HTML_SCHEME",
            level: "HIGH",
            score: 85,
            pattern: /data\s*:\s*(?:text\/html|application\/xhtml\+xml)/i,
            reason: "HTML data scheme detected."
        },

        {
            id: "FILE_SCHEME",
            level: "MEDIUM",
            score: 45,
            pattern: /file\s*:/i,
            reason: "File scheme detected."
        },

        // --------------------------------------
        // JavaScript Function Abuse
        // --------------------------------------

        {
            id: "JS_EVAL",
            level: "HIGH",
            score: 75,
            pattern: /\beval\s*\(/i,
            reason: "eval() pattern detected."
        },

        {
            id: "JS_FUNCTION_CONSTRUCTOR",
            level: "HIGH",
            score: 80,
            pattern: /\b(?:new\s+)?Function\s*\(/i,
            reason: "Dynamic Function constructor detected."
        },

        {
            id: "JS_SET_TIMEOUT_STRING",
            level: "MEDIUM",
            score: 55,
            pattern: /\bset(?:Timeout|Interval)\s*\(\s*["'`]/i,
            reason: "String-based timer execution detected."
        },

        // --------------------------------------
        // DOM Manipulation Indicators
        // --------------------------------------

        {
            id: "DOM_INJECTION",
            level: "MEDIUM",
            score: 50,
            pattern: /\.(?:innerHTML|outerHTML|insertAdjacentHTML)\s*=/i,
            reason: "HTML DOM injection pattern detected."
        },

        // --------------------------------------
        // Encoded Payload Indicators
        // --------------------------------------

        {
            id: "ENCODED_SCRIPT",
            level: "HIGH",
            score: 80,
            pattern: /(?:%3c|%3e|%2f|%22|%27).*?(?:script|iframe|svg|onerror|onload)/i,
            reason: "Encoded suspicious payload detected."
        },

        {
            id: "HEX_SCRIPT",
            level: "HIGH",
            score: 75,
            pattern: /(?:\\x3c|\\x3e|\\u003c|\\u003e).*?(?:script|iframe|svg)/i,
            reason: "Encoded HTML payload detected."
        },

        // --------------------------------------
        // CSS Injection Indicators
        // --------------------------------------

        {
            id: "CSS_EXPRESSION",
            level: "HIGH",
            score: 80,
            pattern: /expression\s*\(/i,
            reason: "CSS expression detected."
        },

        {
            id: "CSS_IMPORT",
            level: "MEDIUM",
            score: 50,
            pattern: /@import\s+(?:url\s*\()?["']?/i,
            reason: "CSS import pattern detected."
        },

        // --------------------------------------
        // Null Byte / Control Characters
        // --------------------------------------

        {
            id: "NULL_BYTE",
            level: "HIGH",
            score: 70,
            pattern: /\x00/,
            reason: "Null byte detected."
        },

        {
            id: "CONTROL_CHARACTER",
            level: "MEDIUM",
            score: 40,
            pattern: /[\u0001-\u0008\u000B\u000C\u000E-\u001F\u007F]/,
            reason: "Unexpected control character detected."
        },

        // --------------------------------------
        // Protocol / Header-like Injection
        // --------------------------------------

        {
            id: "CRLF_INJECTION",
            level: "HIGH",
            score: 80,
            pattern: /(?:\r|\n){2,}|%0d|%0a/i,
            reason: "CRLF injection pattern detected."
        },

        // --------------------------------------
        // Template Injection Indicators
        // --------------------------------------

        {
            id: "TEMPLATE_EXPRESSION",
            level: "MEDIUM",
            score: 55,
            pattern: /(?:\{\{.*?\}\}|\$\{.*?\}|<%.*?%>)/i,
            reason: "Template expression detected."
        }

    ];

    // ==========================================
    // Safe Log
    // ==========================================

    function securityLog(
        level,
        type,
        message,
        details
    ) {

        if (
            !window.SmartClassSecurityLog ||
            typeof window.SmartClassSecurityLog.log !== "function"
        ) {
            return;
        }

        try {

            window.SmartClassSecurityLog.log(
                level,
                type,
                message,
                details || {}
            );

        } catch (error) {

            console.error(
                "Security Rules Log Error:",
                error
            );

        }

    }

    // ==========================================
    // Safe String Conversion
    // ==========================================

    function safeString(value) {

        if (
            value === null ||
            value === undefined
        ) {
            return "";
        }

        try {

            return String(value);

        } catch (error) {

            return "";

        }

    }

    // ==========================================
    // Normalize Input
    // ==========================================

    function normalizeInput(text) {

        let normalized = text;

        try {

            normalized = normalized
                .normalize("NFKC");

        } catch (error) {
            // Older browsers may not support normalize().
        }

        normalized = normalized
            .replace(/\u0000/g, "")
            .replace(/[\u200B-\u200D\uFEFF]/g, "")
            .trim();

        return normalized;

    }

    // ==========================================
    // Decode Common URL Encoding
    // ==========================================

    function decodeForInspection(text) {

        let result = text;

        for (let i = 0; i < 3; i++) {

            try {

                const decoded =
                    decodeURIComponent(result);

                if (decoded === result) {
                    break;
                }

                result = decoded;

            } catch (error) {

                break;

            }

        }

        return result;

    }

    // ==========================================
    // Determine Highest Threat Level
    // ==========================================

    function getHighestLevel(matches) {

        const priority = {
            LOW: 1,
            MEDIUM: 2,
            HIGH: 3,
            CRITICAL: 4
        };

        let highest = "LOW";

        for (let i = 0; i < matches.length; i++) {

            if (
                priority[matches[i].level] >
                priority[highest]
            ) {
                highest = matches[i].level;
            }

        }

        return highest;

    }

    // ==========================================
    // Calculate Risk Score
    // ==========================================

    function calculateRiskScore(matches) {

        if (!matches.length) {
            return 0;
        }

        let score = 0;

        for (let i = 0; i < matches.length; i++) {

            score += matches[i].score;

        }

        // Prevent score inflation from duplicate
        // matches of the same rule.

        const uniqueRules =
            new Set(
                matches.map(function (item) {
                    return item.id;
                })
            ).size;

        score +=
            Math.max(0, uniqueRules - 1) * 5;

        return Math.min(100, score);

    }

    // ==========================================
    // Analyze Input
    // ==========================================

    function analyzeInput(
        value,
        fieldName
    ) {

        const name =
            fieldName || "unknown";

        const original =
            safeString(value);

        // --------------------------------------
        // Length Protection
        // --------------------------------------

        if (
            original.length >
            DEFAULT_MAX_LENGTH
        ) {

            securityLog(
                "MEDIUM",
                "INPUT_TOO_LONG",
                "ورودی بیش از حد مجاز بود.",
                {
                    field: name,
                    length: original.length,
                    maxLength: DEFAULT_MAX_LENGTH
                }
            );

            return {

                safe: false,
                level: LEVELS.MEDIUM,
                score: 40,
                reason: "Input exceeds maximum length.",
                matches: [
                    {
                        id: "INPUT_TOO_LONG",
                        level: LEVELS.MEDIUM,
                        score: 40
                    }
                ]

            };

        }

        const normalized =
            normalizeInput(original);

        const decoded =
            decodeForInspection(normalized);

        if (
            decoded.length >
            MAX_NORMALIZED_LENGTH
        ) {

            securityLog(
                "MEDIUM",
                "NORMALIZED_INPUT_TOO_LONG",
                "ورودی پس از نرمال‌سازی بیش از حد مجاز بود.",
                {
                    field: name,
                    length: decoded.length
                }
            );

            return {

                safe: false,
                level: LEVELS.MEDIUM,
                score: 40,
                reason: "Normalized input exceeds allowed length.",
                matches: [
                    {
                        id: "NORMALIZED_INPUT_TOO_LONG",
                        level: LEVELS.MEDIUM,
                        score: 40
                    }
                ]

            };

        }

        // --------------------------------------
        // Rule Matching
        // --------------------------------------

        const matches = [];

        for (
            let i = 0;
            i < RULES.length;
            i++
        ) {

            const rule =
                RULES[i];

            rule.pattern.lastIndex = 0;

            if (
                rule.pattern.test(normalized)
            ) {

                matches.push({
                    id: rule.id,
                    level: rule.level,
                    score: rule.score,
                    reason: rule.reason
                });

            }

            // Inspect decoded representation too.

            if (
                decoded !== normalized
            ) {

                rule.pattern.lastIndex = 0;

                if (
                    rule.pattern.test(decoded)
                ) {

                    const alreadyMatched =
                        matches.some(function (item) {
                            return item.id === rule.id;
                        });

                    if (!alreadyMatched) {

                        matches.push({
                            id: rule.id,
                            level: rule.level,
                            score: rule.score,
                            reason:
                                rule.reason +
                                " Encoded representation detected."
                        });

                    }

                }

            }

        }

        // --------------------------------------
        // Result
        // --------------------------------------

        if (!matches.length) {

            return {

                safe: true,
                level: null,
                score: 0,
                reason: null,
                matches: []

            };

        }

        const level =
            getHighestLevel(matches);

        const score =
            calculateRiskScore(matches);

        const reason =
            matches
                .map(function (item) {
                    return item.reason;
                })
                .join(" | ");

        securityLog(
            level,
            "SUSPICIOUS_INPUT",
            "ورودی مشکوک شناسایی شد.",
            {
                field: name,
                length: original.length,
                riskScore: score,
                level: level,
                rules: matches.map(function (item) {
                    return item.id;
                })
            }
        );

        return {

            safe: false,
            level: level,
            score: score,
            reason: reason,
            matches: matches

        };

    }

    // ==========================================
    // Legacy-Compatible checkInput()
    // ==========================================

    function checkInput(
        value,
        fieldName
    ) {

        const result =
            analyzeInput(
                value,
                fieldName
            );

        return {

            safe: result.safe,

            reason: result.reason,

            level: result.level,

            score: result.score,

            matches: result.matches

        };

    }

    // ==========================================
    // Check Multiple Inputs
    // ==========================================

    function checkObject(
        object,
        prefix
    ) {

        const results = {};

        if (
            !object ||
            typeof object !== "object"
        ) {
            return results;
        }

        Object.keys(object).forEach(function (key) {

            results[key] =
                checkInput(
                    object[key],
                    prefix
                        ? prefix + "." + key
                        : key
                );

        });

        return results;

    }

    // ==========================================
    // Check if Input is Safe
    // ==========================================

    function isSafe(
        value,
        fieldName
    ) {

        return checkInput(
            value,
            fieldName
        ).safe;

    }

    // ==========================================
    // Get Rules
    // ==========================================

    function getRules() {

        return RULES.map(function (rule) {

            return {

                id: rule.id,
                level: rule.level,
                score: rule.score,
                reason: rule.reason

            };

        });

    }

    // ==========================================
    // Public API
    // ==========================================

    return {

        version: VERSION,

        maxLength: DEFAULT_MAX_LENGTH,

        levels: LEVELS,

        checkInput: checkInput,

        analyzeInput: analyzeInput,

        checkObject: checkObject,

        isSafe: isSafe,

        getRules: getRules

    };

})();