"use strict";

// ============================================================
// SmartClass Security Access Control
// Version 1.0
// ============================================================

window.SmartClassSecurityAccess = (function () {

    const VERSION = "1.0";

    const STATUS = {
        ALLOWED: "ALLOWED",
        DENIED: "DENIED",
        RESTRICTED: "RESTRICTED",
        UNKNOWN: "UNKNOWN"
    };

    const CONFIG = {
        maxActionLength: 100,
        maxReasonLength: 300,
        maxFailures: 20,
        failureWindow: 30000
    };

    let failures = [];

    let totalChecks = 0;

    let allowedChecks = 0;

    let deniedChecks = 0;

    let lastDecision = null;

    let lastError = null;


    // =========================================================
    // Safe String
    // =========================================================

    function safeString(
        value,
        maxLength
    ) {

        try {

            return String(value)
                .replace(/\s+/g, " ")
                .trim()
                .slice(
                    0,
                    maxLength ||
                    CONFIG.maxReasonLength
                );

        } catch (error) {

            return "";

        }

    }


    // =========================================================
    // Security Log
    // =========================================================

    function log(
        level,
        type,
        message,
        details
    ) {

        try {

            if (
                window.SmartClassSecurityLog &&
                typeof window.SmartClassSecurityLog.log ===
                "function"
            ) {

                window.SmartClassSecurityLog.log(
                    level,
                    type,
                    message,
                    details || {}
                );

            }

        } catch (error) {

            console.error(
                "Security Access Log Error:",
                error
            );

        }

    }


    // =========================================================
    // Clean Failures
    // =========================================================

    function cleanupFailures() {

        const now =
            Date.now();


        failures =
            failures.filter(
                function (item) {

                    return (
                        now -
                        item.timestamp
                        <=
                        CONFIG.failureWindow
                    );

                }
            );


        if (
            failures.length >
            CONFIG.maxFailures
        ) {

            failures =
                failures.slice(
                    -CONFIG.maxFailures
                );

        }

    }


    // =========================================================
    // Record Failure
    // =========================================================

    function recordFailure(
        action,
        reason
    ) {

        cleanupFailures();


        failures.push({

            timestamp:
                Date.now(),

            action:
                safeString(
                    action,
                    CONFIG.maxActionLength
                ),

            reason:
                safeString(
                    reason
                )

        });


        cleanupFailures();

    }


    // =========================================================
    // Check Security State
    // =========================================================

    function getSecurityState() {

        const state = {

            healthy:
                true,

            restricted:
                false,

            lockdown:
                false,

            integrityScore:
                100,

            healthScore:
                100,

            failSafeMode:
                "NORMAL"

        };


        try {

            // ---------------------------------------------
            // Automatic Response
            // ---------------------------------------------

            if (
                window.SmartClassSecurityResponse &&
                typeof window.SmartClassSecurityResponse
                    .isRestricted === "function"
            ) {

                state.restricted =
                    window.SmartClassSecurityResponse
                        .isRestricted();

            }


            // ---------------------------------------------
            // Integrity
            // ---------------------------------------------

            if (
                window.SmartClassSecurityIntegrity &&
                typeof window.SmartClassSecurityIntegrity
                    .getStatus === "function"
            ) {

                const integrity =
                    window.SmartClassSecurityIntegrity
                        .getStatus();


                if (
                    Number.isFinite(
                        Number(integrity.score)
                    )
                ) {

                    state.integrityScore =
                        Math.max(
                            0,
                            Math.min(
                                100,
                                Number(integrity.score)
                            )
                        );

                }


                if (
                    integrity.status ===
                    "COMPROMISED"
                ) {

                    state.healthy =
                        false;

                }

            }


            // ---------------------------------------------
            // Health
            // ---------------------------------------------

            if (
                window.SmartClassSecurityHealth &&
                typeof window.SmartClassSecurityHealth
                    .getStatus === "function"
            ) {

                const health =
                    window.SmartClassSecurityHealth
                        .getStatus();


                if (
                    Number.isFinite(
                        Number(health.score)
                    )
                ) {

                    state.healthScore =
                        Math.max(
                            0,
                            Math.min(
                                100,
                                Number(health.score)
                            )
                        );

                }


                if (
                    health.status === "CRITICAL"
                ) {

                    state.healthy =
                        false;

                }

            }


            // ---------------------------------------------
            // Fail-Safe
            // ---------------------------------------------

            if (
                window.SmartClassSecurityFailSafe &&
                typeof window.SmartClassSecurityFailSafe
                    .getStatus === "function"
            ) {

                const failsafe =
                    window.SmartClassSecurityFailSafe
                        .getStatus();


                state.failSafeMode =
                    String(
                        failsafe.mode ||
                        "NORMAL"
                    );


                if (
                    state.failSafeMode ===
                    "LOCKDOWN"
                ) {

                    state.lockdown =
                        true;

                    state.healthy =
                        false;

                }

            }

        } catch (error) {

            lastError =
                "Security state check failed.";

            state.healthy =
                false;

        }


        return state;

    }


    // =========================================================
    // Validate Action
    // =========================================================

    function validateAction(
        action
    ) {

        const value =
            safeString(
                action,
                CONFIG.maxActionLength
            );


        if (!value) {

            return {

                valid:
                    false,

                action:
                    "",

                reason:
                    "Security action is empty."

            };

        }


        if (
            value.length >
            CONFIG.maxActionLength
        ) {

            return {

                valid:
                    false,

                action:
                    value,

                reason:
                    "Security action is too long."

            };

        }


        /*
         * Action names are identifiers, not arbitrary
         * executable code.
         */

        if (
            !/^[a-zA-Z0-9_.:-]+$/.test(
                value
            )
        ) {

            return {

                valid:
                    false,

                action:
                    value,

                reason:
                    "Invalid security action format."

            };

        }


        return {

            valid:
                true,

            action:
                value,

            reason:
                null

        };

    }


    // =========================================================
    // Check Access
    // =========================================================

    function check(
        action
    ) {

        totalChecks++;


        const validation =
            validateAction(
                action
            );


        if (
            !validation.valid
        ) {

            deniedChecks++;

            recordFailure(
                action,
                validation.reason
            );


            lastDecision = {

                action:
                    validation.action,

                status:
                    STATUS.DENIED,

                reason:
                    validation.reason,

                timestamp:
                    Date.now()

            };


            log(
                "MEDIUM",
                "ACCESS_DENIED",
                "دسترسی به عملیات امنیتی رد شد.",
                {
                    action:
                        validation.action,

                    reason:
                        validation.reason
                }
            );


            return {
                allowed:
                    false,

                status:
                    STATUS.DENIED,

                reason:
                    validation.reason

            };

        }


        const state =
            getSecurityState();


        // -----------------------------------------------------
        // Lockdown
        // -----------------------------------------------------

        if (
            state.lockdown
        ) {

            deniedChecks++;


            recordFailure(
                validation.action,
                "Security lockdown is active."
            );


            lastDecision = {

                action:
                    validation.action,

                status:
                    STATUS.RESTRICTED,

                reason:
                    "Security lockdown is active.",

                timestamp:
                    Date.now()

            };


            log(
                "CRITICAL",
                "ACCESS_LOCKDOWN",
                "دسترسی به دلیل Lockdown امنیتی رد شد.",
                {
                    action:
                        validation.action
                }
            );


            return {

                allowed:
                    false,

                status:
                    STATUS.RESTRICTED,

                reason:
                    "Security lockdown is active."

            };

        }


        // -----------------------------------------------------
        // Automatic Restriction
        // -----------------------------------------------------

        if (
            state.restricted
        ) {

            deniedChecks++;


            recordFailure(
                validation.action,
                "Automatic security restriction is active."
            );


            lastDecision = {

                action:
                    validation.action,

                status:
                    STATUS.RESTRICTED,

                reason:
                    "Automatic security restriction is active.",

                timestamp:
                    Date.now()

            };


            log(
                "HIGH",
                "ACCESS_RESTRICTED",
                "دسترسی به دلیل محدودیت امنیتی رد شد.",
                {
                    action:
                        validation.action
                }
            );


            return {

                allowed:
                    false,

                status:
                    STATUS.RESTRICTED,

                reason:
                    "Automatic security restriction is active."

            };

        }


        // -----------------------------------------------------
        // Integrity
        // -----------------------------------------------------

        if (
            state.integrityScore < 40
        ) {

            deniedChecks++;


            recordFailure(
                validation.action,
                "Security integrity is too low."
            );


            lastDecision = {

                action:
                    validation.action,

                status:
                    STATUS.DENIED,

                reason:
                    "Security integrity is too low.",

                timestamp:
                    Date.now()

            };


            log(
                "CRITICAL",
                "ACCESS_INTEGRITY_DENIED",
                "دسترسی به دلیل وضعیت نامناسب یکپارچگی امنیتی رد شد.",
                {
                    action:
                        validation.action,

                    integrityScore:
                        state.integrityScore
                }
            );


            return {

                allowed:
                    false,

                status:
                    STATUS.DENIED,

                reason:
                    "Security integrity is too low."

            };

        }


        // -----------------------------------------------------
        // Health
        // -----------------------------------------------------

        if (
            state.healthScore < 30
        ) {

            deniedChecks++;


            recordFailure(
                validation.action,
                "Security health is too low."
            );


            lastDecision = {

                action:
                    validation.action,

                status:
                    STATUS.DENIED,

                reason:
                    "Security health is too low.",

                timestamp:
                    Date.now()

            };


            log(
                "HIGH",
                "ACCESS_HEALTH_DENIED",
                "دسترسی به دلیل سلامت پایین سیستم رد شد.",
                {
                    action:
                        validation.action,

                    healthScore:
                        state.healthScore
                }
            );


            return {

                allowed:
                    false,

                status:
                    STATUS.DENIED,

                reason:
                    "Security health is too low."

            };

        }


        // -----------------------------------------------------
        // Allow
        // -----------------------------------------------------

        allowedChecks++;


        lastDecision = {

            action:
                validation.action,

            status:
                STATUS.ALLOWED,

            reason:
                null,

            timestamp:
                Date.now()

        };


        return {

            allowed:
                true,

            status:
                STATUS.ALLOWED,

            reason:
                null

        };

    }


    // =========================================================
    // Is Allowed
    // =========================================================

    function isAllowed(
        action
    ) {

        const result =
            check(action);

        return (
            result.allowed === true
        );

    }


    // =========================================================
    // Get Last Decision
    // =========================================================

    function getLastDecision() {

        if (
            !lastDecision
        ) {

            return null;

        }


        try {

            return JSON.parse(
                JSON.stringify(
                    lastDecision
                )
            );

        } catch (error) {

            return null;

        }

    }


    // =========================================================
    // Get Statistics
    // =========================================================

    function getStatistics() {

        cleanupFailures();


        return {

            version:
                VERSION,

            totalChecks:
                totalChecks,

            allowedChecks:
                allowedChecks,

            deniedChecks:
                deniedChecks,

            recentFailures:
                failures.length,

            lastDecision:
                getLastDecision(),

            lastError:
                lastError

        };

    }


    // =========================================================
    // Reset
    // =========================================================

    function reset() {

        failures = [];

        totalChecks = 0;

        allowedChecks = 0;

        deniedChecks = 0;

        lastDecision = null;

        lastError = null;

        return true;

    }


    // =========================================================
    // Public API
    // =========================================================

    return {

        version:
            VERSION,

        statuses:
            { ...STATUS },

        check:
            check,

        isAllowed:
            isAllowed,

        getLastDecision:
            getLastDecision,

        getStatistics:
            getStatistics,

        reset:
            reset

    };

})();