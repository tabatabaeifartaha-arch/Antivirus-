"use strict";

/*
========================================
 SmartClass Security Log
 Version: 1.0
========================================

 مسئولیت این فایل:
 - ثبت رخدادهای امنیتی
 - سطح‌بندی رخدادها
 - جلوگیری از پر شدن بی‌نهایت حافظه
 - پاک‌سازی اطلاعات ثبت‌شده
 - فراهم کردن API برای سایر ماژول‌های امنیتی

 نکته:
 localStorage منبع قابل اعتماد امنیتی نیست.
 این سیستم برای لایه امنیت مرورگر/دمو است.
 امنیت واقعی سمت سرور باید جداگانه اضافه شود.
========================================
*/


(function () {

    const STORAGE_KEY = "smartclass_security_logs";

    const MAX_LOGS = 300;

    const VALID_LEVELS = [
        "INFO",
        "LOW",
        "MEDIUM",
        "HIGH",
        "CRITICAL"
    ];


    /*
    ========================================
    Internal Helpers
    ========================================
    */


    function safeString(value, maxLength) {

        if (value === null || value === undefined) {
            return "";
        }

        let text;

        try {
            text = String(value);
        } catch (error) {
            return "[UNREADABLE]";
        }

        text = text
            .replace(/[\u0000-\u0008]/g, "")
            .replace(/[\u000B\u000C]/g, "")
            .replace(/[\u000E-\u001F]/g, "");

        if (text.length > maxLength) {
            text = text.substring(0, maxLength);
        }

        return text;
    }


    function getTimestamp() {

        return new Date().toISOString();

    }


    function createId() {

        return (
            Date.now().toString(36) +
            "-" +
            Math.random()
                .toString(36)
                .substring(2, 10)
        );

    }


    function normalizeLevel(level) {

        level = safeString(level, 20).toUpperCase();

        if (!VALID_LEVELS.includes(level)) {
            return "INFO";
        }

        return level;

    }


    function readLogs() {

        try {

            const raw =
                localStorage.getItem(STORAGE_KEY);

            if (!raw) {
                return [];
            }

            const parsed = JSON.parse(raw);

            if (!Array.isArray(parsed)) {
                return [];
            }

            return parsed.slice(-MAX_LOGS);

        } catch (error) {

            return [];

        }

    }


    function writeLogs(logs) {

        try {

            const safeLogs =
                Array.isArray(logs)
                    ? logs.slice(-MAX_LOGS)
                    : [];

            localStorage.setItem(
                STORAGE_KEY,
                JSON.stringify(safeLogs)
            );

            return true;

        } catch (error) {

            /*
            اگر localStorage پر شده یا در دسترس نباشد،
            سیستم امنیتی نباید باعث خراب شدن سایت شود.
            */

            return false;

        }

    }


    /*
    ========================================
    Create Security Event
    ========================================
    */


    function createEvent(level, type, message, details) {

        const event = {

            id: createId(),

            timestamp: getTimestamp(),

            level: normalizeLevel(level),

            type: safeString(type, 80),

            message: safeString(message, 500),

            details:
                details && typeof details === "object"
                    ? sanitizeObject(details)
                    : {}

        };

        return event;

    }


    /*
    ========================================
    Sanitize Details
    ========================================
    */


    function sanitizeObject(object) {

        const result = {};

        if (!object || typeof object !== "object") {
            return result;
        }


        Object.keys(object)
            .slice(0, 20)
            .forEach(function (key) {

                const safeKey =
                    safeString(key, 60);

                const value =
                    object[key];


                if (
                    typeof value === "string" ||
                    typeof value === "number" ||
                    typeof value === "boolean"
                ) {

                    result[safeKey] =
                        safeString(value, 300);

                }

            });


        return result;

    }


    /*
    ========================================
    Main Logger
    ========================================
    */


    function log(level, type, message, details) {

        const event =
            createEvent(
                level,
                type,
                message,
                details
            );


        const logs = readLogs();

        logs.push(event);

        writeLogs(logs);


        /*
        Console output فقط برای تست و توسعه
        */

        try {

            if (
                event.level === "HIGH" ||
                event.level === "CRITICAL"
            ) {

                console.warn(
                    "[SmartClass Security]",
                    event
                );

            } else {

                console.info(
                    "[SmartClass Security]",
                    event
                );

            }

        } catch (error) {
            // هیچ خطایی نباید سایت را متوقف کند
        }


        return event;

    }


    /*
    ========================================
    Get Logs
    ========================================
    */


    function getLogs() {

        return readLogs();

    }


    /*
    ========================================
    Clear Logs
    ========================================
    */


    function clearLogs() {

        try {

            localStorage.removeItem(
                STORAGE_KEY
            );

            return true;

        } catch (error) {

            return false;

        }

    }


    /*
    ========================================
    Count Logs By Level
    ========================================
    */


    function countByLevel(level) {

        level = normalizeLevel(level);

        return readLogs()
            .filter(function (event) {

                return event.level === level;

            })
            .length;

    }


    /*
    ========================================
    Public Security API
    ========================================
    */


    window.SmartClassSecurityLog = {

        version: "1.0",

        log: log,

        info: function (type, message, details) {

            return log(
                "INFO",
                type,
                message,
                details
            );

        },

        low: function (type, message, details) {

            return log(
                "LOW",
                type,
                message,
                details
            );

        },

        medium: function (type, message, details) {

            return log(
                "MEDIUM",
                type,
                message,
                details
            );

        },

        high: function (type, message, details) {

            return log(
                "HIGH",
                type,
                message,
                details
            );

        },

        critical: function (type, message, details) {

            return log(
                "CRITICAL",
                type,
                message,
                details
            );

        },

        getLogs: getLogs,

        clearLogs: clearLogs,

        countByLevel: countByLevel

    };


    /*
    ========================================
    Initialization
    ========================================
    */


    console.info(
        "SmartClass Security Log 1.0 initialized."
    );


})();