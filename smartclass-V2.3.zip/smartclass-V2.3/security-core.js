"use strict";

// ============================================================
// SmartClass Security Core
// Version 1.0
// ============================================================

window.SmartClassSecurityCore = (function () {

    const VERSION = "1.0";

    const STATUS = {
        IDLE: "IDLE",
        STARTING: "STARTING",
        PROTECTED: "PROTECTED",
        PARTIAL: "PARTIAL",
        WARNING: "WARNING",
        ERROR: "ERROR"
    };

    const MODULES = [
        {
            name: "SmartClassSecurityLog",
            title: "Security Log"
        },
        {
            name: "SmartClassSecurityRules",
            title: "Security Rules"
        },
        {
            name: "SmartClassSecurityRate",
            title: "Rate Limiting"
        },
        {
            name: "SmartClassSecurityUI",
            title: "Security UI"
        },
        {
            name: "SmartClassSecurityMonitor",
            title: "Security Monitor"
        },
        {
            name: "SmartClassSecurityResponse",
            title: "Automatic Response"
        },
        {
            name: "SmartClassSecurityConfig",
            title: "Security Config"
        },
        {
            name: "SmartClassSecuritySettings",
            title: "Security Settings"
        },
        {
            name: "SmartClassSecuritySettingsUI",
            title: "Settings UI"
        },
        {
            name: "SmartClassSecurityReport",
            title: "Security Report"
        },
        {
            name: "SmartClassSecurityCSP",
            title: "Content Security Policy"
        },
        {
            name: "SmartClassSecurityInput",
            title: "Input Protection"
        },
        {
            name: "SmartClassSecurityStorage",
            title: "Secure Storage"
        },
        {
            name: "SmartClassSecurityIntegrity",
            title: "Integrity"
        },
        {
            name: "SmartClassSecurityFailSafe",
            title: "Fail Safe"
        },
        {
            name: "SmartClassSecurityHealth",
            title: "Security Health"
        },
        {
            name: "SmartClassSecurityAccess",
            title: "Access Control"
        },
        {
            name: "SmartClassSecurityData",
            title: "Data Protection"
        },
        {
            name: "SmartClassSecurityStartup",
            title: "Security Startup"
        },
        {
            name: "SmartClassSecurityDetection",
            title: "Threat Detection"
        },
        {
            name: "SmartClassSecurityAlert",
            title: "Security Alerts"
        }
    ];


    let state = {
        status: STATUS.IDLE,
        initialized: false,
        startedAt: null,
        lastCheckAt: null,
        available: 0,
        missing: [],
        errors: [],
        protectionScore: 0
    };


    // =========================================================
    // Safe Log
    // =========================================================

    function log(
        level,
        type,
        message,
        details
    ) {

        try {

            if (
                window.SmartClassSecurityLog &&
                typeof window.SmartClassSecurityLog.log ===
                "function"
            ) {

                window.SmartClassSecurityLog.log(
                    level,
                    type,
                    message,
                    details || {}
                );

            }

        } catch (error) {

            console.error(
                "Security Core Log Error:",
                error
            );

        }

    }


    // =========================================================
    // Safe String
    // =========================================================

    function safeString(
        value,
        maxLength
    ) {

        try {

            return String(value)
                .slice(
                    0,
                    maxLength || 300
                );

        } catch (error) {

            return "";

        }

    }


    // =========================================================
    // Check Module
    // =========================================================

    function checkModule(
        module
    ) {

        try {

            const exists =
                Boolean(
                    window[module.name]
                );


            return {

                name:
                    module.name,

                title:
                    module.title,

                available:
                    exists,

                type:
                    exists
                        ? typeof window[module.name]
                        : "undefined"

            };

        } catch (error) {

            return {

                name:
                    module.name,

                title:
                    module.title,

                available:
                    false,

                type:
                    "error"

            };

        }

    }


    // =========================================================
    // Check All Modules
    // =========================================================

    function checkModules() {

        const results =
            MODULES.map(
                checkModule
            );


        const available =
            results.filter(
                function (item) {

                    return item.available;

                }
            );


        const missing =
            results.filter(
                function (item) {

                    return !item.available;

                }
            );


        state.available =
            available.length;


        state.missing =
            missing.map(
                function (item) {

                    return item.name;

                }
            );


        return {

            total:
                MODULES.length,

            available:
                available.length,

            missing:
                missing.length,

            complete:
                missing.length === 0,

            modules:
                results

        };

    }


    // =========================================================
    // Calculate Protection Score
    // =========================================================

    function calculateScore(
        moduleStatus
    ) {

        if (
            !moduleStatus ||
            !moduleStatus.total
        ) {

            return 0;

        }


        const percentage =
            (
                moduleStatus.available /
                moduleStatus.total
            ) * 100;


        return Math.max(
            0,
            Math.min(
                100,
                Math.round(
                    percentage
                )
            )
        );

    }


    // =========================================================
    // Determine Status
    // =========================================================

    function determineStatus(
        score,
        moduleStatus
    ) {

        if (
            !moduleStatus ||
            moduleStatus.available === 0
        ) {

            return STATUS.ERROR;

        }


        if (
            score >= 100
        ) {

            return STATUS.PROTECTED;

        }


        if (
            score >= 80
        ) {

            return STATUS.PARTIAL;

        }


        if (
            score >= 50
        ) {

            return STATUS.WARNING;

        }


        return STATUS.ERROR;

    }


    // =========================================================
    // Run Security Check
    // =========================================================

    function check() {

        state.status =
            STATUS.STARTING;


        state.lastCheckAt =
            Date.now();


        try {

            const moduleStatus =
                checkModules();


            const score =
                calculateScore(
                    moduleStatus
                );


            state.protectionScore =
                score;


            state.status =
                determineStatus(
                    score,
                    moduleStatus
                );


            if (
                state.status ===
                STATUS.PROTECTED
            ) {

                state.errors = [];

            } else {

                state.errors =
                    moduleStatus.modules
                        .filter(
                            function (item) {

                                return !item.available;

                            }
                        )
                        .map(
                            function (item) {

                                return (
                                    item.title +
                                    " (" +
                                    item.name +
                                    ")"
                                );

                            }
                        );

            }


            return {

                version:
                    VERSION,

                status:
                    state.status,

                protectionScore:
                    state.protectionScore,

                modules:
                    moduleStatus.modules,

                available:
                    moduleStatus.available,

                total:
                    moduleStatus.total,

                missing:
                    moduleStatus.missing,

                errors:
                    [...state.errors],

                timestamp:
                    state.lastCheckAt

            };

        } catch (error) {

            state.status =
                STATUS.ERROR;


            state.errors = [
                safeString(
                    error &&
                    error.message
                        ? error.message
                        : error
                )
            ];


            log(
                "CRITICAL",
                "SECURITY_CORE_ERROR",
                "خطا در هسته امنیتی."
            );


            return {

                version:
                    VERSION,

                status:
                    STATUS.ERROR,

                protectionScore:
                    0,

                modules:
                    [],

                available:
                    0,

                total:
                    MODULES.length,

                missing:
                    [...state.missing],

                errors:
                    [...state.errors],

                timestamp:
                    Date.now()

            };

        }

    }


    // =========================================================
    // Start
    // =========================================================

    function start() {

        if (
            state.initialized
        ) {

            return check();

        }


        state.status =
            STATUS.STARTING;


        state.startedAt =
            Date.now();


        try {

            /*
             * اگر Startup Module وجود داشته باشد،
             * فقط آن را بررسی می‌کنیم.
             * اتصال واقعی در مرحله بعد انجام می‌شود.
             */

            if (
                window.SmartClassSecurityStartup &&
                typeof window.SmartClassSecurityStartup.start ===
                "function"
            ) {

                window.SmartClassSecurityStartup.start();

            }


            state.initialized =
                true;


            const result =
                check();


            if (
                result.status ===
                STATUS.PROTECTED
            ) {

                log(
                    "INFO",
                    "SECURITY_CORE_STARTED",
                    "هسته امنیتی با موفقیت آماده شد."
                );

            } else {

                log(
                    "HIGH",
                    "SECURITY_CORE_PARTIAL",
                    "هسته امنیتی به‌صورت ناقص آماده شد.",
                    {
                        score:
                            result.protectionScore,

                        available:
                            result.available,

                        total:
                            result.total
                    }
                );

            }


            return result;

        } catch (error) {

            state.status =
                STATUS.ERROR;

            state.initialized =
                false;


            log(
                "CRITICAL",
                "SECURITY_CORE_START_ERROR",
                "راه‌اندازی هسته امنیتی با خطا مواجه شد."
            );


            return check();

        }

    }


    // =========================================================
    // Stop
    // =========================================================

    function stop() {

        try {

            if (
                window.SmartClassSecurityStartup &&
                typeof window.SmartClassSecurityStartup.stop ===
                "function"
            ) {

                window.SmartClassSecurityStartup.stop();

            }

        } catch (error) {

            // Fail-safe: stopping must not crash the page.

        }


        state.initialized =
            false;

        state.status =
            STATUS.IDLE;


        return true;

    }


    // =========================================================
    // Is Protected
    // =========================================================

    function isProtected() {

        return (
            state.status ===
            STATUS.PROTECTED
        );

    }


    // =========================================================
    // Get Status
    // =========================================================

    function getStatus() {

        return {

            version:
                VERSION,

            status:
                state.status,

            initialized:
                state.initialized,

            startedAt:
                state.startedAt,

            lastCheckAt:
                state.lastCheckAt,

            available:
                state.available,

            total:
                MODULES.length,

            missing:
                [...state.missing],

            errors:
                [...state.errors],

            protectionScore:
                state.protectionScore

        };

    }


    // =========================================================
    // Get Module List
    // =========================================================

    function getModules() {

        return MODULES.map(
            function (module) {

                return {
                    name:
                        module.name,

                    title:
                        module.title
                };

            }
        );

    }


    // =========================================================
    // Reset
    // =========================================================

    function reset() {

        state = {

            status:
                STATUS.IDLE,

            initialized:
                false,

            startedAt:
                null,

            lastCheckAt:
                null,

            available:
                0,

            missing:
                [],

            errors:
                [],

            protectionScore:
                0

        };


        return true;

    }


    // =========================================================
    // Public API
    // =========================================================

    return {

        version:
            VERSION,

        statuses:
            { ...STATUS },

        start:
            start,

        stop:
            stop,

        check:
            check,

        checkModules:
            checkModules,

        isProtected:
            isProtected,

        getStatus:
            getStatus,

        getModules:
            getModules,

        reset:
            reset

    };

})();